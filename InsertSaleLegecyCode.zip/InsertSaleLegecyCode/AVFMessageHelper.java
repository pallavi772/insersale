package com.atosorigin.bluemobile.helpers;

import org.springframework.dao.DataAccessException;

import com.atosorigin.bluemobile.boundaryservices.incoming.TISIncomingMessage;
import com.atosorigin.bluemobile.dal.CreateIncomingRequestQry;
import com.atosorigin.bluemobile.dto.IncomingRequestDto;
import com.atosorigin.bluemobile.log4j.AVFLoggerLevel;
import com.atosorigin.bluemobile.log4j.BlueMobileLogger;

public class AVFMessageHelper {
	private static BlueMobileLogger logger = BlueMobileLogger.getLogger(AVFMessageHelper.class);
	
	private CreateIncomingRequestQry createIncomingRequestQry;
	
	/*
	 * This method will call createIncomingRequestQry to 
	 * insert record in IncomingRequest table.
	 */
	public long insertIncomingRequest(TISIncomingMessage tisIncomingMessage){
		IncomingRequestDto incomingRequestDto = new IncomingRequestDto();
		incomingRequestDto.setTIS(tisIncomingMessage.getTIS());
		incomingRequestDto.setRawMessage(tisIncomingMessage.getMessageText());
		
		int noOfRecords = 0;
		try {
			noOfRecords = createIncomingRequestQry.insert(incomingRequestDto);
		} catch (DataAccessException e) {
			logger.log(AVFLoggerLevel.Exception,"Error while creating IncomingRequest record for Ticket Issuer "+incomingRequestDto.getTIS(),e);
		}
		if(logger.isInfoEnabled()){
			logger.info("IncomingRequest record successfully created with id "
					+incomingRequestDto.getId()+" for TicketIssuer "+incomingRequestDto.getTIS());
		}
		return incomingRequestDto.getId();
	}
	
	/*
	 * This method will call createIncomingRequestQry to 
	 * insert record in IncomingRequest table.
	 */
	public long insertIncomingRequest(String message, String TIS ){
		IncomingRequestDto incomingRequestDto = new IncomingRequestDto();
		incomingRequestDto.setTIS(TIS);
		incomingRequestDto.setRawMessage(message);
		
		try {
			createIncomingRequestQry.insert(incomingRequestDto);
		} catch (DataAccessException e) {
			logger.log(AVFLoggerLevel.Exception,"Error while creating IncomingRequest record for Ticket Issuer "+incomingRequestDto.getTIS(),e);
		}
		if(logger.isInfoEnabled()){
			logger.info("IncomingRequest record successfully created with id "
					+incomingRequestDto.getId()+" for TicketIssuer "+incomingRequestDto.getTIS());
		}

		return incomingRequestDto.getId();
	}
	
	
	
	/**
	 * @param createIncomingRequestQry the createIncomingRequestQry to set
	 */
	public void setCreateIncomingRequestQry(
			CreateIncomingRequestQry createIncomingRequestQry) {
		this.createIncomingRequestQry = createIncomingRequestQry;
	}
}
