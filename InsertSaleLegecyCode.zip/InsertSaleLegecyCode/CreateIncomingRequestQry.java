package com.atosorigin.bluemobile.dal;

import java.sql.Types;
import java.util.Date;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import com.atosorigin.bluemobile.dto.IncomingRequestDto;
import com.atosorigin.bluemobile.log4j.BlueMobileLogger;

/**
 * This class creates the object that will be used to execute the create method.
 * It extends SqlUpdate. We create a sql insert statement of which input
 * variables will be provided when the update method of this class
 * (CreateIncomingRequestQry) is called
 * 
 * @author Yogendra Sahoo
 * @version 1.0
 * @created 09-July-2008 21:03:07
 */
public class CreateIncomingRequestQry extends SqlUpdate {

	static BlueMobileLogger logger = BlueMobileLogger.getLogger(CreateIncomingRequestQry.class);

	// Index for the dto fields and size
	private static final int DTOSIZE = 3;
	
	private static final String CREATE_INCOMING_REQUEST_QUERY 
				= "insert into incoming_request (raw_message, last_updated, ticket_issuer) values (?,?,?);";

	/**
	 * Constructor. This uses the given datasource and compiles the object with
	 * the sql that is needed to perform the creation of the record. The given
	 * IncomingRequestDto is used to build up the param object to be used in the
	 * overridden update method.
	 * 
	 * @param incomingMessageDto
	 * @param dataSource
	 */
	public CreateIncomingRequestQry(DataSource ds) {
		logger.debug("Constructor Entered");

		// build up the sql and the types for the params
		setDataSource(ds);
		setSql(CREATE_INCOMING_REQUEST_QUERY);
		declareParameter(new SqlParameter(Types.VARCHAR));
		declareParameter(new SqlParameter(Types.TIMESTAMP));
		declareParameter(new SqlParameter(Types.VARCHAR));
		setReturnGeneratedKeys(true);
		compile();

		logger.debug("Constructor Exited");
	}

	/**
	 * We call the super update method passing in our param array object and the
	 * keyholder from which we can store the given primary key
	 * 
	 * @return int noOfUpdatedRows
	 * @see org.springframework.jdbc.object.SqlUpdate#update()
	 * @see org.springframework.jdbc.object.SqlUpdate#update(java.lang.Object[],
	 *      org.springframework.jdbc.support.KeyHolder)
	 */
	public int insert(IncomingRequestDto incomingRequestDto) throws DataAccessException {
		logger.debug("Perform the update");

		Object[] params = new Object[DTOSIZE];
		
		// build up the parameters
		params[0] = incomingRequestDto.getRawMessage();

		if (incomingRequestDto.getTIS() == null || "".equals(incomingRequestDto.getTIS())) {
			params[2] = "UNKNOWN";
		} else {
			params[2] = incomingRequestDto.getTIS();
		}

		params[1] = new Date();
		KeyHolder keyHolder = new GeneratedKeyHolder();
		int noOfUpdatedRows = super.update(params, keyHolder);

		// update the dto objects
		incomingRequestDto.setId(keyHolder.getKey().intValue());
		incomingRequestDto.setLastUpdated((Date) params[1]); //last updated

		return noOfUpdatedRows;
	}

}