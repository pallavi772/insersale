package com.atosorigin.bluemobile.extranet.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.atosorigin.bluemobile.boundaryservices.incoming.tributeSale.TributeSaleHelper;
import com.atosorigin.bluemobile.exceptions.ApplicationCommunicationException;

/**
 * 
 * This class is a servlet used for Tribute Sale Data insertion.
 * @author Kishor Agrawal
 * @createdate 17-July-2012 15:10:00
 * 
 */
public class TributeInsertSaleInterface extends HttpServlet {
	
	private static Logger log = LogManager.getLogger(TributeInsertSaleInterface.class);
	private static final long serialVersionUID = -2701679880326729279L;

	/**
	 * Constructor of the object.
	 */
	public TributeInsertSaleInterface() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * @param <request>
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public  void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		Map<String,String> tributeInsertSaleRequestMap = new HashMap<String, String>();
		String responseString;
		ServletOutputStream outputStream = response.getOutputStream();
		tributeInsertSaleRequestMap.put("XML",request.getParameter("XML"));
		try {
			responseString = TributeSaleHelper.setTributeInsertSaleRequest(tributeInsertSaleRequestMap);
			response.setContentType("text/xml");	
			outputStream.write(responseString.getBytes());	
		} catch (ApplicationCommunicationException e) {
			log.error("ApplicationCommunicationException occured while executing doPost method : " + e.getMessage());
		}		
		finally{
			if(outputStream != null){
				outputStream.close();
			}
			tributeInsertSaleRequestMap = null;
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occure
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}

