package com.atosorigin.bluemobile.helpers;

import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataAccessException;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.atosorigin.bluemobile.dal.CreateNectarSaleLKeysRecordQry;
import com.atosorigin.bluemobile.dal.CreateSaleLockRecordQry;
import com.atosorigin.bluemobile.dal.CreateTributeCSaleKeysRecordQry;
import com.atosorigin.bluemobile.dal.CreateTributeNSaleKeysRecordQry;
import com.atosorigin.bluemobile.dal.CreateTributePSaleKeysRecordQry;
import com.atosorigin.bluemobile.dal.CreateTributeRSaleKeysRecordQry;
import com.atosorigin.bluemobile.dal.CreateTributeRefundReferenceQry;
import com.atosorigin.bluemobile.dal.CreateTributeSaleRecordQry;
import com.atosorigin.bluemobile.dal.CreateTributeTSaleKeysRecordQry;
import com.atosorigin.bluemobile.dal.CreateTributeUpdateSaleRecordQry;
import com.atosorigin.bluemobile.dal.DeleteSaleCKeysByIdQry;
import com.atosorigin.bluemobile.dal.DeleteSaleNKeysByIdQry;
import com.atosorigin.bluemobile.dal.DeleteSalePKeysByIdQry;
import com.atosorigin.bluemobile.dal.DeleteSaleRKeysByIdQry;
import com.atosorigin.bluemobile.dal.DeleteSaleTKeysByIdQry;
import com.atosorigin.bluemobile.dal.DeleteTributeSaleLockRecordByIdQry;
import com.atosorigin.bluemobile.dal.FindTributeExistLockByIdQry;
import com.atosorigin.bluemobile.dal.FindTributeLockedRecordsByIdQry;
import com.atosorigin.bluemobile.dal.FindTributeRefundReferenceByCodeQry;
import com.atosorigin.bluemobile.dal.FindTributeSaleIdByNonIssueElementQry;
import com.atosorigin.bluemobile.dal.FindTributeSaleLockByNonIssueIdQry;
import com.atosorigin.bluemobile.dal.FindTributeSaleRecordByIdQry;
import com.atosorigin.bluemobile.dal.FindTributeSaleRecordByLockIdQry;
import com.atosorigin.bluemobile.dal.FindTributeSaleRecordByNonIssueIdQry;
import com.atosorigin.bluemobile.dal.FindTributeSaleRecordByOriginalIdQry;
import com.atosorigin.bluemobile.dal.FindTributeSaleXmlQry;
import com.atosorigin.bluemobile.dal.FindTributeSearchSaleCKeysQry;
import com.atosorigin.bluemobile.dal.FindTributeSearchSaleForContactBookingRefQry;
import com.atosorigin.bluemobile.dal.FindTributeSearchSaleNPRkeysQry;
import com.atosorigin.bluemobile.dal.FindTributeSearchSaleNRkeysQry;
import com.atosorigin.bluemobile.dal.FindTributeSearchSalePRkeysQry;
import com.atosorigin.bluemobile.dal.FindTributeSearchSaleQry;
import com.atosorigin.bluemobile.dal.FindTributeSearchSaleRKeysQry;
import com.atosorigin.bluemobile.dal.FindTributeSearchSaleTKeysForISRNIPEQry;
import com.atosorigin.bluemobile.dal.FindTributeSearchSaleTKeysQry;
import com.atosorigin.bluemobile.dal.UpdateSaleLkeysByIdQry;
import com.atosorigin.bluemobile.dal.UpdateSaleLkeysQry;
import com.atosorigin.bluemobile.dal.UpdateTributeRefundReferenceQry;
import com.atosorigin.bluemobile.dal.UpdateTributeSaleCKeyQry;
import com.atosorigin.bluemobile.dal.UpdateTributeSaleNKeyQry;
import com.atosorigin.bluemobile.dal.UpdateTributeSalePKeyQry;
import com.atosorigin.bluemobile.dal.UpdateTributeSaleRKeyQry;
import com.atosorigin.bluemobile.dal.UpdateTributeSaleTKeyQry;
import com.atosorigin.bluemobile.dal.ticketusage.FindBarcodeDataQry;
import com.atosorigin.bluemobile.dal.ticketusage.FindBarcodeTicketScanByTicketingRecordQry;
import com.atosorigin.bluemobile.dal.ticketusage.FindBookingReferenceQryDao;
import com.atosorigin.bluemobile.dal.ticketusage.UpdateAndFetchRefundReferenceDao;
import com.atosorigin.bluemobile.dto.AvfScanDto;
import com.atosorigin.bluemobile.dto.SaleLockDto;
import com.atosorigin.bluemobile.dto.SaleRecordDto;
import com.atosorigin.bluemobile.dto.TributeNonIssueSaleDto;
import com.atosorigin.bluemobile.dto.UpdateSaleDto;
import com.atosorigin.bluemobile.enumerations.TRIBUTE_SALE_ERROR_CODE_ENUM;
import com.atosorigin.bluemobile.exceptions.TributeParserException;
import com.atosorigin.bluemobile.log4j.AVFLoggerLevel;
import com.atosorigin.bluemobile.log4j.BlueMobileLogger;
import com.atosorigin.bluemobile.parsers.TributeGenerateReferenceParser;
import com.atosorigin.bluemobile.parsers.TributeInsertSaleParser;
import com.atosorigin.bluemobile.parsers.TributeLockSaleParser;
import com.atosorigin.bluemobile.parsers.TributeNonIssueSaleParser;
import com.atosorigin.bluemobile.parsers.TributeSearchSaleParser;
import com.atosorigin.bluemobile.parsers.TributeUnlockSaleParser;
import com.atosorigin.bluemobile.parsers.TributeUpdateSaleParser;

import net.sf.json.JSONObject;

/**
 * This class acts as a helper class and is used to fetch the approraite data,
 * process and validate Tribute incoming requests for various calls, received
 * from the specific associated Interface and ejb call.
 * 
 * @author Sudha Parab.
 * @updatedate 14-Aug-2012 17:10:00
 * 
 */
public class TributeMessageHelper {
	static BlueMobileLogger logger = BlueMobileLogger.getLogger(TributeMessageHelper.class);
	
	private static final String XMLELEMENT = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation Ref=\"";
	
	private UpdateTributeRefundReferenceQry updateTributeRefundReferenceQryDao;

	private FindTributeSaleRecordByIdQry findTributeSaleRecordByIdQryDao;

	private FindTributeSaleRecordByOriginalIdQry findTributeSaleRecordByOriginalIdQryDao;

	private FindTributeRefundReferenceByCodeQry findTributeRefundReferenceByCodeQryDao;

	private CreateTributeRefundReferenceQry CreateTributeRefundReferenceQryDao;

	private CreateTributeSaleRecordQry CreateTributeSaleRecordQryDao;

	private CreateTributeCSaleKeysRecordQry createTributeCSaleKeysRecordQryDao;

	private CreateTributeTSaleKeysRecordQry createTributeTSaleKeysRecordQryDao;

	private CreateTributePSaleKeysRecordQry createTributePSaleKeysRecordQryDao;

	private CreateTributeNSaleKeysRecordQry createTributeNSaleKeysRecordQryDao;

	private CreateTributeRSaleKeysRecordQry createTributeRSaleKeysRecordQryDao;

	private CreateNectarSaleLKeysRecordQry createNectarSaleLKeysRecordQry;

	private CreateTributeUpdateSaleRecordQry createTributeUpdateSaleRecordQryDao;

	private DeleteSaleCKeysByIdQry deleteSaleCKeysByIdQryDao;

	private DeleteSaleTKeysByIdQry deleteSaleTKeysByIdQryDao;

	private DeleteSalePKeysByIdQry deleteSalePKeysByIdQryDao;

	private DeleteSaleNKeysByIdQry deleteSaleNKeysByIdQryDao;

	private DeleteSaleRKeysByIdQry deleteSaleRKeysByIdQryDao;

	private FindTributeSaleRecordByLockIdQry findTributeSaleRecordByLockIdQryDao;

	private FindBarcodeDataQry findBarcodeDataQryDao;

	private FindTributeExistLockByIdQry findTributeExistLockByIdQryDao;

	private CreateSaleLockRecordQry createSaleLockRecordQryDao;

	private FindTributeLockedRecordsByIdQry findTributeLockedRecordsByIdQryDao;

	private DeleteTributeSaleLockRecordByIdQry deleteTributeSaleLockRecordByIdQryDao;

	private FindTributeSaleIdByNonIssueElementQry findTributeSaleIdByNonIssueElementQryDao;

	private FindTributeSaleRecordByNonIssueIdQry findTributeSaleRecordByNonIssueIdQryDao;

	private FindTributeSaleLockByNonIssueIdQry findTributeSaleLockByNonIssueIdQryDao;

	private FindTributeSearchSaleTKeysQry findTributeSearchSaleTKeysQryDao;

	private FindTributeSearchSaleCKeysQry findTributeSearchSaleCKeysQryDao;

	private FindTributeSearchSaleRKeysQry findTributeSearchSaleRKeysQryDao;

	private FindTributeSearchSaleNRkeysQry findTributeSearchSaleNRkeysQryDao;

	private FindTributeSearchSalePRkeysQry findTributeSearchSalePRkeysQryDao;

	private FindTributeSearchSaleNPRkeysQry findTributeSearchSaleNPRkeysQryDao;
	
	private FindTributeSearchSaleQry findTributeSearchSaleQryDao;
	
	private FindTributeSearchSaleTKeysForISRNIPEQry findTributeSearchSaleTKeysForISRNIPEQryDao;

	private FindTributeSaleXmlQry findTributeSaleXmlQryDao;

	private UpdateTributeSaleCKeyQry updateTributeSaleCKeyQryDao;

	private UpdateTributeSaleTKeyQry updateTributeSaleTKeyQryDao;

	private UpdateTributeSalePKeyQry updateTributeSalePKeyQryDao;

	private UpdateTributeSaleNKeyQry updateTributeSaleNKeyQryDao;

	private UpdateTributeSaleRKeyQry updateTributeSaleRKeyQryDao;

	private UpdateSaleLkeysByIdQry updateSaleLkeysByIdQryDao;

	private UpdateSaleLkeysQry updateSaleLkeysQryDao;
	
	private FindTributeSearchSaleForContactBookingRefQry findTributeSearchSaleForContactBookingRefQryDao;
	
	private FindBookingReferenceQryDao findBookingReferenceQryDao;
	
	private UpdateAndFetchRefundReferenceDao updateAndFetchRefundReferenceDao;
	
	public UpdateAndFetchRefundReferenceDao getUpdateAndFetchRefundReferenceDao() {
		return updateAndFetchRefundReferenceDao;
	}

	public void setUpdateAndFetchRefundReferenceDao(UpdateAndFetchRefundReferenceDao updateAndFetchRefundReferenceDao) {
		this.updateAndFetchRefundReferenceDao = updateAndFetchRefundReferenceDao;
	}

	public FindBookingReferenceQryDao getFindBookingReferenceQryDao() {
		return findBookingReferenceQryDao;
	}

	public void setFindBookingReferenceQryDao(FindBookingReferenceQryDao findBookingReferenceQryDao) {
		this.findBookingReferenceQryDao = findBookingReferenceQryDao;
	}

	public UpdateSaleLkeysQry getUpdateSaleLkeysQryDao() {
		return updateSaleLkeysQryDao;
	}

	public void setUpdateSaleLkeysQryDao(
			UpdateSaleLkeysQry updateSaleLkeysQryDao) {
		this.updateSaleLkeysQryDao = updateSaleLkeysQryDao;
	}

	private FindBarcodeTicketScanByTicketingRecordQry findBarcodeTicketScanByTicketingRecordQryDao;


	/**
	 * @return the createTributeCSaleKeysRecordQryDao
	 */
	public CreateTributeCSaleKeysRecordQry getCreateTributeCSaleKeysRecordQryDao() {
		return createTributeCSaleKeysRecordQryDao;
	}

	/**
	 * @param createTributeCSaleKeysRecordQryDao
	 *            the createTributeCSaleKeysRecordQryDao to set
	 */
	public void setCreateTributeCSaleKeysRecordQryDao(
			CreateTributeCSaleKeysRecordQry createTributeCSaleKeysRecordQryDao) {
		this.createTributeCSaleKeysRecordQryDao = createTributeCSaleKeysRecordQryDao;
	}

	public CreateNectarSaleLKeysRecordQry getCreateNectarSaleLKeysRecordQry() {
		return createNectarSaleLKeysRecordQry;
	}

	public void setCreateNectarSaleLKeysRecordQry(
			CreateNectarSaleLKeysRecordQry createNectarSaleLKeysRecordQry) {
		this.createNectarSaleLKeysRecordQry = createNectarSaleLKeysRecordQry;
	}

	public UpdateSaleLkeysByIdQry getUpdateSaleLkeysByIdQryDao() {
		return updateSaleLkeysByIdQryDao;
	}

	public void setUpdateSaleLkeysByIdQryDao(
			UpdateSaleLkeysByIdQry updateSaleLkeysByIdQryDao) {
		this.updateSaleLkeysByIdQryDao = updateSaleLkeysByIdQryDao;
	}

	/**
	 * @return the createTributeNSaleKeysRecordQryDao
	 */
	public CreateTributeNSaleKeysRecordQry getCreateTributeNSaleKeysRecordQryDao() {
		return createTributeNSaleKeysRecordQryDao;
	}

	/**
	 * @param createTributeNSaleKeysRecordQryDao
	 *            the createTributeNSaleKeysRecordQryDao to set
	 */
	public void setCreateTributeNSaleKeysRecordQryDao(
			CreateTributeNSaleKeysRecordQry createTributeNSaleKeysRecordQryDao) {
		this.createTributeNSaleKeysRecordQryDao = createTributeNSaleKeysRecordQryDao;
	}

	/**
	 * @return the createTributePSaleKeysRecordQryDao
	 */
	public CreateTributePSaleKeysRecordQry getCreateTributePSaleKeysRecordQryDao() {
		return createTributePSaleKeysRecordQryDao;
	}

	/**
	 * @param createTributePSaleKeysRecordQryDao
	 *            the createTributePSaleKeysRecordQryDao to set
	 */
	public void setCreateTributePSaleKeysRecordQryDao(
			CreateTributePSaleKeysRecordQry createTributePSaleKeysRecordQryDao) {
		this.createTributePSaleKeysRecordQryDao = createTributePSaleKeysRecordQryDao;
	}

	/**
	 * This method is a helper to process Tribute request for Insert Sale. First
	 * scan parameters are validated and then Dal classes are used to insert
	 * scan record.The success or error response is sent in String format.
	 * 
	 * @author Sudha Parab
	 * @throws Exception
	 * @throws DataAccessException
	 * @createdate 14-Aug-2012
	 */
	public String insertSale(TributeInsertSaleRequest tributeInsertSaleRequest,
			long incomingRequestId) throws Exception {
		int length = 0;
		int ctr_length = 0;
		String output_xml = "";
		SaleRecordDto saleRecordDto = new SaleRecordDto();
		String inputXml = tributeInsertSaleRequest.getInputxml();
		List refundReferenceList = new ArrayList();
		List refundStatusList = new ArrayList();
		List surnameList = new ArrayList();
		List transactionList = new ArrayList();
		List issueDateList = new ArrayList();
		List postCodeList = new ArrayList();
		// CR037 changes
		List travelDateList = new ArrayList();
		Map<String, String> insertSaleMap = new HashMap<String, String>();
		TributeInsertSaleParser tributeInsertSaleParser = new TributeInsertSaleParser();
		try {
			insertSaleMap = tributeInsertSaleParser.parseInput(inputXml,findBookingReferenceQryDao);

			if (MapUtils.isNotEmpty(insertSaleMap)) {
					try {
						saleRecordDto.setOriginal_id("0");

						Iterator iterator = insertSaleMap.entrySet().iterator();
						while (iterator.hasNext()) {

							Map.Entry mapEntry = (Map.Entry) iterator.next();

							if (mapEntry.getKey().equals("machine_type")) {
								saleRecordDto.setMachine_type(mapEntry.getValue()
										.toString());

							}

							if (mapEntry.getKey().equals("ctr_reference")) {

								if ((!(mapEntry.getValue().toString())
										.equalsIgnoreCase("~"))) {
									ctr_length = (mapEntry.getValue().toString())
											.length();
									saleRecordDto.setCtr_reference(mapEntry
											.getValue().toString());

								}
							}

							if (mapEntry.getKey().equals("issuedate_size")) {
								length = Integer.valueOf(mapEntry.getValue()
										.toString());

								for (int i = 0; i < length; i++) {

									issueDateList.add(insertSaleMap.get(
											"issue_date" + i).toString());

								}

							}

							if (mapEntry.getKey().equals("transaction_size")) {
								length = Integer.valueOf(mapEntry.getValue()
										.toString());

								for (int i = 0; i < length; i++) {

									transactionList.add(insertSaleMap.get(
											"transaction" + i).toString());

								}

							}

							// CR037 changes

							if (mapEntry.getKey().equals("travel_date_size")) {
								length = Integer.valueOf(mapEntry.getValue()
										.toString());

								for (int i = 0; i < length; i++) {

									travelDateList.add(insertSaleMap.get(
											"travel_date" + i).toString());

								}

							}

							if (mapEntry.getKey().equals("surname_size")) {

								length = Integer.valueOf(mapEntry.getValue()
										.toString());
								if (length != 0) {
									for (int i = 0; i < length; i++) {

										surnameList.add(insertSaleMap.get(
												"surname" + i).toString());

									}
								}
							}

							if (mapEntry.getKey().equals("postcode_size")) {

								length = Integer.valueOf(mapEntry.getValue()
										.toString());
								if (length != 0) {
									for (int i = 0; i < length; i++) {

										postCodeList.add(insertSaleMap.get(
												"postcode" + i).toString());

									}
								}
							}

							if (mapEntry.getKey().equals("machine")) {
								saleRecordDto.setMachine(mapEntry.getValue()
										.toString());

							}

							if (mapEntry.getKey().equals("loyalty_card_id")) {
								saleRecordDto.setLoyaltyCardId(Long
										.valueOf(mapEntry.getValue().toString()));

							}

							if (mapEntry.getKey().equals("issue_machine")) {
								saleRecordDto.setIssue_machine(mapEntry.getValue()
										.toString());

							}
							if (mapEntry.getKey().equals("userid")) {
								saleRecordDto.setUser_id(mapEntry.getValue()
										.toString());

							}
							if (mapEntry.getKey().equals("sale_element")) {
								saleRecordDto.setSale(mapEntry.getValue()
										.toString());
							}
							
							if(mapEntry.getKey().equals("business_group")) {
								saleRecordDto.setBusiness_group(mapEntry.getValue().toString());
							}
							
							if(mapEntry.getKey().equals("contact_booking_reference")) {
								saleRecordDto.setContact_booking_ref(Long.parseLong(mapEntry.getValue().toString()));
							}

							if (mapEntry.getKey().equals("refund_reference_size")) {
								length = Integer.valueOf(mapEntry.getValue()
										.toString());
								for (int i = 0; i < length; i++) {

									refundReferenceList.add(insertSaleMap.get(
											"refund_reference" + i).toString());
									refundStatusList.add(insertSaleMap.get(
											"refund_status" + i).toString());

								}
							}

						}

						int result = CreateTributeSaleRecordQryDao
								.insert(saleRecordDto);
						if (result == -1) {
							logger.log(
									AVFLoggerLevel.Exception,
									"Original_id in Helper: "
											+ saleRecordDto.getOriginal_id());
							logger.log(
									AVFLoggerLevel.Exception,
									"Machine_type in Helper: "
											+ saleRecordDto.getMachine_type());
							logger.log(
									AVFLoggerLevel.Exception,
									"Machine in Helper: "
											+ saleRecordDto.getMachine());
							logger.log(
									AVFLoggerLevel.Exception,
									"User_id in Helper: "
											+ saleRecordDto.getUser_id());
							logger.log(AVFLoggerLevel.Exception, "Sale in Helper: "
									+ saleRecordDto.getSale());
							throw new Exception(
									"Null values found for non-nullable database fields.");
						}

						if (ctr_length != 0) {
							try {
								int result1 = createTributeCSaleKeysRecordQryDao
										.insert(saleRecordDto);
							} catch (Exception e) {
								logger.log(
										AVFLoggerLevel.Exception,
										"Error in inserting data in CSale table: "
												+ saleRecordDto.getOriginal_id());
							}
						}
						if (refundReferenceList.size() > 0) {

							HashSet hashSetStatus = new HashSet();
							hashSetStatus.addAll(refundReferenceList);
							refundReferenceList.clear();
							refundReferenceList.addAll(hashSetStatus);

							for (int i = 0; i < refundReferenceList.size(); i++) {
								saleRecordDto
										.setRefund_reference(refundReferenceList
												.get(i).toString());
								saleRecordDto.setRefund_status(refundStatusList
										.get(i).toString());
								
								if(insertSaleMap.containsKey("createdDate"+refundReferenceList
										.get(i).toString())) {
									saleRecordDto.setRefund_created_date(insertSaleMap.get("createdDate"+refundReferenceList
											.get(i).toString()));
								}
								else{
									saleRecordDto.setRefund_created_date(null);
								}

								try {
									int result5 = createTributeRSaleKeysRecordQryDao
											.insert(saleRecordDto);
								} catch (Exception e) {
									logger.log(
											AVFLoggerLevel.Exception,
											"Error in inserting data in RSale table: "
													+ saleRecordDto.getOriginal_id());

								}
							}
							hashSetStatus = null;
						}

						if (surnameList.size() > 0) {
							HashSet hs = new HashSet();
							hs.addAll(surnameList);
							surnameList.clear();
							surnameList.addAll(hs);
							for (int i = 0; i < surnameList.size(); i++) {
								saleRecordDto.setSurname(surnameList.get(i)
										.toString());

								try {
									int result4 = createTributeNSaleKeysRecordQryDao
											.insert(saleRecordDto);
								} catch (Exception e) {
									logger.log(
											AVFLoggerLevel.Exception,
											"Error in inserting data in NSale table: "
													+ saleRecordDto.getOriginal_id());
								}
							}
							hs = null;
						}
						if (postCodeList.size() > 0) {
							HashSet hs = new HashSet();
							hs.addAll(postCodeList);
							postCodeList.clear();
							postCodeList.addAll(hs);
							for (int i = 0; i < postCodeList.size(); i++) {
								saleRecordDto.setPostcode(postCodeList.get(i)
										.toString());

								try {
									int result3 = createTributePSaleKeysRecordQryDao
											.insert(saleRecordDto);
								} catch (Exception e) {
									logger.log(
											AVFLoggerLevel.Exception,
											"Error in inserting data in PSale table: "
													+ saleRecordDto.getOriginal_id());
								}
							}
							hs = null;
						}

						if (transactionList.size() > 0) {

							HashSet hashSet = new HashSet();
							hashSet.addAll(transactionList);
							transactionList.clear();
							transactionList.addAll(hashSet);

							for (int k = 0; k < transactionList.size(); k++) {
								saleRecordDto.setIssue_date(issueDateList.get(k)
										.toString());
								saleRecordDto.setTransaction_number(transactionList
										.get(k).toString());
								
								
								//12081 changes
								if(insertSaleMap.containsKey("isrn"+transactionList
										.get(k).toString())) {
									saleRecordDto.setIsrn(insertSaleMap.get("isrn"+transactionList
											.get(k).toString()));
								}
								else{
									saleRecordDto.setIsrn(null);
								}
								
								if(insertSaleMap.containsKey("ipe_instanceId"+transactionList
										.get(k).toString())) {
									saleRecordDto.setIpeInstanceId(insertSaleMap.get("ipe_instanceId"+transactionList
											.get(k).toString()));
								}
								else{
									saleRecordDto.setIpeInstanceId(null);
								}

								// CR037 changes
								if (travelDateList.size() == transactionList.size())
									saleRecordDto.setTravel_date(travelDateList
											.get(k).toString());
								else
									saleRecordDto.setTravel_date(null);

								saleRecordDto.setTicketingRecordId(0);
								try {

									int result1 = createTributeTSaleKeysRecordQryDao
											.insert(saleRecordDto);
								} catch (Exception e) {
									logger.log(
											AVFLoggerLevel.Exception,
											"Error in inserting data in TSale table: "
													+ saleRecordDto.getOriginal_id());
								}

							}
							// }
							hashSet = null;
						}

						if (saleRecordDto != null
								&& saleRecordDto.getLoyaltyCardId() != 0) {
							createNectarSaleLKeysRecordQry.insert(saleRecordDto);
						}

						// Sending the Confirmation ID created for insert sale
						// record as output XML.

						output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation ID=\""
								+ saleRecordDto.getId()
								+ "\"><Errors></Errors><Warnings></Warnings></Confirmation>";
						if (logger.isInfoEnabled()) {
							logger.info("Tribute Sale record successfully created for Insert Sale  with id "
									+ saleRecordDto.getId());
						}
					} catch (DataAccessException e) {
						// Sending error XML as output
						logger.log(AVFLoggerLevel.Exception,
								"Error while creating Tribute record for Insert Sale"
										+ e);
						output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
								+ "<code>98</code><desc>\""
								+ e.getMessage()
								+ "\"</desc></Error></Errors><Warnings></Warnings></Confirmation>";
					} catch (Exception e) {
						// Sending error XML as output
						logger.log(AVFLoggerLevel.Exception,
								"Error while creating Tribute record for Insert Sale"
										+ e);
						output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
								+ "<code>99</code><desc>Unexpected system failure</desc>"
								+ "</Error></Errors><Warnings></Warnings></Confirmation>";
					}
			} else {
				// Sending output XML containing error when incoming XML in invalid
				// format.
				logger.log(
						AVFLoggerLevel.Exception,
						"Error while creating Tribute record for Insert Sale  since Input message is in invalid format");
				output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
						+ "<code>01</code><desc>Input message is in invalid format</desc>"
						+ "</Error></Errors><Warnings></Warnings></Confirmation>";
			}
		} catch (Exception e) {
			logger.error("Exception occured while executing insertSale method : " + e.getMessage());
		} finally {
			insertSaleMap = null;
			refundReferenceList = null;
			refundStatusList = null;
			surnameList = null;
			transactionList = null;
			issueDateList = null;
			postCodeList = null;
			travelDateList = null;
		}
		return output_xml;
	}

	/**
	 * This method is a helper to process Tribute request for Update Sale. First
	 * scan parameters are validated and then Dal classes are used to update the
	 * existing scan record.The success or error response is sent in String
	 * format. New record is inserted in Sale table while also retaining the
	 * original record history.
	 * 
	 * @author Sudha Parab
	 * @throws DataAccessException
	 * @createdate 17-Aug-2012
	 */
	public String updateSale(TributeInsertSaleRequest tributeInsertSaleRequest, long incomingRequestId) {
		logger.debug("updateSale method called!");
		String output_xml = "";
		int length = 0;
		int ctr_length = 0;
		List refundReferenceList = new ArrayList();
		List refundStatusList = new ArrayList();
		List surnameList = new ArrayList();
		List ctrRefList = new ArrayList();
		List transactionList = new ArrayList();
		List issueDateList = new ArrayList();
		List postCodeList = new ArrayList();
		SaleRecordDto saleRecordDto = new SaleRecordDto();
		String inputXml = tributeInsertSaleRequest.getInputxml();
		TributeUpdateSaleParser tributeUpdateSaleParser = new TributeUpdateSaleParser();
		Map updateSaleMap = tributeUpdateSaleParser.parseInput(inputXml);

		try {
			if (MapUtils.isNotEmpty(updateSaleMap)) {

				Iterator iterator = updateSaleMap.entrySet().iterator();
				while (iterator.hasNext()) {
					Map.Entry mapEntry = (Map.Entry) iterator.next();

					if (mapEntry.getKey().equals("machine_type")) {
						saleRecordDto.setMachine_type(mapEntry.getValue().toString());
					}
					if (mapEntry.getKey().equals("machine")) {
						saleRecordDto.setMachine(mapEntry.getValue().toString());
					}
					if (mapEntry.getKey().equals("userid")) {
						saleRecordDto.setUser_id(mapEntry.getValue().toString());
					}
					if (mapEntry.getKey().equals("received_update_id")) {
						saleRecordDto.setId(new BigInteger(mapEntry.getValue().toString()));
					}
					if (mapEntry.getKey().equals("sale_element")) {
						saleRecordDto.setSale(mapEntry.getValue().toString());
					}
					if (mapEntry.getKey().equals("issue_machine")) {
						saleRecordDto.setIssue_machine(mapEntry.getValue().toString());
					}

					if (mapEntry.getKey().equals("loyalty_card_id")) {
						saleRecordDto.setLoyaltyCardId(Long.valueOf(mapEntry.getValue().toString()));

					}
					if (mapEntry.getKey().equals("issuedate_size")) {
						length = Integer.valueOf(mapEntry.getValue().toString());
						for (int i = 0; i < length; i++) {

							issueDateList.add(updateSaleMap.get("issue_date" + i).toString());

						}

					}

					if (mapEntry.getKey().equals("transaction_size")) {
						length = Integer.valueOf(mapEntry.getValue().toString());
						for (int i = 0; i < length; i++) {

							transactionList.add(updateSaleMap.get("transaction" + i).toString());

						}

					}

					if (mapEntry.getKey().equals("ctr_reference")) {

						if ((!(mapEntry.getValue().toString()).equalsIgnoreCase("~"))) {
							ctr_length = (mapEntry.getValue().toString()).length();
							saleRecordDto.setCtr_reference(mapEntry.getValue().toString());

						}
					}

					if (mapEntry.getKey().equals("surname_size")) {

						length = Integer.valueOf(mapEntry.getValue().toString());
						if (length != 0) {
							for (int i = 0; i < length; i++) {

								surnameList.add(updateSaleMap.get("surname" + i).toString());

							}
						}
					}

					if (mapEntry.getKey().equals("postcode_size")) {
						length = Integer.valueOf(mapEntry.getValue().toString());
						if (length != 0) {
							for (int i = 0; i < length; i++) {

								postCodeList.add(updateSaleMap.get("postcode" + i).toString());

							}
						}
					}

					if (mapEntry.getKey().equals("business_group")) {
						saleRecordDto.setBusiness_group(mapEntry.getValue().toString());
					}
					
					if(mapEntry.getKey().equals("contact_booking_reference")) {
						saleRecordDto.setContact_booking_ref(Long.parseLong(mapEntry.getValue().toString()));
					}

					if (mapEntry.getKey().equals("refund_reference_size")) {
						length = Integer.valueOf(mapEntry.getValue().toString());

						for (int i = 0; i < length; i++) {

							refundReferenceList.add(updateSaleMap.get("refund_reference" + i).toString());
							refundStatusList.add(updateSaleMap.get("refund_status" + i).toString());

						}
					}

				}
				List<UpdateSaleDto> tributeUpdateSaleDtoList = null;
				List<UpdateSaleDto> tributeUpdateSaleDtoList2 = null;

				Object[] params = new Object[1];
				params[0] = saleRecordDto.getId().toString();

				// Finding whether the record exists in Sale table.
				tributeUpdateSaleDtoList = findTributeSaleRecordByIdQryDao.execute12(params);
				if (CollectionUtils.isNotEmpty(tributeUpdateSaleDtoList)) {
					if (StringUtils.equals(tributeUpdateSaleDtoList.get(0).original_id, "0")) {
						// If original_ID of existing record=0,then
						// original_ID of new record be ID of that existing
						// record.
						saleRecordDto.setOriginal_id(String.valueOf(tributeUpdateSaleDtoList.get(0).id));
					} else {
						// If original_ID of existing record!=0,then
						// original_ID of new record be original_ID of that
						// existing record.
						saleRecordDto.setOriginal_id(tributeUpdateSaleDtoList.get(0).original_id);
					}

					// Deleting the existing records of update ID from
					// SaleKeys tables.

					Object[] params1 = new Object[1];
					params1[0] = saleRecordDto.getOriginal_id();

					tributeUpdateSaleDtoList2 = findTributeSaleRecordByOriginalIdQryDao.execute(params1);

					List<SaleRecordDto> sale_list = new ArrayList<SaleRecordDto>();

					// // start CR037 changes
					sale_list = findBarcodeDataQryDao.execute(saleRecordDto.getId());

					if (CollectionUtils.isNotEmpty(tributeUpdateSaleDtoList2)) {
						params1[0] = tributeUpdateSaleDtoList2.get(0).getId();
						int numberOfRecords1 = deleteSaleCKeysByIdQryDao.delete(params1);
						int numberOfRecords2 = deleteSaleTKeysByIdQryDao.delete(params1);
						int numberOfRecords3 = deleteSalePKeysByIdQryDao.delete(params1);
						int numberOfRecords4 = deleteSaleNKeysByIdQryDao.delete(params1);
						int numberOfRecords5 = deleteSaleRKeysByIdQryDao.delete(params1);
					} else {
						int numberOfRecords1 = deleteSaleCKeysByIdQryDao.delete(params);
						int numberOfRecords2 = deleteSaleTKeysByIdQryDao.delete(params);
						int numberOfRecords3 = deleteSalePKeysByIdQryDao.delete(params);
						int numberOfRecords4 = deleteSaleNKeysByIdQryDao.delete(params);
						int numberOfRecords5 = deleteSaleRKeysByIdQryDao.delete(params);
					}

					saleRecordDto.setCid(saleRecordDto.getId());
					int result = CreateTributeSaleRecordQryDao.insert(saleRecordDto);
					if (saleRecordDto != null && saleRecordDto.getLoyaltyCardId() != 0) {
						updateSaleLkeysQryDao.update(saleRecordDto);
					}

					if (ctr_length != 0) {
						try {
							int result1 = createTributeCSaleKeysRecordQryDao.insert(saleRecordDto);
						} catch (Exception e) {
							logger.log(AVFLoggerLevel.Exception,
									"Error in inserting data in CSaleKeys table: " + saleRecordDto.getOriginal_id());
						}
					}

					if (refundReferenceList.size() > 0) {
						HashSet hashSetStatus = new HashSet();
						hashSetStatus.addAll(refundReferenceList);
						refundReferenceList.clear();
						refundReferenceList.addAll(hashSetStatus);

						for (int i = 0; i < refundReferenceList.size(); i++) {
							saleRecordDto.setRefund_reference(refundReferenceList.get(i).toString());
							saleRecordDto.setRefund_status(refundStatusList.get(i).toString());
							// 11540 changes
							if (updateSaleMap.containsKey("createdDate" + refundReferenceList.get(i).toString())) {
								saleRecordDto.setRefund_created_date(updateSaleMap
										.get("createdDate" + refundReferenceList.get(i).toString()).toString());
							} else {
								saleRecordDto.setRefund_created_date(null);
							}

							try {
								int result5 = createTributeRSaleKeysRecordQryDao.insert(saleRecordDto);
							} catch (Exception e) {
								logger.log(AVFLoggerLevel.Exception, "Error in inserting data in RSaleKeys table: "
										+ saleRecordDto.getOriginal_id());
							}
						}
						hashSetStatus = null;
					}

					if (surnameList.size() > 0) {
						HashSet hs = new HashSet();
						hs.addAll(surnameList);
						surnameList.clear();
						surnameList.addAll(hs);
						for (int i = 0; i < surnameList.size(); i++) {
							saleRecordDto.setSurname(surnameList.get(i).toString());

							try {
								int result4 = createTributeNSaleKeysRecordQryDao.insert(saleRecordDto);
							} catch (Exception e) {
								logger.log(AVFLoggerLevel.Exception, "Error in inserting data in NSaleKeys table: "
										+ saleRecordDto.getOriginal_id());
							}
						}
						hs = null;
					}
					if (postCodeList.size() > 0) {
						HashSet hs = new HashSet();
						hs.addAll(postCodeList);
						postCodeList.clear();
						postCodeList.addAll(hs);
						for (int i = 0; i < postCodeList.size(); i++) {
							saleRecordDto.setPostcode(postCodeList.get(i).toString());

							try {
								int result3 = createTributePSaleKeysRecordQryDao.insert(saleRecordDto);
							} catch (Exception e) {
								logger.log(AVFLoggerLevel.Exception, "Error in inserting data in PSaleKeys table: "
										+ saleRecordDto.getOriginal_id());
							}
						}
						hs = null;
					}

					if (transactionList.size() > 0) {

						HashSet hashSet = new HashSet();
						hashSet.addAll(transactionList);
						transactionList.clear();
						transactionList.addAll(hashSet);

						for (int k = 0; k < transactionList.size(); k++) {
							saleRecordDto.setIssue_date(issueDateList.get(k).toString());
							saleRecordDto.setTransaction_number(transactionList.get(k).toString());

							// 12081 changes
							if (updateSaleMap.containsKey("isrn" + transactionList.get(k).toString())) {
								saleRecordDto.setIsrn(
										updateSaleMap.get("isrn" + transactionList.get(k).toString()).toString());
							} else {
								saleRecordDto.setIsrn(null);
							}

							if (updateSaleMap.containsKey("ipe_instanceId" + transactionList.get(k).toString())) {
								saleRecordDto.setIpeInstanceId(updateSaleMap
										.get("ipe_instanceId" + transactionList.get(k).toString()).toString());
							} else {
								saleRecordDto.setIpeInstanceId(null);
							}

							if (sale_list.size() > k) {
								saleRecordDto.setTravel_date(sale_list.get(k).getTravel_date());
								saleRecordDto.setTicketingRecordId(sale_list.get(k).getTicketingRecordId());

							} else {
								saleRecordDto.setTravel_date(null);
								saleRecordDto.setTicketingRecordId(0);
							}

							try {
								int result1 = createTributeTSaleKeysRecordQryDao.insert(saleRecordDto);
							} catch (Exception e) {
								logger.log(AVFLoggerLevel.Exception, "Error in inserting data in TSaleKeys table: "
										+ saleRecordDto.getOriginal_id());
							}

						}
						hashSet = null;
					}

					// Calling unlock processing
					List<UpdateSaleDto> tributeFindOriginalIdList = null;
					Object[] original = new Object[1];
					original[0] = saleRecordDto.getId();
					tributeFindOriginalIdList = findTributeSaleRecordByIdQryDao.execute12(original);

					if ((tributeFindOriginalIdList.get(0).original_id).equalsIgnoreCase("0")) {
						params[0] = tributeFindOriginalIdList.get(0).id;
					} else {
						params[0] = tributeFindOriginalIdList.get(0).getOriginal_id();
					}
					// Deleting the existing record for update ID/original
					// ID of update record present in the sale_lock table.
					int result1 = deleteTributeSaleLockRecordByIdQryDao.delete(params);

					// Sending output XML containing confirmation ID of the
					// updated record created in sale table.
					if (logger.isInfoEnabled()) {
						logger.info("Tribute Sale record for Update Sale successfully created with id "
								+ saleRecordDto.getId());
					}
					output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation ID=\"" + saleRecordDto.getId()
							+ "\"><Errors></Errors><Warnings></Warnings></Confirmation>";
				} else {
					// Sending output XML containing error if the record to
					// be updated doesnt exist.
					output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
							+ "<code>02</code><desc>Sale Not found"
							+ "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
				}

			} else {
				// Sending output XML containing error when incoming XML in invalid
				// format.
				logger.log(AVFLoggerLevel.Exception,
						"Error while creating Tribute record for Update Sale  since Input message is in invalid format");
				output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
						+ "<code>01</code><desc>Input message is in invalid format."
						+ "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
			}
		} catch (DataAccessException e) {
			// Sending error XML as output
			logger.log(AVFLoggerLevel.Exception,
					"Error while creating Tribute record for Update Sale " + e);
			output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
					+ "<code>98</code><desc>\"" + e.getMessage()
					+ "\"</desc></Error></Errors><Warnings></Warnings></Confirmation>";
		} catch (Exception e) {
			logger.error("Exception occured while executing updateSale method : " + e.getMessage());
			logger.log(AVFLoggerLevel.Exception,
					"Error while creating Tribute record for Update Sale " + e);
			return output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
					+ "<code>99</code><desc>Unexpected system failure"
					+ "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
		} finally {
			refundReferenceList = null;
			refundStatusList = null;
			surnameList = null;
			ctrRefList = null;
			transactionList = null;
			issueDateList = null;
			postCodeList = null;
			updateSaleMap = null;
		}
		return output_xml;
	}

	/**
	 * This method is a helper to process Tribute request for Lock Sale. First
	 * scan parameters are validated and then Dal classes are used to lock the
	 * incoming scan record.The success or error response is sent in String
	 * format. The record is inserted in Sale_lock table if it already dosen't
	 * exist.
	 * 
	 * @author Sudha Parab
	 * @throws DataAccessException
	 * @createdate 17-Aug-2012
	 */

	public String lockSale(TributeInsertSaleRequest tributeInsertSaleRequest,
			long incomingRequestId) {
		String output_xml = null;
		String received_lock_id = "";
		SaleRecordDto saleRecordDto = new SaleRecordDto();
		SaleLockDto saleLockDto = new SaleLockDto();

		String inputXml = tributeInsertSaleRequest.getInputxml();
		TributeLockSaleParser tributeLockSaleParser = new TributeLockSaleParser();
		Map lockSaleMap = tributeLockSaleParser.parseLockInput(inputXml);
		try {

			if (!((lockSaleMap == null) || (lockSaleMap.isEmpty()))) {

				Iterator iterator = lockSaleMap.entrySet().iterator();
				while (iterator.hasNext()) {

					Map.Entry mapEntry = (Map.Entry) iterator.next();
					if (mapEntry.getKey().equals("machine_type")) {
						saleRecordDto.setMachine_type(mapEntry.getValue()
								.toString());

					}
					if (mapEntry.getKey().equals("machine")) {
						saleRecordDto
								.setMachine(mapEntry.getValue().toString());

					}
					if (mapEntry.getKey().equals("userid")) {
						saleRecordDto
								.setUser_id(mapEntry.getValue().toString());

					}
					if (mapEntry.getKey().equals("received_lock_id")) {
						saleRecordDto.setId(new BigInteger(mapEntry.getValue()
								.toString()));
						received_lock_id = saleRecordDto.getId().toString();
					}
				}
				List<UpdateSaleDto> tributeSaleRecordDtoList;
				Object[] params1 = new Object[1];
				params1[0] = saleRecordDto.getId();

				tributeSaleRecordDtoList = findTributeSaleRecordByLockIdQryDao
						.excute(params1);
				if (!((tributeSaleRecordDtoList.isEmpty()) || (tributeSaleRecordDtoList == null))) {

					List<SaleLockDto> tributeSaleLockCheckDtoList;
					Object[] params2 = new Object[1];

					if ((tributeSaleRecordDtoList.get(0).original_id)
							.equalsIgnoreCase("0")) {
						params2[0] = tributeSaleRecordDtoList.get(0).id;
					} else {
						params2[0] = tributeSaleRecordDtoList.get(0)
								.getOriginal_id();
					}
					tributeSaleLockCheckDtoList = findTributeExistLockByIdQryDao
							.excute(params2);
					if (!((tributeSaleLockCheckDtoList.isEmpty()) || (tributeSaleLockCheckDtoList == null))) {
						String machine_type = tributeSaleLockCheckDtoList
								.get(0).machine_type.trim();
						String saleMachine_type = saleRecordDto
								.getMachine_type().trim();

						if ((machine_type.equalsIgnoreCase(saleMachine_type))
								&& ((tributeSaleLockCheckDtoList.get(0).machine
										.trim()).equals(saleRecordDto
										.getMachine().trim()) && (tributeSaleLockCheckDtoList
										.get(0).user_id.trim())
										.equals(saleRecordDto.getUser_id()
												.trim()))) {
							// Sending output XML containing confirmation ID of
							// the locked record in sale_lock table.
							if (logger.isInfoEnabled()) {
								logger.info("Tribute record for Lock Sale already exists with id "
										+ saleRecordDto.getId());
							}
							output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation ID=\""
									+ received_lock_id
									+ "\"><Errors></Errors><Warnings></Warnings></Confirmation>";
						} else {
							// Sending error XML as output
							logger.log(
									AVFLoggerLevel.Exception,
									"Error while creating Tribute record for Lock Sale due to Sale locked by  another user"
											+ saleRecordDto.getId());
							output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
									+ "<code>03</code><desc>Sale locked by  another user</desc>"
									+ "</Error></Errors><Warnings></Warnings></Confirmation>";
						}
					} else {
						saleRecordDto.setId(new BigInteger((params2[0])
								.toString()));

						int result = createSaleLockRecordQryDao
								.insert(saleRecordDto);
						// Sending output XML containing confirmation ID of the
						// locked record in sale_lock table.
						if (logger.isInfoEnabled()) {
							logger.info("Tribute record for Lock Sale successfully created with id "
									+ saleRecordDto.getId());
						}
						output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation ID=\""
								+ received_lock_id
								+ "\"><Errors></Errors><Warnings></Warnings></Confirmation>";
					}
				} else {
					// sending response as error XML.
					logger.log(
							AVFLoggerLevel.Exception,
							"Error while creating Tribute record for Lock Sale since Sale Not found for "
									+ saleRecordDto.getId());
					output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
							+ "<code>02</code><desc>Sale Not found</desc>"
							+ "</Error></Errors><Warnings></Warnings></Confirmation>";
				}
			} else {
				// sending response as error XML.
				logger.log(
						AVFLoggerLevel.Exception,
						"Error while creating Tribute record for Lock Sale since Input message is in invalid format for "
								+ saleRecordDto.getId());
				output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
						+ "<code>01</code><desc>Input message is in invalid format</desc>"
						+ "</Error></Errors><Warnings></Warnings></Confirmation>";
			}
		} catch (DataAccessException e) {
			// Sending error XML as output
			logger.log(AVFLoggerLevel.Exception,
					"Error while creating Tribute record for Lock Sale for "
							+ e);
			output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
					+ "<code>98</code><desc>\""
					+ e.getMessage()
					+ "\"</desc></Error></Errors><Warnings></Warnings></Confirmation>";
		} catch (Exception e) {
			// Sending error XML as output
			logger.log(AVFLoggerLevel.Exception,
					"Error while creating Tribute record for lock Sale for "
							+ e);
			output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
					+ "<code>99</code><desc>Unexpected system failure</desc>"
					+ "</Error></Errors><Warnings></Warnings></Confirmation>";
		}
		return output_xml;
	}

	/**
	 * This method is a helper to process Tribute request for UnLock Sale. First
	 * scan parameters are validated and then Dal classes are used to unlock the
	 * incoming scan record.The success or error response is sent in String
	 * format. The record is deleted from Sale_lock table if locked.
	 * 
	 * @author Sudha Parab
	 * @throws DataAccessException
	 * @createdate 17-Aug-2012
	 */
	public String unlockSale(TributeInsertSaleRequest tributeInsertSaleRequest,
			long incomingRequestId) {
		String output_xml = null;
		String received_id = "";
		SaleRecordDto saleRecordDto = new SaleRecordDto();
		UpdateSaleDto updateSaleDto = new UpdateSaleDto();
		String inputXml = tributeInsertSaleRequest.getInputxml();
		TributeUnlockSaleParser tributeUnlockSaleParser = new TributeUnlockSaleParser();
		Map lockSaleMap = tributeUnlockSaleParser.parseUnLockInput(inputXml);

		if (!(lockSaleMap == null)) {
			if (!(lockSaleMap.isEmpty())) {
				try {

					Iterator iterator = lockSaleMap.entrySet().iterator();
					while (iterator.hasNext()) {
						Map.Entry mapEntry = (Map.Entry) iterator.next();

						if (mapEntry.getKey().equals("machine_type")) {
							saleRecordDto.setMachine_type(mapEntry.getValue()
									.toString());

						}
						if (mapEntry.getKey().equals("machine")) {
							saleRecordDto.setMachine(mapEntry.getValue()
									.toString());

						}
						if (mapEntry.getKey().equals("userid")) {
							saleRecordDto.setUser_id(mapEntry.getValue()
									.toString());

						}
						if (mapEntry.getKey().equals("received_unlock_id")) {
							saleRecordDto.setId(new BigInteger(mapEntry
									.getValue().toString()));
							received_id = saleRecordDto.getId().toString();

						}
					}

					List<UpdateSaleDto> tributeFindOriginalIdList;
					Object[] original = new Object[1];
					original[0] = saleRecordDto.getId();
					tributeFindOriginalIdList = findTributeSaleRecordByIdQryDao
							.execute12(original);

					List<SaleLockDto> tributeLockedRecordDtoList;
					Object[] params = new Object[1];

					if ((tributeFindOriginalIdList.get(0).original_id)
							.equalsIgnoreCase("0")) {
						params[0] = tributeFindOriginalIdList.get(0).id;
					} else {
						params[0] = tributeFindOriginalIdList.get(0)
								.getOriginal_id();
					}

					tributeLockedRecordDtoList = findTributeLockedRecordsByIdQryDao
							.excute(params);
					if (!(tributeLockedRecordDtoList.isEmpty())) {
						if (!(tributeLockedRecordDtoList == null)) {
							if ((saleRecordDto.getMachine_type().trim()
									.equalsIgnoreCase(tributeLockedRecordDtoList
											.get(0).machine_type.trim()))
									&& (saleRecordDto.getMachine().trim())
											.equalsIgnoreCase(tributeLockedRecordDtoList
													.get(0).machine.trim())
									&& (saleRecordDto.getUser_id().trim())
											.equalsIgnoreCase(tributeLockedRecordDtoList
													.get(0).user_id.trim())) {

								int result = deleteTributeSaleLockRecordByIdQryDao
										.delete(params);

								// Sending output XML containing confirmation ID
								// of the unlocked record.
								if (logger.isInfoEnabled()) {
									logger.info("Tribute record for Unlocked Sale with id "
											+ received_id);
								}
								output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation ID=\""
										+ received_id
										+ "\"><Errors></Errors><Warnings></Warnings></Confirmation>";
							} else {
								// Sending error XML as output
								logger.log(
										AVFLoggerLevel.Exception,
										"Error while creating Tribute record for UnLock Sale due to Sale locked by  another user"
												+ saleRecordDto.getId());
								output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors></Errors><Warnings><Warning>"
										+ "<code>03</code><desc>Sale locked by another user"
										+ "</desc></Warning></Warnings></Confirmation>";

							}
						} else {
							// Sending error XML as output
							logger.log(
									AVFLoggerLevel.Exception,
									"Error while creating Tribute record for UnLock Sale since Sale Not found for "
											+ saleRecordDto.getId());
							output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
									+ "<code>02</code><desc>Sale not found"
									+ "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
						}
					} else {
						// Sending error XML as output
						logger.log(
								AVFLoggerLevel.Exception,
								"Error while creating Tribute record for UnLock Sale since Sale Not found for "
										+ saleRecordDto.getId());
						output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
								+ "<code>02</code><desc>Sale not found"
								+ "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
					}

				} catch (DataAccessException e) {
					// Sending error XML as output
					logger.log(
							AVFLoggerLevel.Exception,
							"Error while creating Tribute record for UnLock Sale for "
									+ e);
					return output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
							+ "<code>99</code><desc>Unexpected system failure"
							+ "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
				} catch (Exception e) {
					// Sending error XML as output
					logger.log(
							AVFLoggerLevel.Exception,
							"Error while creating Tribute record for UnLock Sale for "
									+ e);
					output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
							+ "<code>98</code><desc>\""
							+ e.getMessage()
							+ "\"</desc></Error></Errors><Warnings></Warnings></Confirmation>";
				}

			} else {
				// Sending output XML containing error when incoming XML in
				// invalid format.
				logger.log(
						AVFLoggerLevel.Exception,
						"Error while creating Tribute record for Unlock Sale since Input message is in invalid format");
				output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
						+ "<code>01</code><desc>Input message is in invalid format."
						+ "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
			}
		} else {
			// Sending output XML containing error when incoming XML in invalid
			// format.
			logger.log(
					AVFLoggerLevel.Exception,
					"Error while creating Tribute record for Unlock Sale since Input message is in invalid format");
			output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
					+ "<code>01</code><desc>Input message is in invalid format."
					+ "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
		}
		return output_xml;
	}

	/**
	 * This method is a helper to scan Avf ticket. First scan parameters are
	 * validated and then Dal classes are used to insert scan record.JSON is
	 * used to send success or error response.
	 * 
	 * @author Kishor Agrawal
	 * @throws TributeParserException
	 * @createdate 23-Dec-2009
	 */
	public JSONObject autounlockSale(
			TributeInsertSaleRequest tributeInsertSaleRequest,
			long incomingRequestId) {

		SaleRecordDto saleRecordDto = new SaleRecordDto();

		String inputXml = tributeInsertSaleRequest.getInputxml();

		saleRecordDto.setMachine_type("A");
		saleRecordDto.setMachine("b");
		saleRecordDto.setUser_id("ab");
		saleRecordDto.setSale(inputXml);

		int result = CreateTributeSaleRecordQryDao.insert(saleRecordDto);

		JSONObject responseObject = new JSONObject();

		if (result == 1) {
			return responseObject = generateJSONOutput(TRIBUTE_SALE_ERROR_CODE_ENUM.TRIBUTE_SALE_SUCCESS);
		} else {
			logger.log(
					AVFLoggerLevel.Exception,
					"Incoming Request= "
							+ incomingRequestId
							+ " for TributeSale encountered error while inserting record in TRIBUTE_SALE for"
							+ " SALE " + saleRecordDto.getSale());
			return responseObject = generateJSONOutput(TRIBUTE_SALE_ERROR_CODE_ENUM.TRIBUTE_SALE_FAILURE);

		}

	}

	/**
	 * This method is a helper to process Tribute request for Search Sale. First
	 * scan parameters are validated and then Dal classes are used to search the
	 * incoming scan record.The success or error response is sent in String
	 * format. The record is searched from all tables depending upon the
	 * combination of input parameters.
	 * 
	 * @author Sudha Parab
	 * @throws DataAccessException
	 * @createdate 17-Aug-2012
	 */
	public String searchSale(TributeInsertSaleRequest tributeInsertSaleRequest, long incomingRequestId) {
		logger.debug("searchSale method called!");
		SaleRecordDto saleRecordDto = new SaleRecordDto();
		int result = 0;
		String output_xml = "";
		String inputXml = tributeInsertSaleRequest.getInputxml();
		String machine_no = null;
		String issue_date = null;
		String transaction_no = null;
		String ctr_refer = null;
		String refund_refer = null;
		String surname = null;
		String postcode = null;
		String status = null;
		String machine_type = null;
		String machine = null;
		String user_id = null;
		String travel_date = null;
		String isrn = null;
		String ipeInstanceId = null;
		String sale_data = "";
		String business_groups = null;
		String refundStartDateTime = null;
		String refundEndDateTime = null;
		String contactBookingReference = null;
		List tempList = new ArrayList();
		long cid;
		TributeSearchSaleParser tributeSearchSaleParser = new TributeSearchSaleParser();
		Map<String, String> map = tributeSearchSaleParser.parseSearchInput(inputXml);
		try {
		   if (MapUtils.isNotEmpty(map)) {
				Iterator iterator = map.entrySet().iterator();
				while (iterator.hasNext()) {
					Map.Entry mapEntry = (Map.Entry) iterator.next();

					if (mapEntry.getKey().equals("machine_type")) {
						machine_type = mapEntry.getValue().toString();
					}

					if (mapEntry.getKey().equals("machine")) {
						machine = mapEntry.getValue().toString();
					}
					if (mapEntry.getKey().equals("userid")) {
						user_id = mapEntry.getValue().toString();
					}
					if (mapEntry.getKey().equals("machine_no")) {
						machine_no = mapEntry.getValue().toString();
					}
					if (mapEntry.getKey().equals("issue_date")) {
						issue_date = mapEntry.getValue().toString();
					}
					if (mapEntry.getKey().equals("transaction_no")) {
						transaction_no = mapEntry.getValue().toString();
					}
					if (mapEntry.getKey().equals("ctr_refer")) {
						ctr_refer = mapEntry.getValue().toString();
					}
					if (mapEntry.getKey().equals("surname")) {
						surname = mapEntry.getValue().toString();
					}
					if (mapEntry.getKey().equals("postcode")) {
						postcode = mapEntry.getValue().toString();
					}
					if (mapEntry.getKey().equals("refund_refer")) {
						refund_refer = mapEntry.getValue().toString();
					}
					if (mapEntry.getKey().equals("status")) {
						status = mapEntry.getValue().toString();
						if (StringUtils.contains(status, ",")) {
							String[] statusArray = StringUtils.split(mapEntry.getValue().toString(), ',');
							if(statusArray.length > 0) {
								String quote = "'";
								String temp = StringUtils.rightPad(StringUtils.join(statusArray, "', '"), 1, quote);
								status = StringUtils.leftPad(temp, 1, quote);
							}
						}
					}
					if (mapEntry.getKey().equals("travel_date")) {
						travel_date = mapEntry.getValue().toString();
					}
					if(mapEntry.getKey().equals("businessGroupsString")) {
						String[] bgArray = StringUtils.split(mapEntry.getValue().toString(), ',');
						if(bgArray.length > 0) {
							String quote = "'";
							String temp = StringUtils.rightPad(StringUtils.join(bgArray, "', '"), 1, quote);
							business_groups = StringUtils.leftPad(temp, 1, quote);
						}
					}
					if(mapEntry.getKey().equals("refundStartDateTime")) {
						refundStartDateTime = mapEntry.getValue().toString();
					}
					if(mapEntry.getKey().equals("refundEndDateTime")) {
						refundEndDateTime = mapEntry.getValue().toString();
					}
					
					if (mapEntry.getKey().equals("isrn")) {
						isrn = mapEntry.getValue().toString();
					}
					if (mapEntry.getKey().equals("ipeInstanceId")) {
						ipeInstanceId = mapEntry.getValue().toString();
					}
					if (mapEntry.getKey().equals("contactBookingReference")) {
						contactBookingReference = mapEntry.getValue().toString();
					}
					

				}

				List<SaleRecordDto> tributeSaleKeysList = null, saleListForContactBookingRef = null;
				Object[] params = new Object[8];

				if (machine_no != null && issue_date != null
						&& transaction_no != null) {
					params[0] = machine_no;
					params[1] = issue_date;
					params[2] = transaction_no;
					tributeSaleKeysList = findTributeSearchSaleTKeysQryDao
							.execute(params);
				}
				else if(refundStartDateTime != null && refundEndDateTime != null) {
					params[0] = refundStartDateTime;
					params[1] = refundEndDateTime;
					params[2] = status;
					params[3] = refund_refer;
					params[4] = surname;
					params[5] = postcode;
					params[6] = business_groups;
					tributeSaleKeysList = findTributeSearchSaleQryDao
							.execute(params);

				} else if (ctr_refer != null) {
					params[0] = ctr_refer;

					tributeSaleKeysList = findTributeSearchSaleCKeysQryDao
							.execute(params);
				} else if (refund_refer != null) {
					params[0] = refund_refer;
					tributeSaleKeysList = findTributeSearchSaleRKeysQryDao
							.execute(params);
				} else if ((surname != null) && (postcode != null)) {

					params[0] = surname;
					params[1] = postcode;
					params[2] = status;
					tributeSaleKeysList = findTributeSearchSaleNPRkeysQryDao
							.execute(params);
				} else if (surname != null) {
					params[0] = surname;
					params[1] = status;
					tributeSaleKeysList = findTributeSearchSaleNRkeysQryDao
							.execute(params);
				} else if (postcode != null) {
					params[0] = postcode;
					params[1] = status;
					tributeSaleKeysList = findTributeSearchSalePRkeysQryDao
							.execute(params);

				} else if(isrn != null || ipeInstanceId != null) {
					params[0] = isrn;
					params[1] = ipeInstanceId;
				tributeSaleKeysList = findTributeSearchSaleTKeysForISRNIPEQryDao
						.execute(params);
				}
				else if(StringUtils.isNotBlank(contactBookingReference)) {
					params[0] = Long.parseLong(contactBookingReference);
					saleListForContactBookingRef = findTributeSearchSaleForContactBookingRefQryDao.execute(params);
				}
				else {
					// Sending output XML containing error when incoming XML in
					// invalid format.
					logger.log(
							AVFLoggerLevel.Exception,
							"Error while creating Tribute record for Search Sale since Input message is in invalid format");

					return generateErrorXML("01",
							"Input message is invalid format");
				}
				
				if (CollectionUtils.isNotEmpty(tributeSaleKeysList)) {

					// Locking record if single sale is found.
					if (tributeSaleKeysList.size() == 1) {
						BigInteger sale_id = (tributeSaleKeysList.get(0).cid);
						List<UpdateSaleDto> tributeSaleRecordDtoList;
						Object[] params1 = new Object[1];
						params1[0] = sale_id;

						tributeSaleRecordDtoList = findTributeSaleRecordByLockIdQryDao
								.excute(params1);

						if (tributeSaleRecordDtoList != null
								&& !(tributeSaleRecordDtoList.isEmpty())) {

							List<SaleRecordDto> sale_list = new ArrayList<SaleRecordDto>();

							// start CR037 changes
							sale_list = findBarcodeDataQryDao.execute(sale_id);
							sale_data = tributeSaleRecordDtoList.get(0).sale;
							if (CollectionUtils.isNotEmpty(sale_list)) {

								// convert sale data into sale DOM object
								Document doc = convertStringToDocument(sale_data);
								for (int i = 0; i < sale_list.size(); i++) {
									List<AvfScanDto> ticketScan_list = new ArrayList<AvfScanDto>();

									String transactionNumber = sale_list.get(i)
											.getTransaction_number();

									ticketScan_list = findBarcodeTicketScanByTicketingRecordQryDao
											.execute(sale_list.get(i)
													.getTicketingRecordId());

									if (ticketScan_list != null) {
										// append ticketscan records in tickets
										doc = appendSaleXML(doc,
												ticketScan_list,
												transactionNumber);
									}

								}
								// convert sale DOM object into sale data
								sale_data = convertDocumentToString(doc);
							}
							saleRecordDto
									.setId(tributeSaleRecordDtoList.get(0).id);

							saleRecordDto.setSale(sale_data);
						} else {

							saleRecordDto
									.setId(tributeSaleRecordDtoList.get(0).id);
							saleRecordDto.setSale(tributeSaleRecordDtoList
									.get(0).sale);
						}
						/*
						 * output_xml =
						 * "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Result><ID>"
						 * + saleRecordDto.getId() + "</ID>" +
						 * saleRecordDto.getSale() +
						 * "</Result><Errors></Errors><Warnings></Warnings></Confirmation>"
						 * ;
						 */
						return generateOutputXML(saleRecordDto.getId()
								.toString(), saleRecordDto.getSale());

					}

					// Sending Confirmation ID for multiple sales retreived
					// from search.
					else {
						for (int i = 0; i < tributeSaleKeysList.size(); i++) {
							cid = new Long(
									(tributeSaleKeysList.get(i).getCid())
											.toString());
							tempList.add(cid);
							tempList = new ArrayList(
									new LinkedHashSet(tempList));
						}
						List<String> saledtolist = new ArrayList<String>();

						for (int i = 0; i < tempList.size(); i++) {
							Object[] params3 = new Object[1];

							BigInteger sale_id = new BigInteger(tempList.get(i)
									.toString());

							params3[0] = tempList.get(i);
							List<SaleRecordDto> saledtolist1 = null;
							saledtolist1 = findTributeSaleXmlQryDao
									.execute(params3);

							if (CollectionUtils.isNotEmpty(saledtolist1)) {

								List<SaleRecordDto> sale_list = new ArrayList<SaleRecordDto>();

								// start CR037 changes
								sale_list = findBarcodeDataQryDao
										.execute(sale_id);
								sale_data = saledtolist1.get(0).sale;
								if (sale_list != null && !(sale_list.isEmpty())) {

									// convert sale data into sale DOM object
									Document doc = convertStringToDocument(sale_data);
									for (int j = 0; j < sale_list.size(); j++) {
										List<AvfScanDto> ticketScan_list = new ArrayList<AvfScanDto>();

										String transactionNumber = sale_list
												.get(j).getTransaction_number();

										ticketScan_list = findBarcodeTicketScanByTicketingRecordQryDao
												.execute(sale_list.get(j)
														.getTicketingRecordId());

										if (ticketScan_list != null) {
											// add ticketscan in tickets
											doc = appendSaleXML(doc,
													ticketScan_list,
													transactionNumber);
										}
									}
									// convert sale DOM object into sale data
									sale_data = convertDocumentToString(doc);
								}

								saledtolist.add(sale_data);
							} else {

								saledtolist.add(saledtolist1.get(0).getSale());
							}
						}

						// output_xml =
						// "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation>";
						for (int i = 0; i < tempList.size(); i++) {
							if (logger.isInfoEnabled()) {
								// Sending output XML containing
								// confirmation ID of the updated record
								// created in sale table.
								logger.info("Tribute IncomingRequest record for Search Sale successfully found with id "
										+ tempList.get(i));
							}
							/*
							 * output_xml += "<Result><ID>" + tempList.get(i) +
							 * "</ID>" + saledtolist.get(i) + "</Result>";
							 */
						}
						// output_xml +=
						// "<Errors></Errors><Warnings></Warnings></Confirmation>";
						return generateOutputXML(tempList, saledtolist);
					}

				} else if(CollectionUtils.isNotEmpty(saleListForContactBookingRef)) {
					return getSaleDataForSearchCriteria(saleListForContactBookingRef); 
				} else {
					// sending response as error XML.
					logger.log(
							AVFLoggerLevel.Exception,
							"Warning while creating Tribute IncomingRequest record after Search since Sale Not found for "
									+ saleRecordDto.getId());

					return generateWarningXML("04", "No Matching sales found.");
				}
		   } else {
			// Sending output XML containing error when incoming XML in invalid
			// format.
			logger.log(
					AVFLoggerLevel.Exception,
					"Error while creating Tribute record for Search Sale since Input message is in invalid format");
			return generateErrorXML("01", "Input message is in invalid format");
		   }
		
		} catch (DataAccessException e) {
			// Sending error XML as output
			logger.log(AVFLoggerLevel.Exception,
					"Error while creating Tribute record for Search Sale"
							+ e);
			return generateErrorXML("98", e.getMessage());
		} catch (Exception e) {
			// Sending error XML as output
			logger.log(AVFLoggerLevel.Exception,
					"Error while creating Tribute record for Search Sale"
							+ e);

			return generateErrorXML("99", "Unexpected system failure");
		} finally {
			map = null;
			tempList = null;
		}

	}

	/**
	 * This method is a helper to process Tribute request for generateReference
	 * Sale. First scan parameters are validated and then Dal classes are used
	 * to generateReference for the incoming scan record.The success or error
	 * response is sent in String format. The refund reference ID is generated
	 * for incoming request.
	 * 
	 * @author Sudha Parab
	 * @throws DataAccessException
	 * @createdate 17-Aug-2012
	 */
	/**
	 * @param tributeInsertSaleRequest
	 * @return refund_reference
	 */

	public synchronized String generateReference(TributeInsertSaleRequest tributeInsertSaleRequest) {

		String outputXml = null;
		String businessCode = null;
		String tisType = null;
		String inputXml = tributeInsertSaleRequest.getInputxml();
		TributeGenerateReferenceParser tributeGenerateReferenceParser = new TributeGenerateReferenceParser();
		Map<String, String> generateReferenceMap = tributeGenerateReferenceParser.parseInput(inputXml);

		if (MapUtils.isNotEmpty(generateReferenceMap)) {
			try {
				businessCode = generateReferenceMap.get("business_code");
				tisType = generateReferenceMap.get("tis_type");
				// Fetch Refund Reference from Database
				String generatedReference = updateAndFetchRefundReferenceDao.getRefundReference(businessCode, tisType);
				// Return Refund Reference
				outputXml =  XMLELEMENT + generatedReference
						+ "\"><Errors></Errors><Warnings></Warnings></Confirmation>";

				if (logger.isInfoEnabled())
					logger.info("Tribute record for Generate Reference successfully created with id " + generatedReference);

			} catch (DataAccessException e) {
				// Sending error XML as output
				logger.log(AVFLoggerLevel.Exception, "Error while creating Tribute record for Generate Reference" + e);
				outputXml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
						+ "<code>98</code><desc>\"" + e.getMessage()
						+ "\"</desc></Error></Errors><Warnings></Warnings></Confirmation>";
				return outputXml;
			} catch (Exception e) {
				// Sending error XML as output
				logger.log(AVFLoggerLevel.Exception,
						"Error while creating Tribute record for Generate Reference Sale" + e);
				outputXml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
						+ "<code>98</code><desc>\"" + e.getMessage()
						+ "\"</desc></Error></Errors><Warnings></Warnings></Confirmation>";
				return outputXml;
			}
		} else {
			// Return Invalid input 
			logger.log(AVFLoggerLevel.Exception,"Error while creating Tribute record for Generate Reference Sale since Input message is in invalid format");
			return "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
					+ "<code>01</code><desc>Input message is in invalid format."
					+ "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
		}
		return outputXml;
	}

	/**
	 * This method is a helper to process Tribute request for NonIssue Sale.
	 * First scan parameters are validated and then Dal classes are used to get
	 * NonIssue elements from the incoming scan record.The success or error
	 * response is sent in String format.
	 * 
	 * @author Sudha Parab
	 * @throws DataAccessException
	 * @createdate 17-Aug-2012
	 */
	/**
	 * @param tributeInsertSaleRequest
	 * @param incomingRequestId
	 * @return confirmation ID
	 */
	public String nonIssueSale(
			TributeInsertSaleRequest tributeInsertSaleRequest,
			long incomingRequestId) {

		String output_xml = "";

		SaleRecordDto saleRecordDto = new SaleRecordDto();

		String inputXml = tributeInsertSaleRequest.getInputxml();
		String xml;
		int result;
		String nonIssue = "";
		TributeNonIssueSaleParser tributeNonIssueSaleParser = new TributeNonIssueSaleParser();
		Map nonIssueSaleMap = tributeNonIssueSaleParser.parseInput(inputXml);
		if (MapUtils.isNotEmpty(nonIssueSaleMap)) {
			try {
				Iterator iterator = nonIssueSaleMap.entrySet().iterator();
				while (iterator.hasNext()) {
					Map.Entry mapEntry = (Map.Entry) iterator.next();

					if (mapEntry.getKey().equals("machine_number")) {
						saleRecordDto
								.setMachine(mapEntry.getValue().toString());
					}
					if (mapEntry.getKey().equals("issue_date")) {
						saleRecordDto.setIssue_date(mapEntry.getValue()
								.toString());
					}
					if (mapEntry.getKey().equals("transaction_no")) {
						saleRecordDto.setTransaction_number(mapEntry.getValue()
								.toString());
					}
				}
				List<TributeNonIssueSaleDto> tributeNonIssueSaleDtoList;
				Object[] params = new Object[3];
				params[0] = saleRecordDto.getMachine();
				params[1] = saleRecordDto.getIssue_date();
				params[2] = saleRecordDto.getTransaction_number();
				tributeNonIssueSaleDtoList = findTributeSaleIdByNonIssueElementQryDao
						.execute(params);

				if (CollectionUtils.isNotEmpty(tributeNonIssueSaleDtoList)) {

					List<SaleRecordDto> tributeSaleRecordOfNonIssueDtoList;
					Object[] params1 = new Object[1];
					params1[0] = tributeNonIssueSaleDtoList.get(0).getSale_id();
					tributeSaleRecordOfNonIssueDtoList = findTributeSaleRecordByNonIssueIdQryDao
							.execute(params1);
					if (CollectionUtils.isNotEmpty(tributeSaleRecordOfNonIssueDtoList)) {
						Object[] params2 = new Object[1];
							if (StringUtils.equals(tributeSaleRecordOfNonIssueDtoList.get(0).getOriginal_id(), "0")){
							params2[0] = tributeSaleRecordOfNonIssueDtoList
									.get(0).getId();
						} else {
							params2[0] = tributeSaleRecordOfNonIssueDtoList
									.get(0).getOriginal_id();
						}
						List<SaleLockDto> tributeSaleLockRecordDtoList = findTributeSaleLockByNonIssueIdQryDao
								.execute(params2);
						if (CollectionUtils.isNotEmpty(tributeSaleLockRecordDtoList)) {
							// Sending error XML as output
							logger.log(
									AVFLoggerLevel.Exception,
									"Error while creating Tribute record for NonIssue Sale while locking due to Sale locked by another user for "
											+ params2[0]);
							return output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
									+ "<code>03</code><desc>Sale locked by another user"
									+ "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
						}
						/*
						 * Change for QC 467
						 */
						else {

							Object[] paramsXml = new Object[1];
							paramsXml[0] = tributeSaleRecordOfNonIssueDtoList
									.get(0).getId();
							List<SaleRecordDto> saleRecordDtoXml = findTributeSaleXmlQryDao
									.execute(paramsXml);

							xml = saleRecordDtoXml.get(0).getSale();

							// appending the tag <NonIssue> from Incoming
							// requset XML to Sale XML stored in Sale table

							DocumentBuilderFactory dbf = DocumentBuilderFactory
									.newInstance();
							DocumentBuilder db = dbf.newDocumentBuilder();
							Document document = db.parse(new InputSource(
									new StringReader(inputXml)));
							Element rootelement = document.getDocumentElement();

							NodeList nodeList = document
									.getElementsByTagName("NonIssue");

							if (nodeList != null && nodeList.getLength() > 0) {

								for (int i = 0; i < nodeList.getLength(); i++) {

									Node node = nodeList.item(i);
									if (node.hasChildNodes()) {

										Element el = (Element) nodeList.item(i);

										for (int j = 0; j < el.getChildNodes()
												.getLength(); j++) {
											String nodeName = el
													.getChildNodes().item(j)
													.getNodeName();
											
											String textVal = null;
											NodeList nl = el
													.getElementsByTagName(nodeName);
											if (nl != null
													&& nl.getLength() > 0) {
												Element element = (Element) nl
														.item(0);
												textVal = element
														.getFirstChild()
														.getNodeValue();
											}

											nonIssue += "<NonIssue><"
													+ nodeName + ">" + textVal
													+ "</" + nodeName
													+ "></NonIssue>";
										}
									} else if (inputXml.contains("</NonIssue>")) {

										nonIssue += inputXml
												.substring(
														StringUtils.ordinalIndexOf(inputXml, "<NonIssue", i+1),
														StringUtils.ordinalIndexOf(inputXml, "</NonIssue>", i+1) + 11);
									} else {

										nonIssue += inputXml.substring(
												StringUtils.ordinalIndexOf(inputXml, "<NonIssue", i+1),
												StringUtils.ordinalIndexOf(inputXml, "/>", i+1) + 2);
									}
								}

							}

							String outputxml = null;
							// Added for QC 467
							Object[] paramsId = new Object[1];
							paramsId[0] = tributeSaleRecordOfNonIssueDtoList
									.get(0).getId();
							if (xml.contains("</NonIssues>")) {
								int index = xml.indexOf("</NonIssues>");
								String s1 = xml.substring(0, index);

								String s2 = s1.concat(nonIssue);

								outputxml = s2.concat(xml.substring(index));
								saleRecordDto.setOriginal_id(String
										.valueOf(tributeNonIssueSaleDtoList
												.get(0).getSale_id()));
								saleRecordDto
										.setMachine_type(tributeSaleRecordOfNonIssueDtoList
												.get(0).machine_type);
								saleRecordDto
										.setMachine(tributeSaleRecordOfNonIssueDtoList
												.get(0).machine);
								saleRecordDto
										.setUser_id(tributeSaleRecordOfNonIssueDtoList
												.get(0).user_id);
								saleRecordDto.setBusiness_group(tributeSaleRecordOfNonIssueDtoList
										.get(0).getBusiness_group());
								saleRecordDto.setContact_booking_ref(tributeSaleRecordOfNonIssueDtoList
										.get(0).getContact_booking_ref());
								saleRecordDto.setSale(outputxml);

								result = CreateTributeSaleRecordQryDao
										.insert(saleRecordDto);

								saleRecordDto.setCid(new BigInteger(
										(paramsId[0]).toString()));

								// Qry to update the records in sale?keys tables
								// by updating their sale_id.
								result = updateTributeSaleCKeyQryDao
										.update(saleRecordDto);
								result = updateTributeSaleTKeyQryDao
										.update(saleRecordDto);
								result = updateTributeSalePKeyQryDao
										.update(saleRecordDto);
								result = updateTributeSaleNKeyQryDao
										.update(saleRecordDto);
								result = updateTributeSaleRKeyQryDao
										.update(saleRecordDto);
								result = updateSaleLkeysByIdQryDao
										.update(saleRecordDto);

								// Sending output XML containing confirmation ID
								// of the new record created in sale table by
								// appending the <nonissue> tag to sale xml.
								if (logger.isInfoEnabled()) {
									logger.info("Tribute record for NonIssue Sale successfully created with id "
											+ saleRecordDto.getId());
								}
								output_xml = XMLELEMENT
										+ saleRecordDto.getId()
										+ "\"><Errors></Errors><Warnings></Warnings></Confirmation>";
								return output_xml;

							} else if (xml.contains("<NonIssues/>")) {
								int index = xml.indexOf("<NonIssues/>");
								String s1 = xml.substring(0, index);

								String s2 = s1.concat("<NonIssues>" + nonIssue
										+ "</NonIssues>");

								outputxml = s2
										.concat(xml.substring(index + 12));
								saleRecordDto.setOriginal_id(String
										.valueOf(tributeNonIssueSaleDtoList
												.get(0).getSale_id()));
								saleRecordDto
										.setMachine_type(tributeSaleRecordOfNonIssueDtoList
												.get(0).machine_type);
								saleRecordDto
										.setMachine(tributeSaleRecordOfNonIssueDtoList
												.get(0).machine);
								saleRecordDto
										.setUser_id(tributeSaleRecordOfNonIssueDtoList
												.get(0).user_id);
								saleRecordDto.setBusiness_group(tributeSaleRecordOfNonIssueDtoList
												.get(0).getBusiness_group());
								saleRecordDto.setContact_booking_ref(tributeSaleRecordOfNonIssueDtoList
										.get(0).getContact_booking_ref());
								saleRecordDto.setSale(outputxml);

								result = CreateTributeSaleRecordQryDao
										.insert(saleRecordDto);

								saleRecordDto.setCid(new BigInteger(
										(paramsId[0]).toString()));

								// Qry to update the records in sale?keys tables
								// by updating their sale_id.
								result = updateTributeSaleCKeyQryDao
										.update(saleRecordDto);
								result = updateTributeSaleTKeyQryDao
										.update(saleRecordDto);
								result = updateTributeSalePKeyQryDao
										.update(saleRecordDto);
								result = updateTributeSaleNKeyQryDao
										.update(saleRecordDto);
								result = updateTributeSaleRKeyQryDao
										.update(saleRecordDto);
								result = updateSaleLkeysByIdQryDao
										.update(saleRecordDto);
								// Sending output XML containing confirmation ID
								// of the new record created in sale table by
								// appending the <nonissue> tag to sale xml.
								if (logger.isInfoEnabled()) {
									logger.info("Tribute record for NonIssue Sale successfully created with id "
											+ saleRecordDto.getId());
								}
								output_xml = XMLELEMENT
										+ saleRecordDto.getId()
										+ "\"><Errors></Errors><Warnings></Warnings></Confirmation>";
								return output_xml;
							}

							else {
								// Adding <NonIssues> tag in original xml and
								// all contents from incoming XML inside that
								// when Sale XML does not contain <NonIssues>
								int index = xml.indexOf("</Sale>");
								String s1 = xml.substring(0, index);

								String s2 = s1.concat("<NonIssues>" + nonIssue
										+ "</NonIssues>");

								outputxml = s2.concat(xml.substring(index));
								saleRecordDto.setOriginal_id(String
										.valueOf(tributeNonIssueSaleDtoList
												.get(0).getSale_id()));
								saleRecordDto
										.setMachine_type(tributeSaleRecordOfNonIssueDtoList
												.get(0).machine_type);
								saleRecordDto
										.setMachine(tributeSaleRecordOfNonIssueDtoList
												.get(0).machine);
								saleRecordDto
										.setUser_id(tributeSaleRecordOfNonIssueDtoList
												.get(0).user_id);
								saleRecordDto.setBusiness_group(tributeSaleRecordOfNonIssueDtoList
										.get(0).getBusiness_group());
								saleRecordDto.setContact_booking_ref(tributeSaleRecordOfNonIssueDtoList
										.get(0).getContact_booking_ref());
								saleRecordDto.setSale(outputxml);

								result = CreateTributeSaleRecordQryDao
										.insert(saleRecordDto);

								saleRecordDto.setCid(new BigInteger(
										(paramsId[0]).toString()));

								// Qry to update the records in sale?keys tables
								// by updating their sale_id.
								result = updateTributeSaleCKeyQryDao
										.update(saleRecordDto);
								result = updateTributeSaleTKeyQryDao
										.update(saleRecordDto);
								result = updateTributeSalePKeyQryDao
										.update(saleRecordDto);
								result = updateTributeSaleNKeyQryDao
										.update(saleRecordDto);
								result = updateTributeSaleRKeyQryDao
										.update(saleRecordDto);
								result = updateSaleLkeysByIdQryDao
										.update(saleRecordDto);
								// Sending output XML containing confirmation ID
								// of the new record created in sale table by
								// appending the <nonissue> tag to sale xml.
								if (logger.isInfoEnabled()) {
									logger.info("Tribute record for NonIssue Sale successfully created with id "
											+ saleRecordDto.getId());
								}
								output_xml = XMLELEMENT
										+ saleRecordDto.getId()
										+ "\"><Errors></Errors><Warnings></Warnings></Confirmation>";
								return output_xml;
							}

						}
					}
				} else {

					// Sending error XML as output
					logger.log(
							AVFLoggerLevel.Exception,
							"Error while creating Tribute record for NonIssue Sale  due to Sale not found for ");
					return output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
							+ "<code>02</code><desc>Sale not found"
							+ "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
				}

			} catch (DataAccessException e) {
				// Sending error XML as output
				logger.log(AVFLoggerLevel.Exception,
						"Error while creating Tribute record for NonIssue Sale"
								+ e);
				return output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
						+ "<code>98</code><desc>\""
						+ e.getMessage()
						+ "\"</desc></Error></Errors><Warnings></Warnings></Confirmation>";
			} catch (Exception e) {
				// Sending error XML as output
				logger.log(AVFLoggerLevel.Exception,
						"Error while creating Tribute record for NonIssue Sale"
								+ e);
				return output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
						+ "<code>99</code><desc>Unexpected system failure"
						+ "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
			}
		} else {
			// Sending output XML containing error when incoming XML in invalid
			// format.
			logger.log(
					AVFLoggerLevel.Exception,
					"Error while creating Tribute record for NonIssue Sale since Input message is in invalid format");
			return output_xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>"
					+ "<code>01</code><desc>Input message is in invalid format."
					+ "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
		}
		return output_xml;
	}

	/**
	 * This method generates the JSON success or error response for AVF scan
	 * update.
	 * 
	 * @author Kishor Agrawal
	 * @createdate 23-Dec-2009
	 */
	public JSONObject generateJSONOutput(TRIBUTE_SALE_ERROR_CODE_ENUM errorCode) {

		JSONObject tributeResponse = new JSONObject();
		tributeResponse.put("Code", errorCode.getValue());
		tributeResponse.put("Message", errorCode.getText());

		JSONObject responseObject = new JSONObject();

		responseObject.put("Error", tributeResponse);
		return responseObject;
	}

	/**
	 * This method is a helper method to parse the AVF scan date.
	 * 
	 * @author Kishor Agrawal
	 * @createdate 23-Dec-2009
	 */
	private Date parseSaleDate(String dateString) {
		Date result = new Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		try {
			result = format.parse(dateString);
		} catch (ParseException pe) {
			logger.log(AVFLoggerLevel.Exception,
					"Exception occured while parsing scanDate=" + dateString
							+ "in  validateScanParameter()", pe);
		}
		return result;
	}

	private static Document appendSaleXML(Document doc,
			List<AvfScanDto> ticketScanList, String transactionNumber) {

		try {
			NodeList nodeList = doc.getElementsByTagName("Ticket");

			for (int i = 0; i < nodeList.getLength(); i++) {
				Node cnode = nodeList.item(i);

				if (cnode.getNodeType() == Node.ELEMENT_NODE) {

					Element element = (Element) cnode;

					NodeList nodelistTransactionNumber = element
							.getElementsByTagName("TransactionNumber");
					if (nodelistTransactionNumber.getLength() != 0) {
						Element element3 = (Element) nodelistTransactionNumber
								.item(0);
						NodeList nodeTransactionNumber = element3
								.getChildNodes();
						if (nodeTransactionNumber.getLength() != 0) {

							String transaction_Number = nodeTransactionNumber
									.item(0).getNodeValue();

							if (transaction_Number
									.equalsIgnoreCase(transactionNumber)) {

								Element newElement = doc
										.createElement("TicketUsage");

								cnode.appendChild(newElement);

								Node cnodeT = (Node) newElement;

								for (int j = 0; j < ticketScanList.size(); j++) {
									Element newElementT = doc
											.createElement("TicketScan");
									cnodeT.appendChild(newElementT);

									Node cnodee = (Node) newElementT;

									Element newElement1 = doc
											.createElement("Location");
									cnodee.appendChild(newElement1);
									newElement1.setTextContent(ticketScanList
											.get(j).getLocationId());

									Element newElement2 = doc
											.createElement("DeviceId");
									cnodee.appendChild(newElement2);
									newElement2.setTextContent(ticketScanList
											.get(j).getDeviceId());

									Element newElement3 = doc
											.createElement("Reference");
									cnodee.appendChild(newElement3);
									newElement3.setTextContent(ticketScanList
											.get(j).getIssuerReference());

									Element newElement4 = doc
											.createElement("ScanDateTime");
									cnodee.appendChild(newElement4);
									newElement4.setTextContent(ticketScanList
											.get(j).getScanDate().toString());

									Element newElement5 = doc
											.createElement("Status");
									cnodee.appendChild(newElement5);
									newElement5.setTextContent(""); // TODO <--
																	// Fix
																	// Status

									Element newElement6 = doc
											.createElement("Direction");
									cnodee.appendChild(newElement6);
									newElement6.setTextContent(ticketScanList
											.get(j).getDirection() + "");

									Element newElement7 = doc
											.createElement("UserId");
									cnodee.appendChild(newElement7);
									newElement7.setTextContent(ticketScanList
											.get(j).getUserId());

									Element newElement8 = doc
											.createElement("Class");
									cnodee.appendChild(newElement8);
									newElement8.setTextContent(ticketScanList
											.get(j).getClassName());

									Element newElement9 = doc
											.createElement("Coach");
									cnodee.appendChild(newElement9);
									newElement9.setTextContent(ticketScanList
											.get(j).getCoachNumber());

									Element newElement10 = doc
											.createElement("Seat");
									cnodee.appendChild(newElement10);
									newElement10.setTextContent(ticketScanList
											.get(j).getSeatNumber());
								}
							}
						}

					} else {
						logger.debug("null string found for CTRReference value");
					}
				} else {
					logger.debug("null node found for CTRReference tag");
				}
			}

			return doc;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private static Document convertStringToDocument(String xmlStr) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		try {
			builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(new StringReader(
					xmlStr)));
			return doc;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private static String convertDocumentToString(Document doc) {
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer;
		try {
			transformer = tf.newTransformer();

			StringWriter writer = new StringWriter();
			transformer.transform(new DOMSource(doc), new StreamResult(writer));
			String output = writer.getBuffer().toString();
			return output;
		} catch (TransformerException e) {
			e.printStackTrace();
		}

		return null;
	}

	public static String generateWarningXML(String codeValue, String descValue) {
		try {

			DocumentBuilderFactory docFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();

			// Confirmation element
			Element rootElement = doc.createElement("Confirmation");
			doc.appendChild(rootElement);

			// Errors element
			Element errors = doc.createElement("Errors");
			rootElement.appendChild(errors);

			// Warnings element
			Element warnings = doc.createElement("Warnings");
			rootElement.appendChild(warnings);

			// Warning element
			Element warning = doc.createElement("Warning");
			warnings.appendChild(warning);

			// Code element
			Element code = doc.createElement("code");
			warning.appendChild(code);
			code.setTextContent(codeValue);

			// Description elements
			Element desc = doc.createElement("desc");
			warning.appendChild(desc);
			desc.setTextContent(descValue);

			return convertDocumentToString(doc);
		} catch (Exception e) {
			return e.getMessage();
		}
	}

	public static String generateErrorXML(String codeValue, String descValue) {
		try {

			DocumentBuilderFactory docFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();

			// Confirmation element
			Element rootElement = doc.createElement("Confirmation");
			doc.appendChild(rootElement);

			// Errors element
			Element errors = doc.createElement("Errors");
			rootElement.appendChild(errors);

			// Warnings element
			Element warnings = doc.createElement("Warnings");
			rootElement.appendChild(warnings);

			// Warning element
			Element error = doc.createElement("Error");
			errors.appendChild(error);

			// Code element
			Element code = doc.createElement("code");
			error.appendChild(code);
			code.setTextContent(codeValue);

			// Description elements
			Element desc = doc.createElement("desc");
			error.appendChild(desc);
			desc.setTextContent(descValue);

			return convertDocumentToString(doc);
		} catch (Exception e) {
			return e.getMessage();
		}
	}

	private static String generateOutputXML(String codeValue, String descValue) {
		Document doc;

		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			doc = docBuilder.newDocument();
			// Confirmation element
			Element rootElement = doc.createElement("Confirmation");
			doc.appendChild(rootElement);

			// Result element
			Element result = doc.createElement("Result");
			rootElement.appendChild(result);

			// ID element
			Element id = doc.createElement("ID");
			result.appendChild(id);
			id.setTextContent(codeValue);

			// Convert String to document and append as child element
			Document newDoc = docBuilder.parse(new InputSource(
					new StringReader(descValue)));
			Element sale = newDoc.getDocumentElement();
			result.appendChild(doc.importNode(sale, true));

			// Errors element
			Element errors = doc.createElement("Errors");
			rootElement.appendChild(errors);
			// Warnings element
			Element warnings = doc.createElement("Warnings");
			rootElement.appendChild(warnings);

			return convertDocumentToString(doc);

		} catch (Exception e) {
			return e.getMessage();
		}

	}

	private static String generateOutputXML(List idList, List saleList) {
		Document doc;

		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			doc = docBuilder.newDocument();
			// Confirmation element
			Element rootElement = doc.createElement("Confirmation");
			doc.appendChild(rootElement);

			// Result element
			for (int i = 0; i < saleList.size(); i++) {
				Element result = doc.createElement("Result");
				rootElement.appendChild(result);

				// ID element
				Element id = doc.createElement("ID");
				result.appendChild(id);
				id.setTextContent(idList.get(i).toString());

				// Convert String to document and append as child element
				Document newDoc = docBuilder.parse(new InputSource(
						new StringReader(saleList.get(i).toString())));
				Element sale = newDoc.getDocumentElement();
				result.appendChild(doc.importNode(sale, true));
			}

			// Errors element
			Element errors = doc.createElement("Errors");
			rootElement.appendChild(errors);
			// Warnings element
			Element warnings = doc.createElement("Warnings");
			rootElement.appendChild(warnings);

			return convertDocumentToString(doc);

		} catch (Exception e) {
			return e.getMessage();
		}

	}

	public static String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();

		if (child instanceof CharacterData) {

			CharacterData cd = (CharacterData) child;
			return cd.getData();
		}
		return null;
	}

	/**
	 * @return the createTributeSaleRecordQryDao
	 */
	public CreateTributeSaleRecordQry getCreateTributeSaleRecordQryDao() {
		return CreateTributeSaleRecordQryDao;
	}

	/**
	 * @param createTributeSaleRecordQryDao
	 *            the createTributeSaleRecordQryDao to set
	 */
	public void setCreateTributeSaleRecordQryDao(
			CreateTributeSaleRecordQry createTributeSaleRecordQryDao) {
		CreateTributeSaleRecordQryDao = createTributeSaleRecordQryDao;
	}

	/**
	 * @return the createTributeRSaleKeysRecordQryDao
	 */
	public CreateTributeRSaleKeysRecordQry getCreateTributeRSaleKeysRecordQryDao() {
		return createTributeRSaleKeysRecordQryDao;
	}

	/**
	 * @param createTributeRSaleKeysRecordQryDao
	 *            the createTributeRSaleKeysRecordQryDao to set
	 */
	public void setCreateTributeRSaleKeysRecordQryDao(
			CreateTributeRSaleKeysRecordQry createTributeRSaleKeysRecordQryDao) {
		this.createTributeRSaleKeysRecordQryDao = createTributeRSaleKeysRecordQryDao;
	}

	/**
	 * @return the createTributeTSaleKeysRecordQryDao
	 */
	public CreateTributeTSaleKeysRecordQry getCreateTributeTSaleKeysRecordQryDao() {
		return createTributeTSaleKeysRecordQryDao;
	}

	/**
	 * @param createTributeTSaleKeysRecordQryDao
	 *            the createTributeTSaleKeysRecordQryDao to set
	 */
	public void setCreateTributeTSaleKeysRecordQryDao(
			CreateTributeTSaleKeysRecordQry createTributeTSaleKeysRecordQryDao) {
		this.createTributeTSaleKeysRecordQryDao = createTributeTSaleKeysRecordQryDao;
	}

	/**
	 * @return the createTributeRefundReferenceQryDao
	 */
	public CreateTributeRefundReferenceQry getCreateTributeRefundReferenceQryDao() {
		return CreateTributeRefundReferenceQryDao;
	}

	/**
	 * @param createTributeRefundReferenceQryDao
	 *            the createTributeRefundReferenceQryDao to set
	 */
	public void setCreateTributeRefundReferenceQryDao(
			CreateTributeRefundReferenceQry createTributeRefundReferenceQryDao) {
		CreateTributeRefundReferenceQryDao = createTributeRefundReferenceQryDao;
	}

	/**
	 * @return the findTributeRefundReferenceByCodeQryDao
	 */
	public FindTributeRefundReferenceByCodeQry getFindTributeRefundReferenceByCodeQryDao() {
		return findTributeRefundReferenceByCodeQryDao;
	}

	/**
	 * @param findTributeRefundReferenceByCodeQryDao
	 *            the findTributeRefundReferenceByCodeQryDao to set
	 */
	public void setFindTributeRefundReferenceByCodeQryDao(
			FindTributeRefundReferenceByCodeQry findTributeRefundReferenceByCodeQryDao) {
		this.findTributeRefundReferenceByCodeQryDao = findTributeRefundReferenceByCodeQryDao;
	}

	/**
	 * @return the updateTributeRefundReferenceQryDao
	 */
	public UpdateTributeRefundReferenceQry getUpdateTributeRefundReferenceQryDao() {
		return updateTributeRefundReferenceQryDao;
	}

	/**
	 * @param updateTributeRefundReferenceQryDao
	 *            the updateTributeRefundReferenceQryDao to set
	 */
	public void setUpdateTributeRefundReferenceQryDao(
			UpdateTributeRefundReferenceQry updateTributeRefundReferenceQryDao) {
		this.updateTributeRefundReferenceQryDao = updateTributeRefundReferenceQryDao;
	}

	/**
	 * @return the createTributeUpdateSaleRecordQryDao
	 */
	public CreateTributeUpdateSaleRecordQry getCreateTributeUpdateSaleRecordQryDao() {
		return createTributeUpdateSaleRecordQryDao;
	}

	/**
	 * @param createTributeUpdateSaleRecordQryDao
	 *            the createTributeUpdateSaleRecordQryDao to set
	 */
	public void setCreateTributeUpdateSaleRecordQryDao(
			CreateTributeUpdateSaleRecordQry createTributeUpdateSaleRecordQryDao) {
		this.createTributeUpdateSaleRecordQryDao = createTributeUpdateSaleRecordQryDao;
	}

	/**
	 * @return the deleteSaleCKeysByIdQryDao
	 */
	public DeleteSaleCKeysByIdQry getDeleteSaleCKeysByIdQryDao() {
		return deleteSaleCKeysByIdQryDao;
	}

	/**
	 * @param deleteSaleCKeysByIdQryDao
	 *            the deleteSaleCKeysByIdQryDao to set
	 */
	public void setDeleteSaleCKeysByIdQryDao(
			DeleteSaleCKeysByIdQry deleteSaleCKeysByIdQryDao) {
		this.deleteSaleCKeysByIdQryDao = deleteSaleCKeysByIdQryDao;
	}

	/**
	 * @return the deleteSaleNKeysByIdQryDao
	 */
	public DeleteSaleNKeysByIdQry getDeleteSaleNKeysByIdQryDao() {
		return deleteSaleNKeysByIdQryDao;
	}

	/**
	 * @param deleteSaleNKeysByIdQryDao
	 *            the deleteSaleNKeysByIdQryDao to set
	 */
	public void setDeleteSaleNKeysByIdQryDao(
			DeleteSaleNKeysByIdQry deleteSaleNKeysByIdQryDao) {
		this.deleteSaleNKeysByIdQryDao = deleteSaleNKeysByIdQryDao;
	}

	/**
	 * @return the deleteSalePKeysByIdQryDao
	 */
	public DeleteSalePKeysByIdQry getDeleteSalePKeysByIdQryDao() {
		return deleteSalePKeysByIdQryDao;
	}

	/**
	 * @param deleteSalePKeysByIdQryDao
	 *            the deleteSalePKeysByIdQryDao to set
	 */
	public void setDeleteSalePKeysByIdQryDao(
			DeleteSalePKeysByIdQry deleteSalePKeysByIdQryDao) {
		this.deleteSalePKeysByIdQryDao = deleteSalePKeysByIdQryDao;
	}

	/**
	 * @return the deleteSaleTKeysByIdQryDao
	 */
	public DeleteSaleTKeysByIdQry getDeleteSaleTKeysByIdQryDao() {
		return deleteSaleTKeysByIdQryDao;
	}

	/**
	 * @param deleteSaleTKeysByIdQryDao
	 *            the deleteSaleTKeysByIdQryDao to set
	 */
	public void setDeleteSaleTKeysByIdQryDao(
			DeleteSaleTKeysByIdQry deleteSaleTKeysByIdQryDao) {
		this.deleteSaleTKeysByIdQryDao = deleteSaleTKeysByIdQryDao;
	}

	/**
	 * @return the findTributeSaleRecordByIdQryDao
	 */
	public FindTributeSaleRecordByIdQry getFindTributeSaleRecordByIdQryDao() {
		return findTributeSaleRecordByIdQryDao;
	}

	/**
	 * @param findTributeSaleRecordByIdQryDao
	 *            the findTributeSaleRecordByIdQryDao to set
	 */
	public void setFindTributeSaleRecordByIdQryDao(
			FindTributeSaleRecordByIdQry findTributeSaleRecordByIdQryDao) {
		this.findTributeSaleRecordByIdQryDao = findTributeSaleRecordByIdQryDao;
	}

	/**
	 * @return the findTributeSaleRecordByLockIdQryDao
	 */
	public FindTributeSaleRecordByLockIdQry getFindTributeSaleRecordByLockIdQryDao() {
		return findTributeSaleRecordByLockIdQryDao;
	}

	/**
	 * @param findTributeSaleRecordByLockIdQryDao
	 *            the findTributeSaleRecordByLockIdQryDao to set
	 */
	public void setFindTributeSaleRecordByLockIdQryDao(
			FindTributeSaleRecordByLockIdQry findTributeSaleRecordByLockIdQryDao) {
		this.findTributeSaleRecordByLockIdQryDao = findTributeSaleRecordByLockIdQryDao;
	}

	/**
	 * @return the findTributeExistLockByIdQryDao
	 */
	public FindTributeExistLockByIdQry getFindTributeExistLockByIdQryDao() {
		return findTributeExistLockByIdQryDao;
	}

	/**
	 * @param findTributeExistLockByIdQryDao
	 *            the findTributeExistLockByIdQryDao to set
	 */
	public void setFindTributeExistLockByIdQryDao(
			FindTributeExistLockByIdQry findTributeExistLockByIdQryDao) {
		this.findTributeExistLockByIdQryDao = findTributeExistLockByIdQryDao;
	}

	/**
	 * @return the createSaleLockRecordQryDao
	 */
	public CreateSaleLockRecordQry getCreateSaleLockRecordQryDao() {
		return createSaleLockRecordQryDao;
	}

	/**
	 * @param createSaleLockRecordQryDao
	 *            the createSaleLockRecordQryDao to set
	 */
	public void setCreateSaleLockRecordQryDao(
			CreateSaleLockRecordQry createSaleLockRecordQryDao) {
		this.createSaleLockRecordQryDao = createSaleLockRecordQryDao;
	}

	/**
	 * @return the findTributeLockedRecordsByIdQryDao
	 */
	public FindTributeLockedRecordsByIdQry getFindTributeLockedRecordsByIdQryDao() {
		return findTributeLockedRecordsByIdQryDao;
	}

	/**
	 * @param findTributeLockedRecordsByIdQryDao
	 *            the findTributeLockedRecordsByIdQryDao to set
	 */
	public void setFindTributeLockedRecordsByIdQryDao(
			FindTributeLockedRecordsByIdQry findTributeLockedRecordsByIdQryDao) {
		this.findTributeLockedRecordsByIdQryDao = findTributeLockedRecordsByIdQryDao;
	}

	/**
	 * @return the deleteTributeSaleLockRecordByIdQryDao
	 */
	public DeleteTributeSaleLockRecordByIdQry getDeleteTributeSaleLockRecordByIdQryDao() {
		return deleteTributeSaleLockRecordByIdQryDao;
	}

	/**
	 * @param deleteTributeSaleLockRecordByIdQryDao
	 *            the deleteTributeSaleLockRecordByIdQryDao to set
	 */
	public void setDeleteTributeSaleLockRecordByIdQryDao(
			DeleteTributeSaleLockRecordByIdQry deleteTributeSaleLockRecordByIdQryDao) {
		this.deleteTributeSaleLockRecordByIdQryDao = deleteTributeSaleLockRecordByIdQryDao;
	}

	/**
	 * @return the findTributeSaleIdByNonIssueElementQryDao
	 */
	public FindTributeSaleIdByNonIssueElementQry getFindTributeSaleIdByNonIssueElementQryDao() {
		return findTributeSaleIdByNonIssueElementQryDao;
	}

	/**
	 * @param findTributeSaleIdByNonIssueElementQryDao
	 *            the findTributeSaleIdByNonIssueElementQryDao to set
	 */
	public void setFindTributeSaleIdByNonIssueElementQryDao(
			FindTributeSaleIdByNonIssueElementQry findTributeSaleIdByNonIssueElementQryDao) {
		this.findTributeSaleIdByNonIssueElementQryDao = findTributeSaleIdByNonIssueElementQryDao;
	}

	/**
	 * @return the findTributeSaleRecordByNonIssueIdQryDao
	 */
	public FindTributeSaleRecordByNonIssueIdQry getFindTributeSaleRecordByNonIssueIdQryDao() {
		return findTributeSaleRecordByNonIssueIdQryDao;
	}

	/**
	 * @param findTributeSaleRecordByNonIssueIdQryDao
	 *            the findTributeSaleRecordByNonIssueIdQryDao to set
	 */
	public void setFindTributeSaleRecordByNonIssueIdQryDao(
			FindTributeSaleRecordByNonIssueIdQry findTributeSaleRecordByNonIssueIdQryDao) {
		this.findTributeSaleRecordByNonIssueIdQryDao = findTributeSaleRecordByNonIssueIdQryDao;
	}

	/**
	 * @return the findTributeSaleLockByNonIssueIdQryDao
	 */
	public FindTributeSaleLockByNonIssueIdQry getFindTributeSaleLockByNonIssueIdQryDao() {
		return findTributeSaleLockByNonIssueIdQryDao;
	}

	/**
	 * @param findTributeSaleLockByNonIssueIdQryDao
	 *            the findTributeSaleLockByNonIssueIdQryDao to set
	 */
	public void setFindTributeSaleLockByNonIssueIdQryDao(
			FindTributeSaleLockByNonIssueIdQry findTributeSaleLockByNonIssueIdQryDao) {
		this.findTributeSaleLockByNonIssueIdQryDao = findTributeSaleLockByNonIssueIdQryDao;
	}
	/**
	 * @return the findTributeSearchSaleTKeysQryDao
	 */
	public FindTributeSearchSaleTKeysQry getFindTributeSearchSaleTKeysQryDao() {
		return findTributeSearchSaleTKeysQryDao;
	}

	/**
	 * @param findTributeSearchSaleTKeysQryDao
	 *            the findTributeSearchSaleTKeysQryDao to set
	 */
	public void setFindTributeSearchSaleTKeysQryDao(
			FindTributeSearchSaleTKeysQry findTributeSearchSaleTKeysQryDao) {
		this.findTributeSearchSaleTKeysQryDao = findTributeSearchSaleTKeysQryDao;
	}

	/**
	 * @return the findTributeSearchSaleCKeysQryDao
	 */
	public FindTributeSearchSaleCKeysQry getFindTributeSearchSaleCKeysQryDao() {
		return findTributeSearchSaleCKeysQryDao;
	}

	/**
	 * @param findTributeSearchSaleCKeysQryDao
	 *            the findTributeSearchSaleCKeysQryDao to set
	 */
	public void setFindTributeSearchSaleCKeysQryDao(
			FindTributeSearchSaleCKeysQry findTributeSearchSaleCKeysQryDao) {
		this.findTributeSearchSaleCKeysQryDao = findTributeSearchSaleCKeysQryDao;
	}

	/**
	 * @return the findTributeSearchSaleRKeysQryDao
	 */
	public FindTributeSearchSaleRKeysQry getFindTributeSearchSaleRKeysQryDao() {
		return findTributeSearchSaleRKeysQryDao;
	}

	/**
	 * @param findTributeSearchSaleRKeysQryDao
	 *            the findTributeSearchSaleRKeysQryDao to set
	 */
	public void setFindTributeSearchSaleRKeysQryDao(
			FindTributeSearchSaleRKeysQry findTributeSearchSaleRKeysQryDao) {
		this.findTributeSearchSaleRKeysQryDao = findTributeSearchSaleRKeysQryDao;
	}

	/**
	 * @return the findTributeSearchSaleNRkeysQryDao
	 */
	public FindTributeSearchSaleNRkeysQry getFindTributeSearchSaleNRkeysQryDao() {
		return findTributeSearchSaleNRkeysQryDao;
	}

	/**
	 * @param findTributeSearchSaleNRkeysQryDao
	 *            the findTributeSearchSaleNRkeysQryDao to set
	 */
	public void setFindTributeSearchSaleNRkeysQryDao(
			FindTributeSearchSaleNRkeysQry findTributeSearchSaleNRkeysQryDao) {
		this.findTributeSearchSaleNRkeysQryDao = findTributeSearchSaleNRkeysQryDao;
	}

	/**
	 * @return the findTributeSearchSaleNPRkeysQryDao
	 */
	public FindTributeSearchSaleNPRkeysQry getFindTributeSearchSaleNPRkeysQryDao() {
		return findTributeSearchSaleNPRkeysQryDao;
	}

	/**
	 * @param findTributeSearchSaleNPRkeysQryDao
	 *            the findTributeSearchSaleNPRkeysQryDao to set
	 */
	public void setFindTributeSearchSaleNPRkeysQryDao(
			FindTributeSearchSaleNPRkeysQry findTributeSearchSaleNPRkeysQryDao) {
		this.findTributeSearchSaleNPRkeysQryDao = findTributeSearchSaleNPRkeysQryDao;
	}

	/**
	 * @return the findTributeSearchSalePRkeysQryDao
	 */
	public FindTributeSearchSalePRkeysQry getFindTributeSearchSalePRkeysQryDao() {
		return findTributeSearchSalePRkeysQryDao;
	}

	/**
	 * @param findTributeSearchSalePRkeysQryDao
	 *            the findTributeSearchSalePRkeysQryDao to set
	 */
	public void setFindTributeSearchSalePRkeysQryDao(
			FindTributeSearchSalePRkeysQry findTributeSearchSalePRkeysQryDao) {
		this.findTributeSearchSalePRkeysQryDao = findTributeSearchSalePRkeysQryDao;
	}

	/**
	 * @return the findTributeSaleXmlQryDao
	 */
	public FindTributeSaleXmlQry getFindTributeSaleXmlQryDao() {
		return findTributeSaleXmlQryDao;
	}

	/**
	 * @param findTributeSaleXmlQryDao
	 *            the findTributeSaleXmlQryDao to set
	 */
	public void setFindTributeSaleXmlQryDao(
			FindTributeSaleXmlQry findTributeSaleXmlQryDao) {
		this.findTributeSaleXmlQryDao = findTributeSaleXmlQryDao;
	}

	/**
	 * @return the deleteSaleRKeysByIdQryDao
	 */
	public DeleteSaleRKeysByIdQry getDeleteSaleRKeysByIdQryDao() {
		return deleteSaleRKeysByIdQryDao;
	}

	/**
	 * @param deleteSaleRKeysByIdQryDao
	 *            the deleteSaleRKeysByIdQryDao to set
	 */
	public void setDeleteSaleRKeysByIdQryDao(
			DeleteSaleRKeysByIdQry deleteSaleRKeysByIdQryDao) {
		this.deleteSaleRKeysByIdQryDao = deleteSaleRKeysByIdQryDao;
	}

	/**
	 * @return the findTributeSaleRecordByOriginalIdQryDao
	 */
	public FindTributeSaleRecordByOriginalIdQry getFindTributeSaleRecordByOriginalIdQryDao() {
		return findTributeSaleRecordByOriginalIdQryDao;
	}

	/**
	 * @param findTributeSaleRecordByOriginalIdQryDao
	 *            the findTributeSaleRecordByOriginalIdQryDao to set
	 */
	public void setFindTributeSaleRecordByOriginalIdQryDao(
			FindTributeSaleRecordByOriginalIdQry findTributeSaleRecordByOriginalIdQryDao) {
		this.findTributeSaleRecordByOriginalIdQryDao = findTributeSaleRecordByOriginalIdQryDao;
	}

	/**
	 * @return the updateTributeSaleCKeyQryDao
	 */
	public UpdateTributeSaleCKeyQry getUpdateTributeSaleCKeyQryDao() {
		return updateTributeSaleCKeyQryDao;
	}

	/**
	 * @param updateTributeSaleCKeyQryDao
	 *            the updateTributeSaleCKeyQryDao to set
	 */
	public void setUpdateTributeSaleCKeyQryDao(
			UpdateTributeSaleCKeyQry updateTributeSaleCKeyQryDao) {
		this.updateTributeSaleCKeyQryDao = updateTributeSaleCKeyQryDao;
	}

	/**
	 * @return the updateTributeSaleNKeyQryDao
	 */
	public UpdateTributeSaleNKeyQry getUpdateTributeSaleNKeyQryDao() {
		return updateTributeSaleNKeyQryDao;
	}

	/**
	 * @param updateTributeSaleNKeyQryDao
	 *            the updateTributeSaleNKeyQryDao to set
	 */
	public void setUpdateTributeSaleNKeyQryDao(
			UpdateTributeSaleNKeyQry updateTributeSaleNKeyQryDao) {
		this.updateTributeSaleNKeyQryDao = updateTributeSaleNKeyQryDao;
	}

	/**
	 * @return the updateTributeSalePKeyQryDao
	 */
	public UpdateTributeSalePKeyQry getUpdateTributeSalePKeyQryDao() {
		return updateTributeSalePKeyQryDao;
	}

	/**
	 * @param updateTributeSalePKeyQryDao
	 *            the updateTributeSalePKeyQryDao to set
	 */
	public void setUpdateTributeSalePKeyQryDao(
			UpdateTributeSalePKeyQry updateTributeSalePKeyQryDao) {
		this.updateTributeSalePKeyQryDao = updateTributeSalePKeyQryDao;
	}

	/**
	 * @return the updateTributeSaleRKeyQryDao
	 */
	public UpdateTributeSaleRKeyQry getUpdateTributeSaleRKeyQryDao() {
		return updateTributeSaleRKeyQryDao;
	}

	/**
	 * @param updateTributeSaleRKeyQryDao
	 *            the updateTributeSaleRKeyQryDao to set
	 */
	public void setUpdateTributeSaleRKeyQryDao(
			UpdateTributeSaleRKeyQry updateTributeSaleRKeyQryDao) {
		this.updateTributeSaleRKeyQryDao = updateTributeSaleRKeyQryDao;
	}

	/**
	 * @return the updateTributeSaleTKeyQryDao
	 */
	public UpdateTributeSaleTKeyQry getUpdateTributeSaleTKeyQryDao() {
		return updateTributeSaleTKeyQryDao;
	}

	/**
	 * @param updateTributeSaleTKeyQryDao
	 *            the updateTributeSaleTKeyQryDao to set
	 */
	public void setUpdateTributeSaleTKeyQryDao(
			UpdateTributeSaleTKeyQry updateTributeSaleTKeyQryDao) {
		this.updateTributeSaleTKeyQryDao = updateTributeSaleTKeyQryDao;
	}

	/**
	 * @return the findBarcodeDataQryDao
	 */
	public FindBarcodeDataQry getFindBarcodeDataQryDao() {
		return findBarcodeDataQryDao;
	}

	/**
	 * @param findBarcodeDataQryDao
	 *            the findBarcodeDataQryDao to set
	 */
	public void setFindBarcodeDataQryDao(
			FindBarcodeDataQry findBarcodeDataQryDao) {
		this.findBarcodeDataQryDao = findBarcodeDataQryDao;
	}

	/**
	 * @return the findBarcodeTicketScanByTicketingRecordQryDao
	 */
	public FindBarcodeTicketScanByTicketingRecordQry getFindBarcodeTicketScanByTicketingRecordQryDao() {
		return findBarcodeTicketScanByTicketingRecordQryDao;
	}

	/**
	 * @param findBarcodeTicketScanByTicketingRecordQryDao
	 *            the findBarcodeTicketScanByTicketingRecordQryDao to set
	 */
	public void setFindBarcodeTicketScanByTicketingRecordQryDao(
			FindBarcodeTicketScanByTicketingRecordQry findBarcodeTicketScanByTicketingRecordQryDao) {
		this.findBarcodeTicketScanByTicketingRecordQryDao = findBarcodeTicketScanByTicketingRecordQryDao;
	}
	
	/**
	 * @return the findTributeSearchSaleQryDao
	 */
	public FindTributeSearchSaleQry getFindTributeSearchSaleQryDao() {
		return findTributeSearchSaleQryDao;
	}
	
	/**
	 * @param findTributeSearchSaleQryDao
	 *            the findTributeSearchSaleQryDao to set
	 */
	public void setFindTributeSearchSaleQryDao(
			FindTributeSearchSaleQry findTributeSearchSaleQryDao) {
		this.findTributeSearchSaleQryDao = findTributeSearchSaleQryDao;
	}
	
	/**
	 * @param findTributeSearchSaleTKeysForISRNIPEQryDao
	 *            the findTributeSearchSaleTKeysForISRNIPEQryDao to set
	 */
	public void setFindTributeSearchSaleTKeysForISRNIPEQryDao(
			FindTributeSearchSaleTKeysForISRNIPEQry findTributeSearchSaleTKeysForISRNIPEQryDao) {
		this.findTributeSearchSaleTKeysForISRNIPEQryDao = findTributeSearchSaleTKeysForISRNIPEQryDao;
	}
	
	/**
	 * @return the findTributeSearchSaleTKeysForISRNIPEQryDao
	 */
	public FindTributeSearchSaleTKeysForISRNIPEQry getFindTributeSearchSaleTKeysForISRNIPEQryDao() {
		return findTributeSearchSaleTKeysForISRNIPEQryDao;
	}
	
	public FindTributeSearchSaleForContactBookingRefQry getFindTributeSearchSaleForContactBookingRefQryDao() {
		return findTributeSearchSaleForContactBookingRefQryDao;
	}

	public void setFindTributeSearchSaleForContactBookingRefQryDao(
			FindTributeSearchSaleForContactBookingRefQry findTributeSearchSaleForContactBookingRefQryDao) {
		this.findTributeSearchSaleForContactBookingRefQryDao = findTributeSearchSaleForContactBookingRefQryDao;
	}
	
	/**
	 * This method is used to the sale data for the sale keys fetched based on search criteria.
	 * 
	 * @param tributeSaleKeysList
	 * @param saleListForContactBookingRef
	 * @returns String
	 */
	private String getSaleDataForSearchCriteria(List<SaleRecordDto> saleListForContactBookingRef) {
		SaleRecordDto saleRecordDto = new SaleRecordDto();
		if (CollectionUtils.isNotEmpty(saleListForContactBookingRef)) {
			int saleListSize = saleListForContactBookingRef.size();
			if (saleListSize == 1) {
				BigInteger sale_id = saleListForContactBookingRef.get(0).cid;
				saleRecordDto = getScanDataForSale(saleListForContactBookingRef.get(0));
				saleRecordDto.setId(sale_id);
				return generateOutputXML(saleRecordDto.getId().toString(), saleRecordDto.getSale());
			}
			// Sending Confirmation ID for multiple sales retreived from search.
			else if (saleListSize > 1) {
				long cid;
				List tempList = new ArrayList();
				List<String> saleStringlist = new ArrayList<String>();
					for (int i = 0; i < saleListSize; i++) {
						cid = new Long((saleListForContactBookingRef.get(i).getCid()).toString());
						tempList.add(cid);
						tempList = new ArrayList(new LinkedHashSet(tempList));
						saleStringlist.add(getScanDataForSale(saleListForContactBookingRef.get(i)).getSale());
					}
				
				for (int i = 0; i < tempList.size(); i++) {
					if (logger.isInfoEnabled()) {
						logger.info("Tribute IncomingRequest record for Search Sale successfully found with id "
								+ tempList.get(i));
					}
				}
				return generateOutputXML(tempList, saleStringlist);
			}
		} else {
			logger.log(AVFLoggerLevel.Exception,
					"Warning while creating Tribute IncomingRequest record after Search since Sale Not found for "
							+ saleRecordDto.getId());

			return generateWarningXML("04", "No Matching sales found.");
		}
		return generateWarningXML("04", "No Matching sales found.");
	}
	
	
	/**
	 * This method is used to add all elements updateSaleDto list to saleRecordDto list.
	 * 
	 * @param updateSaleList
	 * @returns List<SaleRecordDto>
	 */
	private List<SaleRecordDto> addUpdateSaleDtoListToSaleRecordDtoList(List<UpdateSaleDto> updateSaleList) {
		List<SaleRecordDto> saleRecordList = new ArrayList<SaleRecordDto> ();
		for (UpdateSaleDto updateSaleDto : updateSaleList) {
			SaleRecordDto saleRecordDto = new SaleRecordDto();
			saleRecordDto.setCid(updateSaleDto.getId());
			saleRecordDto.setSale(updateSaleDto.getSale());
			saleRecordList.add(saleRecordDto);
		}
		return saleRecordList;

	}
	
	
	/**
	 * This method is used to fetch and append the scan details of a sale from the database.
	 * 
	 * @param saleRecordDtoList
	 * @param saleId
	 * @returns SaleRecordDto
	 */
	private SaleRecordDto getScanDataForSale(SaleRecordDto saleRecordDto) {
		if (null != saleRecordDto) {
			List<SaleRecordDto> sale_list = new ArrayList<SaleRecordDto>();
			String sale_data = saleRecordDto.sale;
			BigInteger id = saleRecordDto.getCid();
			sale_list = findBarcodeDataQryDao.execute(id);
			if (CollectionUtils.isNotEmpty(sale_list)) {
				Document doc = convertStringToDocument(sale_data);
				for (int j = 0; j < sale_list.size(); j++) {
					List<AvfScanDto> ticketScan_list = new ArrayList<AvfScanDto>();
					String transactionNumber = sale_list.get(j).getTransaction_number();
					ticketScan_list = findBarcodeTicketScanByTicketingRecordQryDao
							.execute(sale_list.get(j).getTicketingRecordId());
					if (null != ticketScan_list) {
						doc = appendSaleXML(doc, ticketScan_list, transactionNumber);
					}
				}
				sale_data = convertDocumentToString(doc);
			}
			saleRecordDto.setSale(sale_data);
		} else {
			saleRecordDto.setSale(saleRecordDto.getSale());
		}
		return saleRecordDto;
	}

}