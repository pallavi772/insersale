package com.atosorigin.bluemobile.dto;

import java.io.Serializable;
import java.util.Date;

public class IncomingRequestDto implements Serializable{

	private static final long serialVersionUID = -6899986631932580025L;
	
	private long id;
	private String rawMessage;
	private Date lastUpdated;
	private String TIS;
	
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	/**
	 * @return the lastUpdated
	 */
	public Date getLastUpdated() {
		return lastUpdated;
	}
	/**
	 * @param lastUpdated the lastUpdated to set
	 */
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	/**
	 * @return the rawMessage
	 */
	public String getRawMessage() {
		return rawMessage;
	}
	/**
	 * @param rawMessage the rawMessage to set
	 */
	public void setRawMessage(String rawMessage) {
		this.rawMessage = rawMessage;
	}
	/**
	 * @return the tIS
	 */
	public String getTIS() {
		return TIS;
	}
	/**
	 * @param tis the tIS to set
	 */
	public void setTIS(String tis) {
		TIS = tis;
	}
}
