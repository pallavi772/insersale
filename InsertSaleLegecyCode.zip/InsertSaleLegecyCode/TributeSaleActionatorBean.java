package com.atosorigin.bluemobile.ticketengine.webfacade;

import java.util.Date;
import java.util.Map;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;

import org.apache.commons.lang3.StringUtils;
import org.jboss.ejb3.annotation.Clustered;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ejb.interceptor.SpringBeanAutowiringInterceptor;
import org.springframework.http.HttpStatus;

import com.atosorigin.bluemobile.helpers.AVFMessageHelper;
import com.atosorigin.bluemobile.helpers.TributeInsertSaleRequest;
import com.atosorigin.bluemobile.helpers.TributeMessageHelper;
import com.atosorigin.bluemobile.log4j.BlueMobileLogger;
import com.worldline.dts.common.Constants;
import com.worldline.dts.common.enumeration.RequestType;
import com.worldline.dts.common.enumeration.SaleEnum;
import com.worldline.dts.common.model.TelemetryRequest;
import com.worldline.dts.common.util.TelemetryUtils;

import net.sf.json.JSONObject;

/**
 * This class will be expose to extarnet for business logic implementation.
 * 
 */

@Stateless(mappedName = "bluemobile/ejb/TributeSaleActionator")
@Remote(TributeSaleActionatorRemote.class)
@Local(TributeSaleActionatorLocal.class)
@Clustered
@Interceptors(SpringBeanAutowiringInterceptor.class)
@SuppressWarnings("rawtypes")
public class TributeSaleActionatorBean implements TributeSaleActionatorLocal, TributeSaleActionatorRemote {

	
	static BlueMobileLogger logger = BlueMobileLogger.getLogger(TributeSaleActionatorBean.class);

	@Autowired
	TributeMessageHelper  tributeMessageHelper; 
	
	@Autowired
	AVFMessageHelper avfMessageHelper;
	
	private static final String SERVICE_REQUEST_UPDATE = "update";
	private static final String SERVICE_REQUEST_INSERT = "insert";

	/*
	 * This method is used to insert a tribute Sale request.
	 * 
	 */

	public String insertSale(Map avfSaleRequestMap, long incomingRequestId) throws Exception {
		TributeInsertSaleRequest tributeInsertSaleRequest = new TributeInsertSaleRequest();
		String responseObject = null;
		
		// Populate telemetry request.
		TelemetryRequest request = TelemetryUtils.populateTelemetryRequest(new Date(), null, null, SaleEnum.INSERT.getApiName(), SaleEnum.INSERT.getApiUri(), RequestType.SALE.name());
		
		tributeInsertSaleRequest.setInputxml((String) avfSaleRequestMap.get("XML"));
		responseObject = tributeMessageHelper.insertSale(tributeInsertSaleRequest, incomingRequestId);
		
		// Populate telemetry response.
		TelemetryUtils.populateTelemetryResponse(request, String.valueOf(incomingRequestId), HttpStatus.OK.value(), new Date(), Constants.SUCCESS);
		// Save telemetry log.
		TelemetryUtils.saveTelemetryRequest(request);

		return responseObject;
	}

	/*
	 * This method is used to update a tribute Sale request.
	 * 
	 */
	public String updateSale(Map avfSaleRequestMap, long incomingRequestId) {
		TributeInsertSaleRequest tributeInsertSaleRequest = new TributeInsertSaleRequest();
		String responseObject = null;
		
		// Populate telemetry request.
		TelemetryRequest request = TelemetryUtils.populateTelemetryRequest(new Date(), null, null, SaleEnum.UPDATE.getApiName(), SaleEnum.UPDATE.getApiUri(), RequestType.SALE.name());
		
		tributeInsertSaleRequest.setInputxml((String) avfSaleRequestMap.get("XML"));
		responseObject = tributeMessageHelper.updateSale(tributeInsertSaleRequest, incomingRequestId);
		
		// Populate telemetry response.
		TelemetryUtils.populateTelemetryResponse(request, String.valueOf(incomingRequestId), HttpStatus.OK.value(), new Date(), Constants.SUCCESS);
		// Save telemetry log.
		TelemetryUtils.saveTelemetryRequest(request);
		
		return responseObject;
	}

	/*
	 * This method is used to lock a tribute Salerequest.
	 * 
	 */

	public String lockSale(Map avfSaleRequestMap, long incomingRequestId) {
		// Populate telemetry request.
		TelemetryRequest request = TelemetryUtils.populateTelemetryRequest(new Date(), null, null, SaleEnum.LOCK.getApiName(), SaleEnum.LOCK.getApiUri(), RequestType.SALE.name());
				
		TributeInsertSaleRequest tributeInsertSaleRequest = new TributeInsertSaleRequest();

		String responseObject = null;

		tributeInsertSaleRequest.setInputxml((String) avfSaleRequestMap.get("XML"));
		responseObject = tributeMessageHelper.lockSale(tributeInsertSaleRequest, incomingRequestId);
		
		// Populate Telemetry response.
		TelemetryUtils.populateTelemetryResponse(request, null, HttpStatus.OK.value(), new Date(), Constants.SUCCESS);
		// Save Telemetry log.
		TelemetryUtils.saveTelemetryRequest(request);

		return responseObject;
	}

	/*
	 * This method is used to unlock a tribute Sale request.
	 * 
	 */
	public String unlockSale(Map avfSaleRequestMap, long incomingRequestId) {
		TributeInsertSaleRequest tributeInsertSaleRequest = new TributeInsertSaleRequest();
		String responseObject = null;
		
		// Populate telemetry request.
		TelemetryRequest request = TelemetryUtils.populateTelemetryRequest(new Date(), null, null, SaleEnum.UNLOCK.getApiName(), SaleEnum.UNLOCK.getApiUri(), RequestType.SALE.name());
		
		tributeInsertSaleRequest.setInputxml((String) avfSaleRequestMap.get("XML"));
		responseObject = tributeMessageHelper.unlockSale(tributeInsertSaleRequest, incomingRequestId);

		// Populate Telemetry response.
		TelemetryUtils.populateTelemetryResponse(request, null, HttpStatus.OK.value(), new Date(), Constants.SUCCESS);
		// Save Telemetry log.
		TelemetryUtils.saveTelemetryRequest(request);
		
		return responseObject;
	}

	/*
	 * This method is used to automatically unlock a tribute Sale request.
	 * 
	 */
	public String autounlockSale(Map avfSaleRequestMap, long incomingRequestId) {
		TributeInsertSaleRequest tributeInsertSaleRequest = new TributeInsertSaleRequest();
		JSONObject responseObject = new JSONObject();

		// Populate telemetry request.
		TelemetryRequest request = TelemetryUtils.populateTelemetryRequest(new Date(), null, null, SaleEnum.AUTO_UNLOCK.getApiName(), SaleEnum.AUTO_UNLOCK.getApiUri(), RequestType.SALE.name());
		
		tributeInsertSaleRequest.setInputxml((String) avfSaleRequestMap.get("XML"));

		responseObject = tributeMessageHelper.autounlockSale(tributeInsertSaleRequest, incomingRequestId);
		
		// Populate Telemetry response.
		TelemetryUtils.populateTelemetryResponse(request, null, HttpStatus.OK.value(), new Date(), Constants.SUCCESS);
		// Save Telemetry log.
		TelemetryUtils.saveTelemetryRequest(request);

		return responseObject.toString();
	}

	/*
	 * This method is used to nonissue a sale request.
	 * 
	 */
	public String nonIssueSale(Map avfSaleRequestMap, long incomingRequestId) {
		TributeInsertSaleRequest tributeInsertSaleRequest = new TributeInsertSaleRequest();
		String responseObject = null;

		// Populate telemetry request.
		TelemetryRequest request = TelemetryUtils.populateTelemetryRequest(new Date(), null, null, SaleEnum.NON_ISSUE.getApiName(), SaleEnum.NON_ISSUE.getApiUri(), RequestType.SALE.name());
				
		tributeInsertSaleRequest.setInputxml((String) avfSaleRequestMap.get("XML"));
		responseObject = tributeMessageHelper.nonIssueSale(tributeInsertSaleRequest, incomingRequestId);

		// Populate Telemetry response.
		TelemetryUtils.populateTelemetryResponse(request, null, HttpStatus.OK.value(), new Date(), Constants.SUCCESS);
		// Save Telemetry log.
		TelemetryUtils.saveTelemetryRequest(request);

		return responseObject;
	}

	/*
	 * This method is used to search a tribute Sale request.
	 * 
	 * @param avfcanRequestMap
	 * 
	 * @param serviceRequest
	 * 
	 */
	public String searchSale(Map avfSaleRequestMap, long incomingRequestId) {
		TributeInsertSaleRequest tributeInsertSaleRequest = new TributeInsertSaleRequest();
		String responseObject = null;
		
		// Populate telemetry request.
		TelemetryRequest request = TelemetryUtils.populateTelemetryRequest(new Date(), null, null, SaleEnum.SEARCH.getApiName(), SaleEnum.SEARCH.getApiUri(), RequestType.SALE.name());
		
		tributeInsertSaleRequest.setInputxml((String) avfSaleRequestMap.get("XML"));
		responseObject = tributeMessageHelper.searchSale(tributeInsertSaleRequest, incomingRequestId);

		// Populate telemetry response.
		TelemetryUtils.populateTelemetryResponse(request, null, HttpStatus.OK.value(), new Date(), Constants.SUCCESS);
		// Save telemetry log.
		TelemetryUtils.saveTelemetryRequest(request);
		return responseObject;
	}

	/**
	 * This method is used to generate a refund Reference for Sale request.
	 * 
	 * @param avfSaleRequestMap
	 * @param incomingRequestId
	 */
	public String generateReference(Map avfSaleRequestMap, long incomingRequestId) {
		TributeInsertSaleRequest tributeInsertSaleRequest = new TributeInsertSaleRequest();
		String responseObject = null;
		// Populate telemetry request.
		TelemetryRequest request = TelemetryUtils.populateTelemetryRequest(new Date(), null, null, SaleEnum.GENERATE_REFERENCE.getApiName(), SaleEnum.GENERATE_REFERENCE.getApiUri(), RequestType.SALE.name());
		tributeInsertSaleRequest.setInputxml((String) avfSaleRequestMap.get("XML"));
		responseObject = tributeMessageHelper.generateReference(tributeInsertSaleRequest);
		// Populate telemetry response.
		TelemetryUtils.populateTelemetryResponse(request, null, HttpStatus.OK.value(), new Date(), Constants.SUCCESS);
		// Save telemetry log.
		TelemetryUtils.saveTelemetryRequest(request);
		return responseObject;
	}

	/**
	 * This method used to insert record in incoming_request table and get id.
	 * 
	 * @param tributeSaleRequestMap
	 * @param serviceRequest
	 */
	public long insertIntoIncomingRequest(Map tributeSaleRequestMap, String serviceRequest) {
		long incomingRequestId = -1;
		String message = "";
		String ticketIssuer = "TRIBUTE";

		if (serviceRequest != null
				&& (serviceRequest.equals(SERVICE_REQUEST_INSERT) || serviceRequest.equals(SERVICE_REQUEST_UPDATE))) {
			message = new StringBuffer("" + tributeSaleRequestMap.get("XML")).toString();
			incomingRequestId = avfMessageHelper.insertIncomingRequest(message, ticketIssuer);
			logger.debug("Request for  Sale ticket Message at " + BlueMobileLogger.getCurrentDate());
		}

		return incomingRequestId;
	}

	/**
	 * Method used to get request reference for telemetry log.
	 * 
	 * @param xmlValue
	 * @return
	 */
	private static String getReqestReference(String xmlValue) {
		String[] result = StringUtils.substringsBetween(xmlValue, "<Parameters>", "</Parameters>");
		if (null != result && result.length > 0) {
			return result[0];
		}
		return null;
	}
	
}
