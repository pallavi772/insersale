package com.atosorigin.bluemobile.dal.ticketusage;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.atosorigin.bluemobile.log4j.BlueMobileLogger;

public class FindBookingReferenceQryDao {
	static BlueMobileLogger logger = BlueMobileLogger.getLogger(FindBookingReferenceQryDao.class);
	private static final String FIND_BOOKING_REFERENCE_QRY = "select booking_reference from booking where ctr_reference=?";
	
	private DataSource dataSource;
	
	public FindBookingReferenceQryDao(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public String getBookingReferenceByCtrReference(String ctrReference) {
	    JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
	    String bookingReference = (String) jdbcTemplate.queryForObject(FIND_BOOKING_REFERENCE_QRY, new Object[] { ctrReference }, String.class);
	    return bookingReference;
	}

}
