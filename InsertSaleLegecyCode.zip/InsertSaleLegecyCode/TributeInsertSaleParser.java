package com.atosorigin.bluemobile.parsers;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.EmptyResultDataAccessException;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.atosorigin.bluemobile.dal.ticketusage.FindBookingReferenceQryDao;
import com.atosorigin.bluemobile.log4j.AVFLoggerLevel;
import com.atosorigin.bluemobile.log4j.BlueMobileLogger;

/**
 * Class to parse the Incoming request for Insert Sale.
 * 
 * @author Sudha Parab
 * 
 */
/**
 * @author a500346 CR037 : added code to extract product_type, outward_date and
 *         start_date.
 */
public class TributeInsertSaleParser {
	private static BlueMobileLogger logger = BlueMobileLogger
			.getLogger(TributeInsertSaleParser.class);

	Map<String, String> insertSaleMap = new HashMap<String, String>();

	String machine_type = null;

	String machine = null;

	String userid = null;

	String sale_element;

	String issue_machine;

	String issue_date;

	String loyalty_card_id = null;

	String transaction_no;

	String sundry_issue_date;

	String sundry_transaction_no;

	String refund_status = null;

	String refund_reference = null;

	String output_xml;

	String product_type = "";

	public Map<String, String> parseInput(String inputXml,FindBookingReferenceQryDao findBookingReferenceQry) {

		insertSaleMap.clear();
		List insertSaleTransactionList = new ArrayList();
		List insertSaleIssueDateList = new ArrayList();
		List insertSaleTravelDateList = new ArrayList();

		try {
			logger.debug("Parser Entered");
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(new InputSource(new StringReader(
					inputXml)));
			Element rootelement = document.getDocumentElement();

			machine_type = rootelement.getAttribute("MachineType");
			machine = rootelement.getAttribute("Machine");
			userid = rootelement.getAttribute("UserID");

			logger.debug("MacType:" + machine_type);
			logger.debug("Machine:" + machine);
			logger.debug("UserID: " + userid);

			if ((machine_type != null && machine_type.length() != 0)
					&& (machine != null && machine.length() != 0)
					&& (userid != null && userid.length() != 0)) {

				insertSaleMap.put("machine_type", machine_type);
				insertSaleMap.put("machine", machine);
				insertSaleMap.put("userid", userid);

				StringWriter stringWriter = new StringWriter();
				Transformer transformer = TransformerFactory.newInstance().newTransformer();
				transformer.transform(new DOMSource(document),new StreamResult(stringWriter));
				String strFileContent = stringWriter.toString();

				//Populate Sale element
				if (strFileContent.startsWith("<?xml ")) {
					strFileContent = strFileContent.substring(strFileContent.indexOf("<Sale"));
					if (strFileContent.contains("</Sale>")){
						sale_element = strFileContent.substring(0,(strFileContent.lastIndexOf("</Sale>") + 7));
						insertSaleMap.put("sale_element", sale_element);
					} else{
						logger.debug("null string found for sale value"+ sale_element);
						return null;
					}
				} else {
					return null;
				}

				// ctr-ref in sale node...
				String ctr_refer = null;
				NodeList nodeList_sale = document.getElementsByTagName("Sale");
				if (nodeList_sale.getLength() != 0) {
					for (int i = 0; i < nodeList_sale.getLength(); i++) {
						Node node = nodeList_sale.item(i);
						if (node.getNodeType() == Node.ELEMENT_NODE) {
							Element element = (Element) node;
							NodeList nodelist_ctrref = element
									.getElementsByTagName("CTRReference");
							if (nodelist_ctrref.getLength() != 0) {
								Element element3 = (Element) nodelist_ctrref
										.item(0);
								NodeList ctr_reference = element3
										.getChildNodes();
								if (ctr_reference.getLength() != 0) {
									ctr_refer = ctr_reference.item(0).getNodeValue();
									insertSaleMap.put("ctr_reference",ctr_refer);
									// Add booking reference to Sale
									addBookingReference(db, transformer, element, findBookingReferenceQry,ctr_refer);
								} else {
									logger.debug("null string found for CTRReference value");
									insertSaleMap.put("ctr_reference", "~");

								}
							} else {
								logger.debug("null node found for CTRReference tag");
							}

							NodeList nodelist_issue_machine = element
									.getElementsByTagName("IssueMachine");
							if (nodelist_issue_machine.getLength() != 0) {
								Element element_issue = (Element) nodelist_issue_machine
										.item(0);
								NodeList issue_mac = element_issue
										.getChildNodes();
								if (issue_mac.getLength() != 0) {

									issue_machine = issue_mac.item(0)
											.getNodeValue();
									insertSaleMap.put("issue_machine",
											issue_machine);

								} else {
									logger.debug("null string found for issue_machine value");
								}
							} else {
								logger.debug("null node found for issue_machine tag");
							}
							
							// 11540 changes
							if (element.hasAttribute("BusinessGroup") && element.getAttribute("BusinessGroup") != null
									&& element.getAttribute("BusinessGroup").length() != 0) {
								insertSaleMap.put("business_group", element.getAttribute("BusinessGroup"));
							} else if (element.getAttribute("BusinessGroup") == null
									|| element.getAttribute("BusinessGroup").length() == 0) {
								logger.debug("null string found for BusinessGroup attribute value");
							} else if (!element.hasAttribute("BusinessGroup")) {
								logger.debug("BusinessGroup attribute not found");
							}
							//Populate Booking Reference
							populateBookingReference(element);

						}
					}

				} else
					return null;

				NodeList nodeList_loyalty = document
						.getElementsByTagName("LoyaltyDetail");
				if (nodeList_loyalty.getLength() != 0) {
					for (int i = 0; i < nodeList_loyalty.getLength(); i++) {
						Node node = nodeList_loyalty.item(i);
						if (node.getNodeType() == Node.ELEMENT_NODE) {
							Element element = (Element) node;
							NodeList nodelist_nectar_loyalty = element
									.getElementsByTagName("LoyaltyCardId");
							if (nodelist_nectar_loyalty.getLength() != 0) {
								Element loyalty = (Element) nodelist_nectar_loyalty
										.item(0);
								NodeList nectar = loyalty.getChildNodes();
								if (nectar.getLength() != 0) {
									loyalty_card_id = nectar.item(0)
											.getNodeValue();
									insertSaleMap.put("loyalty_card_id",
											loyalty_card_id);
								} else {
									logger.debug("null string found for LoyaltycardID value");
									return null;
								}
							} else {
								logger.debug("null node found LoyaltycardID for tag");
								return null;
							}
						}
					}
				} else {
					logger.debug("null node found LoyaltyDetail for tag");
				}

				NodeList nodeList_ticket = document
						.getElementsByTagName("Ticket");

				for (int i = 0; i < nodeList_ticket.getLength(); i++) {
					Node node = nodeList_ticket.item(i);
					if (node.getNodeType() == Node.ELEMENT_NODE) {
						Element element = (Element) node;

						NodeList nodelist_issue_date = element
								.getElementsByTagName("IssueDate");
						if (nodelist_issue_date.getLength() != 0) {
							Element element1 = (Element) nodelist_issue_date
									.item(0);
							NodeList issue_dat = element1.getChildNodes();
							if (issue_dat.getLength() != 0) {
								issue_date = issue_dat.item(0).getNodeValue();

								insertSaleIssueDateList.add(issue_date);
							} else {
								logger.debug("null string found for IssueDate value");
								return null;
							}
						} else {
							logger.debug("null node found IssueDate for tag");
							return null;
						}

						NodeList nodelist_transaction_no = element
								.getElementsByTagName("TransactionNumber");
						if (nodelist_transaction_no.getLength() != 0) {
							Element element2 = (Element) nodelist_transaction_no
									.item(0);
							NodeList transac_no = element2.getChildNodes();
							if (transac_no.getLength() != 0) {
								transaction_no = transac_no.item(0)
										.getNodeValue();

								insertSaleTransactionList.add(transaction_no);
								
								if (element.hasAttribute("ISRN") && element.getAttribute("ISRN") != null && element.getAttribute("ISRN").length() != 0) {
									insertSaleMap.put("isrn"+transaction_no, element.getAttribute("ISRN"));
								} else if (element.getAttribute("ISRN") == null || element.getAttribute("ISRN").length() == 0) {
									logger.debug("null string found for ISRN attribute value");
								} else if (!element.hasAttribute("ISRN")) {
									logger.debug("ISRN attribute not found");
								}
								
								if (element.hasAttribute("IPEInstanceId") && element.getAttribute("IPEInstanceId") != null && element.getAttribute("IPEInstanceId").length() != 0) {
									insertSaleMap.put("ipe_instanceId"+transaction_no, element.getAttribute("IPEInstanceId"));
								} else if (element.getAttribute("IPEInstanceId") == null || element.getAttribute("IPEInstanceId").length() == 0) {
									logger.debug("null string found for IPEInstanceId attribute value");
								} else if (!element.hasAttribute("IPEInstanceId")) {
									logger.debug("IPEInstanceId attribute not found");
								}
								
							} else {
								logger.debug("null string found for attribute value");
								return null;
							}
						} else {
							logger.debug("null node found for tag");
							return null;
						}

						// CR037 changes

						NodeList nodelist_productType = element
								.getElementsByTagName("ProductType");
						if (nodelist_productType.getLength() != 0) {
							Element element_productType = (Element) nodelist_productType
									.item(0);
							NodeList productType = element_productType
									.getChildNodes();
							if (productType.getLength() != 0) {

								product_type = (productType.item(0)
										.getNodeValue());
							} else {
								logger.debug("null string found for attribute value");
								return null;
							}
						} else {
							logger.debug("null node found for ProductType tag");
						}

						if (product_type.equalsIgnoreCase("TT")) {
							NodeList nodelist_ticketDetail = element
									.getElementsByTagName("TicketDetail");
							if (nodelist_ticketDetail.getLength() != 0) {
								Element element2 = (Element) nodelist_ticketDetail
										.item(0);
								NodeList ticketDetail = element2
										.getChildNodes();
								if (ticketDetail.getLength() != 0) {

									Node node1 = ticketDetail.item(0);
									if (node1.getNodeType() == Node.ELEMENT_NODE) {

										if (inputXml.contains("<OutwardDate>")) {

											NodeList nodelist_outwardDate = element
													.getElementsByTagName("OutwardDate");
											Element element_outwardDate = (Element) nodelist_outwardDate
													.item(0);
											NodeList outwardDate = element_outwardDate
													.getChildNodes();
											if (outwardDate.getLength() != 0) {

												insertSaleTravelDateList
														.add(outwardDate
																.item(0)
																.getNodeValue());

											} else {
												logger.debug("null node found for OutwardDate tag");
												return null;
											}
										}

									}
								}
							} else {
								logger.debug("null node found for TicketDetail tag");
							}
						} else if (product_type.equalsIgnoreCase("SE")) {
							NodeList nodelist_seasonDetail = element
									.getElementsByTagName("SeasonDetail");
							if (nodelist_seasonDetail.getLength() != 0) {
								Element element3 = (Element) nodelist_seasonDetail
										.item(0);
								NodeList seasonDetail = element3
										.getChildNodes();
								if (seasonDetail.getLength() != 0) {

									Node node_seasonDetail = seasonDetail
											.item(0);
									if (node_seasonDetail.getNodeType() == Node.ELEMENT_NODE) {

										if (inputXml.contains("<StartDate>")) {

											NodeList nodelist_startDate = element
													.getElementsByTagName("StartDate");
											Element element_startDate = (Element) nodelist_startDate
													.item(0);
											NodeList startDate = element_startDate
													.getChildNodes();
											if (startDate.getLength() != 0) {

												insertSaleTravelDateList
														.add(startDate.item(0)
																.getNodeValue());

											} else {
												logger.debug("null node found for StartDate tag");
												return null;
											}
										}

									}
								}
							} else {
								logger.debug("null node found for SeasonDetail tag");
							}

						} else {
							logger.debug("product type is other than TT and SE ");
							insertSaleTravelDateList.add(" ");
						}

					}
				}

				NodeList nodeList_sundry = document
						.getElementsByTagName("Sundry");

				for (int i = 0; i < nodeList_sundry.getLength(); i++) {
					Node node = nodeList_sundry.item(i);
					if (node.getNodeType() == Node.ELEMENT_NODE) {
						Element element = (Element) node;

						NodeList nodelist_sundry_issue_date = element
								.getElementsByTagName("IssueDate");
						if (nodelist_sundry_issue_date.getLength() != 0) {
							Element element1 = (Element) nodelist_sundry_issue_date
									.item(0);
							NodeList sundry_issue_dat = element1
									.getChildNodes();
							if (sundry_issue_dat.getLength() != 0) {
								sundry_issue_date = sundry_issue_dat.item(0)
										.getNodeValue();

								insertSaleIssueDateList.add(sundry_issue_date);
							} else {
								logger.debug("null string found for IssueDate");
								return null;
							}
						} else {
							logger.debug("null node found  for tag IssueDate");
							return null;
						}

						NodeList sundry_nodelist_transaction_no = element
								.getElementsByTagName("TransactionNumber");
						if (sundry_nodelist_transaction_no.getLength() != 0) {
							Element element2 = (Element) sundry_nodelist_transaction_no
									.item(0);
							NodeList sundry_transac_no = element2
									.getChildNodes();
							if (sundry_transac_no.getLength() != 0) {
								sundry_transaction_no = sundry_transac_no.item(
										0).getNodeValue();

								insertSaleTransactionList
										.add(sundry_transaction_no);
							} else {
								logger.debug("null string found for Transaction no.");
								return null;
							}
						} else {
							logger.debug("null node found for tag Transaction no.");
							return null;
						}

					}
				}

				List insertSaleRefundReferenceList = new ArrayList();
				List insertSaleRefundStatusList = new ArrayList();
				List insertSaleSurnameList = new ArrayList();
				List insertSalePostcodeList = new ArrayList();
				String surname = null;
				String postcode = null;

				NodeList nodeList_refund = document
						.getElementsByTagName("Refund");
				if (nodeList_refund.getLength() != 0) {
					for (int i = 0; i < nodeList_refund.getLength(); i++) {
						Node node = nodeList_refund.item(i);
						if (node.getNodeType() == Node.ELEMENT_NODE) {
							Element element = (Element) node;

							NodeList nodelist_surname = element
									.getElementsByTagName("Surname");
							if (nodelist_surname.getLength() != 0) {
								Element element1 = (Element) nodelist_surname
										.item(0);
								NodeList surn = element1.getChildNodes();
								if (surn.getLength() != 0) {

									surname = surn.item(0).getNodeValue();

									insertSaleSurnameList.add(surname);

								} else {
									logger.debug("null string found for Surname value");

									insertSaleSurnameList.add("~");
								}

							} else {
								logger.debug("null node found for Surname tag");
							}

							NodeList nodelist_postcode = element
									.getElementsByTagName("Postcode");
							if (nodelist_postcode.getLength() != 0) {
								Element element2 = (Element) nodelist_postcode
										.item(0);
								NodeList post = element2.getChildNodes();
								if (post.getLength() != 0) {
									postcode = post.item(0).getNodeValue();

									insertSalePostcodeList.add(postcode);

								} else {
									logger.debug("null string found for Postcode value");
									insertSalePostcodeList.add("~");
								}
							} else {
								logger.debug("null node found for Postcode tag");
							}

							NodeList nodelist_status = element
									.getElementsByTagName("RefundStatus");
							if (nodelist_status.getLength() != 0) {
								Element element3 = (Element) nodelist_status
										.item(0);
								NodeList stat = element3.getChildNodes();
								if (stat.getLength() != 0) {

									refund_status = stat.item(0).getNodeValue();

									insertSaleRefundStatusList
											.add(refund_status);

								} else {
									logger.debug("null string found for RefundStatus value");
									return null;
								}

							} else {
								logger.debug("null node found for RefundStatus tag");
								return null;
							}

							NodeList nodelist_refund_reference = element
									.getElementsByTagName("RefundReference");

							if (nodelist_refund_reference.getLength() != 0) {

								Element element4 = (Element) nodelist_refund_reference
										.item(0);
								NodeList refund_ref = element4.getChildNodes();

								if (refund_ref.getLength() != 0) {
									refund_reference = refund_ref.item(0)
											.getNodeValue();

									insertSaleRefundReferenceList
											.add(refund_reference);
									
									if (element.hasAttribute("CreatedDateTime")){
										String createdDateTime = element.getAttribute("CreatedDateTime");
										if(null != createdDateTime && createdDateTime.length() != 0){
											insertSaleMap.put("createdDate" + refund_reference,
													createdDateTime);
										}
										else{
											logger.debug("null string found for CreatedDateTime attribute value");
										}
									}
									else if (element.hasAttribute("CreationDateTime")){
										String creationDateTime = element.getAttribute("CreationDateTime");
										if(null != creationDateTime && creationDateTime.length() != 0){
											insertSaleMap.put("createdDate" + refund_reference,
													creationDateTime);
										}
										else{
											logger.debug("null string found for CreationDateTime attribute value");
										}
									}
									else{
										logger.debug("CreationDateTime attribute not found");
									}
									
								} else {
									logger.debug("null string found for RefundReference value");
									return null;
								}
							} else {
								logger.debug("null node found for RefundReference tag");
								return null;
							}
						}
					}
					// postcode
					if (!(insertSalePostcodeList == null
							|| insertSalePostcodeList.isEmpty() || (insertSalePostcodeList
								.get(0).equals("~"))))

					{

						insertSaleMap
								.put("postcode_size",
										String.valueOf((insertSalePostcodeList
												.size())));

						for (int h = 0; h < insertSalePostcodeList.size(); h++) {
							if (!(insertSalePostcodeList.get(0).equals("~"))) {

								insertSaleMap.put("postcode" + h,
										insertSalePostcodeList.get(h)
												.toString());
							}
						}

					} else {
						insertSaleMap.put("postcode_size", "0");
					}
					// surname
					if (!(insertSaleSurnameList == null
							|| insertSaleSurnameList.isEmpty() || (insertSaleSurnameList
								.get(0).equals("~")))) {

						insertSaleMap.put("surname_size",
								String.valueOf((insertSaleSurnameList.size())));

						for (int h = 0; h < insertSaleSurnameList.size(); h++) {
							if (!(insertSaleSurnameList.get(h).equals("~"))) {

								insertSaleMap
										.put("surname" + h,
												insertSaleSurnameList.get(h)
														.toString());
							}
						}

					} else {
						insertSaleMap.put("surname_size", "0");
					}

					if (!(insertSaleRefundReferenceList == null || insertSaleRefundReferenceList
							.isEmpty())) {
						if (!(insertSaleRefundStatusList == null || insertSaleRefundStatusList
								.isEmpty())) {
							if (insertSaleRefundStatusList.size() == insertSaleRefundReferenceList
									.size()) {

								insertSaleMap
										.put("refund_reference_size",
												String.valueOf((insertSaleRefundReferenceList
														.size())));
								for (int h = 0; h < insertSaleRefundReferenceList
										.size(); h++) {
									insertSaleMap.put("refund_reference" + h,
											insertSaleRefundReferenceList
													.get(h).toString());
									insertSaleMap.put("refund_status" + h,
											insertSaleRefundStatusList.get(h)
													.toString());

								}
							}
						}
					}

				} else {
					logger.debug("null string found for refund value");
				}

				if (!(insertSaleTransactionList == null || insertSaleTransactionList
						.isEmpty())) {
					insertSaleMap.put("transaction_size",
							String.valueOf((insertSaleTransactionList.size())));

					for (int h = 0; h < insertSaleTransactionList.size(); h++) {
						insertSaleMap.put("transaction" + h,
								insertSaleTransactionList.get(h).toString());

					}

				}

				if (!(insertSaleIssueDateList == null || insertSaleIssueDateList
						.isEmpty())) {
					insertSaleMap.put("issuedate_size",
							String.valueOf((insertSaleIssueDateList.size())));

					for (int h = 0; h < insertSaleIssueDateList.size(); h++) {
						insertSaleMap.put("issue_date" + h,
								insertSaleIssueDateList.get(h).toString());
					}
				}

				// CR037 changes

				if (!(insertSaleTravelDateList == null || insertSaleTravelDateList
						.isEmpty())) {
					insertSaleMap.put("travel_date_size",
							String.valueOf((insertSaleTravelDateList.size())));

					for (int h = 0; h < insertSaleTravelDateList.size(); h++) {
						insertSaleMap.put("travel_date" + h,
								insertSaleTravelDateList.get(h).toString());

					}
				}

			} else {
				logger.debug("null string found for machine_type value");
				logger.debug("null string found for machine value");
				logger.debug("null string found for userid value");
				return null;
			}

		} catch (TransformerConfigurationException e) {
			logger.log(
					AVFLoggerLevel.Exception,
					"Error when parsing the Insert Sale xml message - TransformerConfigurationException",
					e);
			return null;
		} catch (DOMException e) {
			logger.log(
					AVFLoggerLevel.Exception,
					"Error when parsing the Insert Sale xml message - DOMException",
					e);
			return null;
		} catch (FactoryConfigurationError e) {
			logger.log(
					AVFLoggerLevel.Exception,
					"Error when parsing the  Insert Sale xml message - FactoryConfigurationError",
					e);
			return null;
		} catch (ParserConfigurationException e) {
			logger.log(
					AVFLoggerLevel.Exception,
					"Error when parsing the  Insert Sale xml message - ParserConfigurationException",
					e);
			return null;
		} catch (SAXException e) {
			logger.log(
					AVFLoggerLevel.Exception,
					"Error when parsing the  Insert Sale xml message - SAXException",
					e);
			return null;
		} catch (IOException e) {
			logger.log(
					AVFLoggerLevel.Exception,
					"Error when parsing the  Insert Sale xml message - IOException ",
					e);
			return null;
		} catch (TransformerFactoryConfigurationError e) {
			logger.log(
					AVFLoggerLevel.Exception,
					"Error when parsing the  Insert Sale xml message - TransformerFactoryConfigurationError ",
					e);
			return null;
		} catch (TransformerException e) {
			logger.log(
					AVFLoggerLevel.Exception,
					"Error when parsing the  Insert Sale xml message - TransformerException ",
					e);
			return null;
		}
		return insertSaleMap;

	}
	
	/**
	 * Add Booking reference to sale record
	 * @param db
	 * @param transformer
	 * @param element
	 * @param findBookingReferenceQry 
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 * @throws TransformerConfigurationException
	 * @throws TransformerFactoryConfigurationError
	 * @throws TransformerException
	 */
	private void addBookingReference(DocumentBuilder db, Transformer transformer, Element element, FindBookingReferenceQryDao findBookingReferenceQry,String ctrReference) throws ParserConfigurationException, SAXException, IOException,
			TransformerConfigurationException, TransformerFactoryConfigurationError, TransformerException {
		try {
			if ((element.hasAttribute("ContactBookingReference") && StringUtils.isBlank(element.getAttribute("ContactBookingReference"))) || (!element.hasAttribute("ContactBookingReference"))) {
				logger.debug("ContactBookingReference is blank or attribute not present");
				// Find Booking reference by CTRReference
				String bookingReference = findBookingReferenceQry.getBookingReferenceByCtrReference(ctrReference);
				if(StringUtils.isNotBlank(bookingReference)) {
					// update booking reference field
					insertSaleMap.put("contact_booking_reference", bookingReference);
					// Update Sale element
					Document document = db.parse(new InputSource(new StringReader(sale_element)));
					Element rootelement = document.getDocumentElement();
					rootelement.setAttribute("ContactBookingReference", bookingReference);
					StringWriter stringWriter = new StringWriter();
					transformer.transform(new DOMSource(document),new StreamResult(stringWriter));
					String strFileContent = stringWriter.toString();
					strFileContent = strFileContent.substring(strFileContent.indexOf("<Sale"));
					insertSaleMap.put("sale_element", strFileContent);
				}
			}
		}catch (EmptyResultDataAccessException exception) {
			logger.warn("Booking reference not found for CTR Reference ::: "+ctrReference);
		}catch (Exception exception) {
			logger.error("Exception occured while executing addBookingReference "+exception.getMessage());
		}
	}
	
	/**
	 * Populate Booking Reference
	 * @param element
	 */
	private void populateBookingReference(Element element) {
		if(!insertSaleMap.containsKey("contact_booking_reference")) {
			if (element.hasAttribute("ContactBookingReference") && StringUtils.isNotBlank(element.getAttribute("ContactBookingReference"))) {
				insertSaleMap.put("contact_booking_reference", element.getAttribute("ContactBookingReference"));
			} else if (element.hasAttribute("ContactBookingReference") && StringUtils.isBlank(element.getAttribute("ContactBookingReference"))) {
				logger.debug("null string found for ContactBookingReference attribute value");
			} else if (!element.hasAttribute("ContactBookingReference")) {
				logger.debug("ContactBookingReference attribute not found");
			}
		}
	}
}
