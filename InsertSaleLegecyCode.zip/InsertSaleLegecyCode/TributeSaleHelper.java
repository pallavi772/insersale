package com.atosorigin.bluemobile.boundaryservices.incoming.tributeSale;

import java.util.HashMap;
import java.util.Map;

import com.atosorigin.bluemobile.exceptions.ApplicationCommunicationException;
import com.atosorigin.bluemobile.log4j.AVFLoggerLevel;
import com.atosorigin.bluemobile.log4j.BlueMobileLogger;
import com.atosorigin.bluemobile.ticketengine.webfacade.TributeSaleActionatorRemote;
import com.atosorigin.bluemobile.utils.BlueMobileEJBUtil;

/**
 * This class acts as a helper class and is used to fetch appropriate data,from
 * TributeSaleActionator EJB call.
 * 
 * @author kishor Agrawal
 * @version 1.0
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class TributeSaleHelper {

	private static BlueMobileLogger logger = BlueMobileLogger.getLogger(TributeSaleHelper.class);

	private static final String SERVICE_REQUEST_UPDATE = "update";
	private static final String SERVICE_REQUEST_SEARCH = "search";
	private static final String SERVICE_REQUEST_INSERT = "insert";
	private static final String SERVICE_REQUEST_GENERATE = "generate";
	private static final String SERVICE_REQUEST_LOCK = "lock";
	private static final String SERVICE_REQUEST_UNLOCK = "unlock";
	private static final String SERVICE_REQUEST_AUTOMATIC_UNLOCK = "autounlock";
	private static final String SERVICE_REQUEST_NONISSUE = "nonissue";
	
	public static String setTributeInsertSaleRequest(Map avfSaleRequestList) throws ApplicationCommunicationException {
		logger.debug("Inside setTributeInsertSaleRequest");

		long requestId;
		String response = "";
		
		try {
			TributeSaleActionatorRemote tributeSaleActionator = (TributeSaleActionatorRemote) BlueMobileEJBUtil
					.getTributeSaleActionatorBean();
			requestId = (long) tributeSaleActionator.insertIntoIncomingRequest(avfSaleRequestList, SERVICE_REQUEST_INSERT);
			try {
				response = tributeSaleActionator.insertSale(avfSaleRequestList, requestId);
				if (response.contains("<code>99</code>")) {
					logger.log(AVFLoggerLevel.Exception, ((HashMap) avfSaleRequestList).get("XML").toString());
				}
			} catch (Exception e) {
				logger.error(
						"Exception occured while executing setTributeInsertSaleRequest method : " + e.getMessage());
			}
			logger.debug("Incoming Request Id for Tribute Insert Sale in TributeSaleHelper" + requestId);
		} catch (Exception e) {
			logger.log(AVFLoggerLevel.Exception, "Exception while inserting ticket(s)", e);
			throw new ApplicationCommunicationException(e);
		}
		return response;
	}

	public static String setTributeUpdateSaleRequest(Map avfSaleRequestList) throws ApplicationCommunicationException {
		logger.debug("Inside setTributeUpdateSaleRequest ");

		long requestId;
		String response = "";
		
		try {
			TributeSaleActionatorRemote tributeSaleActionator = (TributeSaleActionatorRemote) BlueMobileEJBUtil.getTributeSaleActionatorBean();
			requestId = (long) tributeSaleActionator.insertIntoIncomingRequest(avfSaleRequestList,SERVICE_REQUEST_UPDATE);
			response = tributeSaleActionator.updateSale(avfSaleRequestList, requestId);
			logger.debug("Incoming Request Id for Tribute Update Sale in TributeSaleHelper" + requestId);
		} catch (Exception e) {
			logger.log(AVFLoggerLevel.Exception, "Exception while updating ticket(s)", e);
			throw new ApplicationCommunicationException(e);
		}

		return response;
	}

	public static String setTributeSearchSaleRequest(Map avfSaleRequestList) throws ApplicationCommunicationException {
		logger.debug("Inside setTributeSearchSaleRequest ");

		long requestId;
		String response = "";

		try {
			TributeSaleActionatorRemote tributeSaleActionator = (TributeSaleActionatorRemote) BlueMobileEJBUtil
					.getTributeSaleActionatorBean();
			requestId = (long) tributeSaleActionator.insertIntoIncomingRequest(avfSaleRequestList,
					SERVICE_REQUEST_SEARCH);
			response = tributeSaleActionator.searchSale(avfSaleRequestList, requestId);
			logger.debug("Incoming Request Id for Tribute Search Sale in TributeSaleHelper" + requestId);
		} catch (Exception e) {
			logger.log(AVFLoggerLevel.Exception, "Exception in ticket search : ", e);
			throw new ApplicationCommunicationException(e);
		}

		return response;
	}

	public static String setTributeNonIssueSaleRequest(Map avfSaleRequestList)
			throws ApplicationCommunicationException {
		logger.debug("inside setTributeNonIssueSaleRequest ");

		long requestId;
		String response = "";
		try {
			TributeSaleActionatorRemote tributeSaleActionator = (TributeSaleActionatorRemote) BlueMobileEJBUtil
					.getTributeSaleActionatorBean();
			requestId = (long) tributeSaleActionator.insertIntoIncomingRequest(avfSaleRequestList,
					SERVICE_REQUEST_NONISSUE);
			response = tributeSaleActionator.nonIssueSale(avfSaleRequestList, requestId);
			logger.debug("Incoming Request Id for Tribute NonIssue Sale in TributeSaleHelper" + requestId);
		} catch (Exception e) {
			logger.log(AVFLoggerLevel.Exception, "Exception in non issue sale request : ", e);
			throw new ApplicationCommunicationException(e);
		}

		return response;
	}

	public static String setTributeLockSaleRequest(Map avfSaleRequestList) throws ApplicationCommunicationException {
		logger.debug("Inside setTributeLockSaleRequest");

		long requestId;
		String response = "";
		try {
			TributeSaleActionatorRemote tributeSaleActionator = (TributeSaleActionatorRemote) BlueMobileEJBUtil
					.getTributeSaleActionatorBean();
			requestId = (long) tributeSaleActionator.insertIntoIncomingRequest(avfSaleRequestList,
					SERVICE_REQUEST_LOCK);
			response = tributeSaleActionator.lockSale(avfSaleRequestList, requestId);
			logger.debug("Incoming Request Id for Tribute lock Sale in TributeSaleHelper" + requestId);
		} catch (Exception e) {
			logger.log(AVFLoggerLevel.Exception, "Exception in lock sale : ", e);
			throw new ApplicationCommunicationException(e);
		}

		return response;
	}

	public static String setTributeUnlockSaleRequest(Map avfSaleRequestList) throws ApplicationCommunicationException {
		logger.debug("Inside setTributeUnlockSaleRequest");

		long requestId;
		String response = "";
		
		try {
			TributeSaleActionatorRemote tributeSaleActionator = (TributeSaleActionatorRemote) BlueMobileEJBUtil
					.getTributeSaleActionatorBean();
			requestId = (long) tributeSaleActionator.insertIntoIncomingRequest(avfSaleRequestList,
					SERVICE_REQUEST_UNLOCK);
			response = tributeSaleActionator.unlockSale(avfSaleRequestList, requestId);
			logger.debug("Incoming Request Id for Tribute Unlock Sale in TributeSaleHelper" + requestId);
		} catch (Exception e) {
			logger.log(AVFLoggerLevel.Exception, "Exception in unlock sale : ", e);
			throw new ApplicationCommunicationException(e);
		}
		return response;
	}

	public static String setTributeAutoUnlockSaleRequest(Map avfSaleRequestList)
			throws ApplicationCommunicationException {
		logger.debug("Inside setTributeAutoUnlockSaleRequest");

		long requestId;
		String response = "";
		try {
			TributeSaleActionatorRemote tributeSaleActionator = (TributeSaleActionatorRemote) BlueMobileEJBUtil
					.getTributeSaleActionatorBean();
			requestId = (long) tributeSaleActionator.insertIntoIncomingRequest(avfSaleRequestList,
					SERVICE_REQUEST_AUTOMATIC_UNLOCK);
			response = tributeSaleActionator.autounlockSale(avfSaleRequestList, requestId);
			logger.debug("Incoming Request Id for Tribute Automatic Unlock Sale in TributeSaleHelper" + requestId);
		} catch (Exception e) {
			logger.log(AVFLoggerLevel.Exception, "Exception in auto unlock sale : ", e);
			throw new ApplicationCommunicationException(e);
		}

		return response;
	}

	public static String setTributeGenerateReferenceRequest(Map avfSaleRequestList)
			throws ApplicationCommunicationException {
		logger.debug("Inside setTributeGenerateReferenceRequest");

		long requestId;
		String response = "";

		try {
			TributeSaleActionatorRemote tributeSaleActionator = (TributeSaleActionatorRemote) BlueMobileEJBUtil
					.getTributeSaleActionatorBean();
			requestId = (long) tributeSaleActionator.insertIntoIncomingRequest(avfSaleRequestList,
					SERVICE_REQUEST_GENERATE);
			response = tributeSaleActionator.generateReference(avfSaleRequestList, requestId);
			logger.debug("Incoming Request Id for Tribute Generate Reference  in TributeSaleHelper" + requestId);
		} catch (Exception e) {
			logger.log(AVFLoggerLevel.Exception, "Exception in generate reference : ", e);
			throw new ApplicationCommunicationException(e);
		}
		return response;
	}

}