package com.atosorigin.bluemobile.dto;

import java.math.BigInteger;
import java.util.Date;

/**
 * This class represents the database object TicketingRecordDto
 * along with get and set methods
 * 
 * @version 1.0
 * @created 17-July-2012 15:21:14
 * @author 42466a
 */
public class SaleRecordDto {

	public BigInteger getLid() {
		return lid;
	}

	public void setLid(BigInteger lid) {
		this.lid = lid;
	}

	public BigInteger id;
	public BigInteger cid;
	public BigInteger tid;
	public BigInteger rid;
	public BigInteger pid;
	public BigInteger nid;
	public BigInteger lid;
	public String original_id;
	public String machine_type;
	public String machine;
	public String user_id;
	public Date last_updated;
	public String sale;
	public String ctr_reference;
	public String surname;
	public String postcode;
	public String refund_reference;
	public String refund_status;
	public String issue_machine;
	public String issue_date;
	public String transaction_number;
	public String business_code;
	public String tis_type;
	public int sequence_number;
	private long loyaltyCardId;
	public String business_group;
	public String refund_created_date;
	private String isrn;
	private String ipeInstanceId;
	private String sequence_alphabet;
	public Long contact_booking_ref;

	
	// CR037

	public long getLoyaltyCardId() {
		return loyaltyCardId;
	}

	public void setLoyaltyCardId(long loyaltyCardId) {
		this.loyaltyCardId = loyaltyCardId;
	}

	public long ticketingRecordId;
	public String travel_date;
	
	public long getTicketingRecordId() {
		return ticketingRecordId;
	}

	public void setTicketingRecordId(long ticketingRecordId) {
		this.ticketingRecordId = ticketingRecordId;
	}


	public String getTravel_date() {
		return travel_date;
	}

	public void setTravel_date(String travel_date) {
		this.travel_date = travel_date;
	}

	/**
	 * @return the sequence_number
	 */
	public int getSequence_number() {
		return sequence_number;
	}

	/**
	 * @param sequence_number
	 *            the sequence_number to set
	 */
	public void setSequence_number(int sequence_number) {
		this.sequence_number = sequence_number;
	}

	/**
	 * @return the business_code
	 */
	public String getBusiness_code() {
		return business_code;
	}

	/**
	 * @param business_code
	 *            the business_code to set
	 */
	public void setBusiness_code(String business_code) {
		this.business_code = business_code;
	}

	/**
	 * @return the tis_type
	 */
	public String getTis_type() {
		return tis_type;
	}

	/**
	 * @param tis_type
	 *            the tis_type to set
	 */
	public void setTis_type(String tis_type) {
		this.tis_type = tis_type;
	}

	/**
	 * @return the id
	 */

	/**
	 * @return the last_updated
	 */
	public Date getLast_updated() {
		return last_updated;
	}

	/**
	 * @param date
	 *            the last_updated to set
	 */
	public void setLast_updated(Date date) {
		this.last_updated = date;
	}

	/**
	 * @return the machine
	 */
	public String getMachine() {
		return machine;
	}

	/**
	 * @param machine
	 *            the machine to set
	 */
	public void setMachine(String machine) {
		this.machine = machine;
	}

	/**
	 * @return the machine_type
	 */
	public String getMachine_type() {
		return machine_type;
	}

	/**
	 * @param machine_type
	 *            the machine_type to set
	 */
	public void setMachine_type(String machine_type) {
		this.machine_type = machine_type;
	}

	/**
	 * @return the original_id
	 */
	public String getOriginal_id() {
		return original_id;
	}

	/**
	 * @param original_id
	 *            the original_id to set
	 */
	public void setOriginal_id(String original_id) {
		this.original_id = original_id;
	}

	/**
	 * @return the sale
	 */
	public String getSale() {
		return sale;
	}

	/**
	 * @param sale
	 *            the sale to set
	 */
	public void setSale(String sale) {
		this.sale = sale;
	}

	/**
	 * @return the user_id
	 */
	public String getUser_id() {
		return user_id;
	}

	/**
	 * @param user_id
	 *            the user_id to set
	 */
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	/**
	 * @return the ctr_reference
	 */
	public String getCtr_reference() {
		return ctr_reference;
	}

	/**
	 * @param ctr_reference
	 *            the ctr_reference to set
	 */
	public void setCtr_reference(String ctr_reference) {
		this.ctr_reference = ctr_reference;
	}

	/**
	 * @return the issue_date
	 */
	public String getIssue_date() {
		return issue_date;
	}

	/**
	 * @param issue_date
	 *            the issue_date to set
	 */
	public void setIssue_date(String issue_date) {
		this.issue_date = issue_date;
	}

	/**
	 * @return the postcode
	 */
	public String getPostcode() {
		return postcode;
	}

	/**
	 * @param postcode
	 *            the postcode to set
	 */
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	/**
	 * @return the refund_reference
	 */
	public String getRefund_reference() {
		return refund_reference;
	}

	/**
	 * @param refund_reference
	 *            the refund_reference to set
	 */
	public void setRefund_reference(String refund_reference) {
		this.refund_reference = refund_reference;
	}

	/**
	 * @return the refund_status
	 */
	public String getRefund_status() {
		return refund_status;
	}

	/**
	 * @param refund_status
	 *            the refund_status to set
	 */
	public void setRefund_status(String refund_status) {
		this.refund_status = refund_status;
	}

	/**
	 * @return the surname
	 */
	public String getSurname() {
		return surname;
	}

	/**
	 * @param surname
	 *            the surname to set
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}

	/**
	 * @return the transaction_number
	 */
	public String getTransaction_number() {
		return transaction_number;
	}

	/**
	 * @param transaction_number
	 *            the transaction_number to set
	 */
	public void setTransaction_number(String transaction_number) {
		this.transaction_number = transaction_number;
	}

	/**
	 * @return the cid
	 */
	public BigInteger getCid() {
		return cid;
	}

	/**
	 * @param cid
	 *            the cid to set
	 */
	public void setCid(BigInteger cid) {
		this.cid = cid;
	}

	/**
	 * @return the nid
	 */
	public BigInteger getNid() {
		return nid;
	}

	/**
	 * @param nid
	 *            the nid to set
	 */
	public void setNid(BigInteger nid) {
		this.nid = nid;
	}

	/**
	 * @return the pid
	 */
	public BigInteger getPid() {
		return pid;
	}

	/**
	 * @param pid
	 *            the pid to set
	 */
	public void setPid(BigInteger pid) {
		this.pid = pid;
	}

	/**
	 * @return the rid
	 */
	public BigInteger getRid() {
		return rid;
	}

	/**
	 * @param rid
	 *            the rid to set
	 */
	public void setRid(BigInteger rid) {
		this.rid = rid;
	}

	/**
	 * @return the tid
	 */
	public BigInteger getTid() {
		return tid;
	}

	/**
	 * @param tid
	 *            the tid to set
	 */
	public void setTid(BigInteger tid) {
		this.tid = tid;
	}

	/**
	 * @param object
	 */
	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(BigInteger id) {
		this.id = id;
	}

	/**
	 * @return the id
	 */
	public BigInteger getId() {
		return id;
	}

	/**
	 * @return the issue_machine
	 */
	public String getIssue_machine() {
		return issue_machine;
	}

	/**
	 * @param issue_machine
	 *            the issue_machine to set
	 */
	public void setIssue_machine(String issue_machine) {
		this.issue_machine = issue_machine;
	}
	
	public String getBusiness_group() {
		return business_group;
	}

	public void setBusiness_group(String business_group) {
		this.business_group = business_group;
	}

	public String getRefund_created_date() {
		return refund_created_date;
	}

	public void setRefund_created_date(String refund_created_date) {
		this.refund_created_date = refund_created_date;
	}
	
	public String getIsrn() {
		return isrn;
	}

	public void setIsrn(String isrn) {
		this.isrn = isrn;
	}

	public String getIpeInstanceId() {
		return ipeInstanceId;
	}

	public void setIpeInstanceId(String ipeInstanceId) {
		this.ipeInstanceId = ipeInstanceId;
	}

	/**
	 * Getter for sequence_alphabet.
	 * 
	 * @return the sequence_alphabet
	 */
	public String getSequence_alphabet() {
		return sequence_alphabet;
	}

	/**
	 * Setter for sequence_alphabet.
	 * 
	 * @param sequence_alphabet the sequence_alphabet to set
	 */
	public void setSequence_alphabet(String sequence_alphabet) {
		this.sequence_alphabet = sequence_alphabet;
	}

	/**
	 * @return the contact_booking_ref
	 */
	public Long getContact_booking_ref() {
		return contact_booking_ref;
	}

	/**
	 * @param contact_booking_ref the contact_booking_ref to set
	 */
	public void setContact_booking_ref(Long contact_booking_ref) {
		this.contact_booking_ref = contact_booking_ref;
	}
	

}