package com.worldline.dts.sale.helper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import com.worldline.dts.sale.dataaccess.Sale;
import com.worldline.dts.sale.dataaccess.SaleCKey;
import com.worldline.dts.sale.dataaccess.SaleCKeyRepository;
import com.worldline.dts.sale.dataaccess.SaleNKey;
import com.worldline.dts.sale.dataaccess.SaleNKeyRepository;
import com.worldline.dts.sale.dataaccess.SalePKey;
import com.worldline.dts.sale.dataaccess.SalePKeyRepository;
import com.worldline.dts.sale.dataaccess.SaleRKey;
import com.worldline.dts.sale.dataaccess.SaleRKeyRepository;
import com.worldline.dts.sale.dataaccess.SaleRepository;
import com.worldline.dts.sale.dataaccess.SaleTKey;
import com.worldline.dts.sale.dataaccess.SaleTKeyRepository;
import com.worldline.dts.sale.model.InsertSaleRequest;
import com.worldline.dts.sale.model.SaleRecordDto;
import com.worldline.dts.sale.service.SaleMapper;

import jakarta.transaction.Transactional;

@Component
public class ProcessInsertSale {

	private final SimpleDateFormat refundDateFormat = new SimpleDateFormat("yyyy-MM-dd"); // Adjust format as needed

	@Autowired
	private SaleRepository saleRepository;
	@Autowired
	private SaleTKeyRepository tSaleRepository;
	@Autowired
	private SaleRKeyRepository rSaleRepository;
	@Autowired
	private SaleNKeyRepository nSaleRepository;
	@Autowired
	private SalePKeyRepository pSaleRepository;
	@Autowired
	private SaleCKeyRepository cSaleRepository;
	@Autowired
	private SaleMapper saleMapper;

	@Transactional
	public String insertSale(InsertSaleRequest request1, Long incomingRequestId) {
		String outputXml = null;
		List<SaleCKey> cKeys = new ArrayList<>();
		List<SaleNKey> nKeys = new ArrayList<>();
		List<SalePKey> pKeys = new ArrayList<>();
		List<SaleRKey> rKeys = new ArrayList<>();
		try {
			SaleRecordDto dto = saleMapper.mapToEntity(request1);

			// Validate required data from DTO
			if (dto == null) {
				return errorXml("01", "Input message is in invalid format");
			}
			Sale sale = new Sale();
			sale.setOriginalId(Long.valueOf(dto.getOriginalId()));
			sale.setMachineType(dto.getMachineType());
			sale.setMachine(dto.getMachine());
			sale.setUserId(dto.getUserId());
			sale.setLastUpdated(dto.getLastUpdated());
			sale.setSale(dto.getSale().toString());
			sale.setBusinessGroup(dto.getBusinessGroup());
			//sale.setContactBookingRef(dto.getContactBookingRef());

	        if (dto.getContactBookingRef() != null)
	            sale.setContactBookingRef(dto.getContactBookingRef());

	        sale.setLastUpdated(new Date());

	        // Save sale to generate ID
	        sale = saleRepository.save(sale);
	        
			String ctrReference = dto.getCtrReference();
			if (ctrReference != null && !ctrReference.equals("~")) {
				SaleCKey cKey = new SaleCKey();
				cKey.setCtrReference(ctrReference);
				cKey.setSale(sale);
				cKeys.add(cKey);
	            cSaleRepository.save(cKey);

			}

			String postcode = dto.getPostcode();
			if (postcode != null && !postcode.trim().isEmpty()) {
				SalePKey pKey = new SalePKey();
				pKey.setPostcode(postcode);
				pKey.setSale(sale);
				pKeys.add(pKey);
                pSaleRepository.save(pKey);
			}
			
		      if (dto.getSurname() != null && !dto.getSurname().trim().isEmpty()) {
		    	            SaleNKey nKey = new SaleNKey();
		                    nKey.setSurname(dto.getSurname());
		                    nKey.setSale(sale);
		                    nSaleRepository.save(nKey);
		                }
		           

			if (StringUtils.isNotBlank(dto.getRefundReference()) || StringUtils.isNotBlank(dto.getRefundStatus())) {
				String refundStatus = dto.getRefundStatus();
				if (refundStatus == null || refundStatus.isBlank()) {
					refundStatus = "Pending"; // Default
				}

				SaleRKey rKey = new SaleRKey();
				rKey.setRefundReference(dto.getRefundReference());
				rKey.setRefundStatus(dto.getRefundStatus());

				try {
					Date createdDate = dto.getRefundCreatedDate() != null
							? new SimpleDateFormat("yyyyMMdd").parse(dto.getRefundCreatedDate())
							: null;
					rKey.setRefundCreatedDate(createdDate);
				} catch (ParseException e) {
					rKey.setRefundCreatedDate(null); // fallback on failure
				}

				rKey.setSale(sale); // associate with parent sale
				rKeys.add(rKey);
				rSaleRepository.save(rKey);
			}



//		 int length;
//
//         // Process refund references
//		 int refundSize = dto.getRefundReferenceSize();
//         for (int i = 0; i < refundSize; i++) {
//             String ref = dto.getRefundReference();;
//             String status = dto.getRefundStatus();
//             String refCreatedDateStr = dto.getRefundCreatedDate();
//             Date createdDate = parseDate(refCreatedDateStr);
//
//             if (ref == null || ref.trim().isEmpty() || refundRefList.contains(ref))
//                 continue;
//
//             if (rSaleRepository.existsByRefundReference(ref))
//                 continue;
//
//             refundRefList.add(ref);
//             SaleRKey rSale = new SaleRKey();
//             rSale.setRefundReference(ref);
//             rSale.setRefundStatus(status);
//             rSale.setRefundCreatedDate(createdDate);
//             rSale.setSale(sale);
//             rSaleRepository.save(rSale);
//         }
//
//         // Process postcodes
//         int postcodeSize = Integer.parseInt(dto.getPostcode("postcode_size", "0"));
//         for (int i = 0; i < postcodeSize; i++) {
//             String postcode = dto.getPostcode();
//             if (postcode != null && !postcode.trim().isEmpty()) {
//                 SalePKey pSale = new SalePKey();
//                 pSale.setPostcode(postcode);
//                 pSale.setSale(sale);
//                 pSaleRepository.save(pSale);
//             }
//         }
//
//         // Process surnames
//         int surnameSize = Integer.parseInt(dto.getOrDefault("surname_size", "0"));
//         for (int i = 0; i < surnameSize; i++) {
//             String surname =dto.getSurname();
//             if (surname != null && !surname.trim().isEmpty()) {
//                 SaleNKey nSale = new SaleNKey();
//                 nSale.setSurname(surname);
//                 nSale.setSale(sale);
//                 nSaleRepository.save(nSale);
//             }
//         }

//         // Process transactions
//         int txnSize = Integer.parseInt(dto.getOrDefault("transaction_size", "0"));
//         for (int i = 0; i < txnSize; i++) {
   //         String transactionNumber = request1.get("transaction" + i);

//             String issueDateStr = request1.get("issue_date" + i);
//             String machine = request1.get("machine" + i);
//             String isrn = request1.getOrDefault("isrn" + transactionNumber, null);
//             String ipeInstanceId = request1.getOrDefault("ipe_instanceId" + transactionNumber, null);
//             String travelDateStr = request1.getOrDefault("travel_date" + i, null);
//
//             SaleTKey tSale = new SaleTKey();
//             tSale.setTransactionNumber(transactionNumber);
//             tSale.setIssueDate(issueDateStr);
//             tSale.setMachine(machine);
//             tSale.setSale(sale);
//             tSale.setTicketingRecordId(0L);
//
//             tSale.setIsrn(isrn);
//             tSale.setIpeInstanceId(ipeInstanceId);
//             tSale.setTravelDate(travelDateStr);
//             tSaleRepository.save(tSale);
//         }
//
//         // Save Nectar if loyalty ID set
//         if (dto.getLoyaltyCardId() !=null  && dto.getLoyaltyCardId() != 0) {
//             var nectar = new Nectar();
//             nectar.setSale(sale);
//             nectarRepository.save(nectar);
//         }

			// Build output xml
			outputXml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation ID=\"" + sale.getId()
					+ "\"><Errors></Errors><Warnings></Warnings></Confirmation>";

		} catch (Exception e) {
			outputXml = errorXml("99", "Unexpected system failure");
		} finally {
			// Cleanup if needed
		}
		return outputXml;
	}

	private String errorXml(String code, String message) {
		return "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>" + "<code>" + code
				+ "</code><desc>" + message + "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
	}

	private Date parseDate(String dateStr) {
		if (dateStr == null || dateStr.trim().isEmpty())
			return null;
		try {
			return new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
		} catch (ParseException e) {
			return null;
		}
	}
}
