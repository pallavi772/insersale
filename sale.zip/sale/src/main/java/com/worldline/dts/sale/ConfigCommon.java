/*
 * Copyright: 2022, Worldline, DTS.
 */
package com.worldline.dts.sale;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Configuration
@EnableJpaRepositories(basePackages ={"com.worldline.dts.common.dataaccess", "com.worldline.dts.sale.dataaccess"})
@EntityScan(basePackages = {"com.worldline.dts.common.dataaccess", "com.worldline.dts.sale.dataaccess"})
@ComponentScan(basePackages = {"com.worldline.dts.common.dataaccess", "com.worldline.dts.common.model"})
public class ConfigCommon {
	
}
