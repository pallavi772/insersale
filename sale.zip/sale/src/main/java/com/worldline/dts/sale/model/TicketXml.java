package com.worldline.dts.sale.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class TicketXml {


	@XmlAttribute(name = "ApplicationTicketId")
    private String applicationTicketId;

    @XmlAttribute(name = "Class")
    private String ticketClass;

    @XmlAttribute(name = "Destination")
    private String destination;

    @XmlAttribute(name = "DiscountCode")
    private String discountCode;

    @XmlAttribute(name = "DiscountPercent")
    private String discountPercent;

    @XmlAttribute(name = "FareAmount")
    private String fareAmount;

    @XmlAttribute(name = "FulfilmentMethod")
    private String fulfilmentMethod;

    @XmlAttribute(name = "IssueDate")
    private String issueDate;

    @XmlAttribute(name = "NumAAA")
    private String numAAA;

    @XmlAttribute(name = "NumAdults")
    private String numAdults;

    @XmlAttribute(name = "NumChildren")
    private String numChildren;

    @XmlAttribute(name = "NumCoupons")
    private String numCoupons;

    @XmlAttribute(name = "Origin")
    private String origin;

    @XmlAttribute(name = "PackageNumber")
    private String packageNumber;

    @XmlAttribute(name = "ProductType")
    private String productType;

    @XmlAttribute(name = "PromotionCode")
    private String promotionCode;

    @XmlAttribute(name = "Railcard")
    private String railcard;

    @XmlAttribute(name = "Route")
    private String route;

    @XmlAttribute(name = "Status")
    private String status;

    @XmlAttribute(name = "TicketType")
    private String ticketType;

    @XmlAttribute(name = "TransactionNumber")
    private String transactionNumber;

    @XmlElement(name = "TicketDetails")
    private TicketDetailsXml ticketDetails;

    @XmlElement(name = "LoyaltyDetail")
    private LoyaltyDetailXml loyaltyDetail;

    @XmlElement(name = "IssueDate")
    private String issueDateElement;

    @XmlElement(name = "TransactionNumber")
    private String transactionNumberElement;

} 


