package com.worldline.dts.sale.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class LoyaltyDetail {
	
	 @XmlAttribute(name = "LoyaltyType")
	    private String loyaltyType;

	    @XmlElement(name = "LoyaltyCardId")
	    private String loyaltyCardId;

}
