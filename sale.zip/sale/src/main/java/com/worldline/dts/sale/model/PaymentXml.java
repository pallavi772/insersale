package com.worldline.dts.sale.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import lombok.Data;

@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class PaymentXml {

	@XmlAttribute(name = "MOP")
	private String mop;

	@XmlAttribute(name = "PaymentRefundFlag")
	private String paymentRefundFlag;

	@XmlAttribute(name = "WebTISPaymentId")
	private String webTISPaymentId;

	@XmlAttribute(name = "Amount")
	private String amount;

	@XmlAttribute(name = "PANHandle")
	private String panHandle;

	@XmlAttribute(name = "MaskedPAN")
	private String maskedPAN;

	@XmlAttribute(name = "Expiry")
	private String expiry;

	@XmlAttribute(name = "StartDate")
	private String startDate;

	@XmlAttribute(name = "AuthCode")
	private String authCode;

	@XmlAttribute(name = "IssueNumber")
	private String issueNumber;

	@XmlAttribute(name = "CompanyCode")
	private String companyCode;

	@XmlAttribute(name = "CompanySubType")
	private String companySubType;

	@XmlAttribute(name = "NotionalPayment")
	private String notionalPayment;

}
