package com.worldline.dts.sale.dataaccess;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

/**
 * This class describes the data model for sale_lock.
 * 
 * @author A638752
 */
@Data
@Entity
@Table(name = "sale_lock")
public class SaleLock {
	
	@Id
	@Column(name="sale_id")
	private Long saleId;
	
	@Column(name="machine_type")
	private String machineType;
	
	@Column(name="machine")
	private String machine;
	
	@Column(name="user_id")
	private String userId;
	
	@Column(name="last_updated")
	private Date lastUpdated;

	
}
