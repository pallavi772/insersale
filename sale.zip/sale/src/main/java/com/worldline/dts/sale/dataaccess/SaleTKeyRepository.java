package com.worldline.dts.sale.dataaccess;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SaleTKeyRepository extends JpaRepository<SaleTKey, Long>{

}
