package com.worldline.dts.sale.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
	@XmlAccessorType(XmlAccessType.FIELD)
	public class SaleXml {

	    @XmlAttribute(name = "BusinessGroup")
	    private String businessGroup;

	    @XmlAttribute(name = "CTRReference")
	    private String ctrReference;

	    @XmlAttribute(name = "Fulfilment")
	    private String fulfilment;

	    @XmlAttribute(name = "IssueMachine")
	    private String issueMachine;

	    @XmlAttribute(name = "IssueMachineType")
	    private String issueMachineType;

	    @XmlAttribute(name = "IssueOffice")
	    private String issueOffice;

	    @XmlAttribute(name = "IssueWindow")
	    private String issueWindow;

	    @XmlAttribute(name = "SaleIssueDate")
	    private String saleIssueDate;

	    @XmlAttribute(name = "SaleNumber")
	    private String saleNumber;

	    @XmlElement(name = "Tickets")
	    private TicketsXml tickets;

	    @XmlElement(name = "Sundries")
	    private SundriesXml sundries;

	    @XmlElement(name = "Payments")
	    private PaymentsXml payments;

	    @XmlElement(name = "Refunds")
	    private RefundsXml refunds;

}
