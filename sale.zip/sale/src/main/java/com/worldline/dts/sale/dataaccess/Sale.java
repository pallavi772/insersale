package com.worldline.dts.sale.dataaccess;

import java.util.Date;
import java.util.List;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "sale")
@Data
public class Sale {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "original_id")
	private Long originalId;
	@Column(name = "machine_type")
	private String machineType;
	@Column(name = "machine")
	private String machine;
	@Column(name = "user_id")
	private String userId;
	@Column(name = "last_updated")
	private Date lastUpdated;
	@Column(name = "sale")
	private String sale;
	@Column(name = "business_group")
	private String businessGroup;
	@Column(name = "contact_booking_ref")
	private String contactBookingRef;

	@OneToMany(mappedBy = "sale", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<SaleCKey> cSale;

	@OneToMany(mappedBy = "sale", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<SaleNKey> nSale;

	@OneToMany(mappedBy = "sale", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<SalePKey> pSale;

	@OneToMany(mappedBy = "sale", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<SaleRKey> rSale;
	
	@OneToMany(mappedBy = "sale", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<SaleTKey> tSale;

//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "incoming_request_id")
//	private IncomingRequest incomingRequest;
}
