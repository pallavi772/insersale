package com.worldline.dts.sale.dataaccess;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import jakarta.transaction.Transactional;

public interface SaleLockRepository extends JpaRepository<SaleLock, Long> {
	
	@Modifying
	@Transactional
	@Query(value = "DELETE FROM sale_lock WHERE DATEDIFF(mi, last_updated, getdate()) > ?1", nativeQuery = true)
	void deleteByLastUpdated(int min);

}
