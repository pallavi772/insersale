package com.worldline.dts.sale.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class LoyaltyDetailXml {
	
	 @XmlAttribute(name = "LoyaltyType")
	    private String loyaltyType;

	    @XmlAttribute(name = "SponsorId")
	    private String sponsorId;

	    @XmlAttribute(name = "TransactionId")
	    private String transactionId;

	    @XmlAttribute(name = "LocationId")
	    private String locationId;

	    @XmlAttribute(name = "LoyaltyCardId")
	    private String loyaltyCardIdAttr;

	    @XmlAttribute(name = "OfferCode")
	    private String offerCode;

	    @XmlAttribute(name = "Points")
	    private String points;

	    @XmlElement(name = "LoyaltyCardId")
	    private String loyaltyCardIdElement;

}
