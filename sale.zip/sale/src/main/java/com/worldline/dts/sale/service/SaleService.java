package com.worldline.dts.sale.service;

import java.io.StringReader;
import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.worldline.dts.common.logger.DTSLogger;
import com.worldline.dts.sale.dataaccess.BookingRepository;
import com.worldline.dts.sale.dataaccess.IncomingRequest;
import com.worldline.dts.sale.dataaccess.IncomingRequestRepository;
import com.worldline.dts.sale.helper.ProcessInsertSale;
import com.worldline.dts.sale.model.InsertSaleRequest;
import com.worldline.dts.sale.model.SaleRecordDto;
import com.worldline.dts.sale.parsers.InsertSaleParser;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;

@Service

public class SaleService {

	private static DTSLogger log = DTSLogger.getLogger(SaleService.class);

	@Autowired
	private IncomingRequestRepository incomingRequestRepository;
	@Autowired
	private ProcessInsertSale processInsertSale;
	@Autowired
	private InsertSaleParser parser;
      @Autowired
	private BookingRepository bookingRepository;
      
	String ticketIssuer = "TRIBUTE";

	public String processSaleSearch(String xmlPayload) {
		try {
			log.info("Processing sale request" + xmlPayload);

			if (xmlPayload == null || xmlPayload.trim().isEmpty()) {
				return buildErrorXml("01", "Missing or empty XML payload");
			}
            
			IncomingRequest request = new IncomingRequest();
			request.setRawMessage(xmlPayload);
			request.setTicketIssuer(ticketIssuer);
			if (ticketIssuer == null || ticketIssuer.trim().isEmpty()) {
				ticketIssuer = "UNKNOWN";
			}

			request.setTicketIssuer(ticketIssuer);
			request.setLastUpdated(new Date());
			request = incomingRequestRepository.save(request);

			long incomingRequestId = request.getId();
			JAXBContext context = JAXBContext.newInstance(InsertSaleRequest.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            StringReader reader = new StringReader(xmlPayload);
            InsertSaleRequest request1 = (InsertSaleRequest) unmarshaller.unmarshal(reader);
			return processInsertSale.insertSale(request1, incomingRequestId);

		} catch (Exception ex) {
			return buildErrorXml("99", "Unexpected system failure: " + ex.getMessage());
		}
	}

//            // 2. Process sale
//            InsertSaleRequestDTO dto = new InsertSaleRequestDTO();
//            dto.setInputxml(xmlPayload);
//            outputXml = insertSale(dto, request.getId());
//        } catch (Exception e) {
//            outputXml = generateErrorXml("99", "Unexpected system failure");
//        }
//
//        return outputXml;
//    }
	private String buildErrorXml(String code, String desc) {
		return "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>" + "<code>" + code
				+ "</code><desc>" + desc + "</desc>" + "</Error></Errors><Warnings></Warnings></Confirmation>";
	}

//    private String insertSale(InsertSaleRequestDTO tributeInsertSaleRequest, long incomingRequestId) throws Exception {
//        String inputXml = tributeInsertSaleRequest.getInputxml();
//       Map<String, String> insertSaleMap = //tributeInsertSaleParser.parseInput(inputXml);
//
//        if (insertSaleMap == null || insertSaleMap.isEmpty()) {
//            return generateErrorXml("01", "Input message is in invalid format");
//        }
//
//        Sale saleRecord = new Sale();
//        saleRecord.setOriginalId("0");
//        //saleRecord.setIncomingRequestId(incomingRequestId);
//
//        // Set core fields
//        saleRecord.setMachineType(insertSaleMap.get("machine_type"));
//       // saleRecord.setCtrReference(insertSaleMap.get("ctr_reference"));
//        saleRecord.setMachine(insertSaleMap.get("machine"));
//       // saleRecord.setIssueMachine(insertSaleMap.get("issue_machine"));
//        saleRecord.setUserId(insertSaleMap.get("userid"));
//        saleRecord.setSale(insertSaleMap.get("sale_element"));
//        saleRecord.setBusinessGroup(insertSaleMap.get("business_group"));
//
//        if (insertSaleMap.containsKey("contact_booking_reference")) {
//            saleRecord.setContactBookingRef(Long.parseLong(insertSaleMap.get("contact_booking_reference")));
//        }
//
//        if (insertSaleMap.containsKey("loyalty_card_id")) {
//            //saleRecord.setLoyaltyCardId(Long.parseLong(insertSaleMap.get("loyalty_card_id")));
//        }
//
//        // Save main sale record
//        saleRecord = saleRepository.save(saleRecord);
//
//        // You can handle insert logic for TSale, PSale, NSale, RSale using similar JPA repositories
//
//        return "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation ID=\"" + saleRecord.getId() +
//                "\"><Errors></Errors><Warnings></Warnings></Confirmation>";
//    }
//
//    private String generateErrorXml(String code, String description) {
//        return "<?xml version=\"1.0\" encoding=\"utf-8\"?><Confirmation><Errors><Error>" +
//                "<code>" + code + "</code><desc>" + description + "</desc></Error></Errors><Warnings></Warnings></Confirmation>";
//    }
//    

	/*
	 * public String processSaleSearch(String inputXml) throws Exception { // 1.
	 * Insert into incoming_request IncomingRequest request = new IncomingRequest();
	 * request.setRawMessage(inputXml); request.setTicketIssuer("InsertSale");
	 * 
	 * request.setLastUpdated(new Date()); request =
	 * incomingRequestRepository.save(request);
	 * 
	 * long incomingRequestId = request.getId();
	 * 
	 * // 2. Wrap into DTO InsertSaleRequestDTO saleRequest = new
	 * InsertSaleRequestDTO(); saleRequest.setInputxml(inputXml);
	 * 
	 * // 3. Delegate to legacy insertSale logic return
	 * tributeMessageHelper.insertSale(saleRequest, incomingRequestId); }
	 */
}
