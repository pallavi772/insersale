package com.worldline.dts.sale.dataaccess;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Entity
@Table(name = "sale_rkeys")
@Data
public class SaleRKey {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank(message = "refund_reference must not be blank")
	@Column(name = "refund_reference")
    private String refundReference;

	@NotBlank(message = "refund_status must not be blank")
    @Column(name = "refund_status", nullable = false)
    private String refundStatus;

    @Column(name = "refund_created_date", nullable = false)
    private Date refundCreatedDate;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "sale_id" , nullable = false)
	private Sale sale;


}
