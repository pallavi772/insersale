package com.worldline.dts.sale.scheduler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.worldline.dts.common.logger.DTSLogger;
import com.worldline.dts.sale.dataaccess.SaleLockRepository;

import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;

@Component
public class AutoUnlockSaleScheduler {

	private static DTSLogger log = DTSLogger.getLogger(AutoUnlockSaleScheduler.class);
	
	@Autowired
	private SaleLockRepository saleLockRepository;

	@Value("${autoUnlockSale.retention.minutes}")
	private int autoUnlockSaleRetentionMinutes;
	
	@Scheduled(cron = "${autoUnlockSale.cron}")
	@SchedulerLock(name = "autoUnlockSale_scheduledJob", lockAtMostFor = "${autoUnlockSale.scheduler.lockAtMostFor}", lockAtLeastFor = "${autoUnlockSale.scheduler.lockAtLeastFor}")
	public void autoUnlockSaleJob() {
		log.debug("In AutoUnlockSale Scheduler Job");
		try {
			saleLockRepository.deleteByLastUpdated(autoUnlockSaleRetentionMinutes);
		}
		catch (Exception e) {
			log.error("Exception occured in autoUnlockSaleJob " + e.getMessage());
		}
		
	}


}
