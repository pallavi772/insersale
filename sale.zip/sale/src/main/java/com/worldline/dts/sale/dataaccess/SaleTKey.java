package com.worldline.dts.sale.dataaccess;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "sale_tkeys")
@Data
public class SaleTKey {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "ticketing_record_id")
    private Long ticketingRecordId;

    @Column(name = "transaction_number")
    private String transactionNumber;

    @Column(name = "issue_date")
    private String issueDate;

    @Column(name = "travel_date")
    private String travelDate;
    
	@Column(name = "machine")
	private String machine;

    @Column(name = "isrn")
    private String isrn;
    
    @Column(name = "ipe_instance_id")
    private String ipeInstanceId;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "sale_id" , nullable = false)
	private Sale sale;

}
