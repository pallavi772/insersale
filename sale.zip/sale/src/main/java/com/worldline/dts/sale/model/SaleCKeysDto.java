package com.worldline.dts.sale.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import lombok.Data;

@Data
public class SaleCKeysDto {

	  @JacksonXmlProperty(localName = "ctr_reference")
	    private String ctrReference;
}
