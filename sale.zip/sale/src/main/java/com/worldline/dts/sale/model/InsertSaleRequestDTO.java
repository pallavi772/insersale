package com.worldline.dts.sale.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class InsertSaleRequestDTO {
	
	public String inputxml;
	public String id;
	public String original_id;
	public String machine_type;
	public String machine;
	public String user_id;
	public String last_updated;
	public String sale;

}
