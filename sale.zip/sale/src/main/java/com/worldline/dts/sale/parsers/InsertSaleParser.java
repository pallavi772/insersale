package com.worldline.dts.sale.parsers;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.worldline.dts.common.logger.DTSLogger;
import com.worldline.dts.sale.dataaccess.BookingRepository;

@Component
public class InsertSaleParser  {
	
	private static DTSLogger log = DTSLogger.getLogger(InsertSaleParser.class);

	
	@Autowired
	private BookingRepository bookingRepository;


	public Map<String, String> parseInput(String inputXml,BookingRepository bookingRepository) {
		Map<String, String> insertSaleMap = new HashMap<>();
	    List<String> insertSaleTransactionList = new ArrayList<>();
	    List<String> insertSaleIssueDateList = new ArrayList<>();
	    List<String> insertSaleTravelDateList = new ArrayList<>();
	    List<String> refundReferenceList = new ArrayList<>();
	    List<String> refundStatusList = new ArrayList<>();
	    List<String> surnameList = new ArrayList<>();
	    List<String> transactionList = new ArrayList<>();
	    List<String> issueDateList = new ArrayList<>();
	    List<String> postCodeList = new ArrayList<>();
	    List<String> travelDateList = new ArrayList<>();
	    
	    String sale_element = null;
	    String saleXmlStr = null;
	    String issue_machine = null;
	    String machine_type = null;
	    String machine = null;
	    String userid = null;
	    String loyalty_card_id = null;
	    String refund_status = null;
	    String refund_reference = null;
	    String sundry_issue_date = null;
	    String sundry_transaction_no = null;
	    String issue_date = null;
	    String transaction_no = null;
	    String product_type = "";
	    
	    try {
	        // Parse XML
	        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	        DocumentBuilder db = dbf.newDocumentBuilder();
	        Document document = db.parse(new InputSource(new StringReader(inputXml)));
	        Element root = document.getDocumentElement();

	        // Extract core attributes
	        machine_type = root.getAttribute("MachineType");
	        machine = root.getAttribute("Machine");
	        userid = root.getAttribute("UserID");

	        if (isBlank(machine_type) || isBlank(machine) || isBlank(userid)) {
	            // missing core attributes, return null
	            return null;
	        }

	        insertSaleMap.put("machine_type", machine_type);
	        insertSaleMap.put("machine", machine);
	        insertSaleMap.put("userid", userid);

	        // Generate sale_element string
	        StringWriter writer = new StringWriter();
	        Transformer transformer = TransformerFactory.newInstance().newTransformer();
	        transformer.transform(new DOMSource(document), new StreamResult(writer));
	        String fullXmlString = writer.toString();

	        // Extract <Sale> element string
	        if (fullXmlString.startsWith("<?xml ")) {
	            int startIdx = fullXmlString.indexOf("<Sale");
	            if (startIdx != -1) {
	                String saleStr = fullXmlString.substring(startIdx);
	                int endIdx = saleStr.indexOf("</Sale>");
	                if (endIdx != -1) {
	                    sale_element = saleStr.substring(0, endIdx + 7);
	                    insertSaleMap.put("sale_element", sale_element);
	                } else {
	                    return null; // no </Sale> found
	                }
	            } else {
	                return null; // no <Sale> found
	            }
	        } else {
	            return null; // not starting with xml declaration
	        }

	        // Process <Sale> nodes
	        NodeList saleNodes = document.getElementsByTagName("Sale");
	        if (saleNodes.getLength() > 0) {
	            for (int i = 0; i < saleNodes.getLength(); i++) {
	                Element saleElem = (Element) saleNodes.item(i);
	                String ctrRef = getNodeValue(saleElem, "CTRReference");
	                if (ctrRef != null) {
	                    insertSaleMap.put("ctr_reference", ctrRef);
	                    addBookingReference(db, transformer, saleElem, bookingRepository, ctrRef);
	                } else {
	                    insertSaleMap.put("ctr_reference", "~");
	                }

	                String issueMachine = getNodeValue(saleElem, "IssueMachine");
	                if (issueMachine != null) {
	                    insertSaleMap.put("issue_machine", issueMachine);
	                }

	                // Process BusinessGroup attribute
	                if (saleElem.hasAttribute("BusinessGroup")) {
	                    String bg = saleElem.getAttribute("BusinessGroup");
	                    if (isNotBlank(bg)) {
	                        insertSaleMap.put("business_group", bg);
	                    }
	                }

	                // Populate booking reference if present
	                populateBookingReference(saleElem,insertSaleMap);
	            }
	        } else {
	            return null;
	        }

	        // LoyaltyDetail processing
	        NodeList loyaltyNodes = document.getElementsByTagName("LoyaltyDetail");
	        if (loyaltyNodes.getLength() > 0) {
	            Element loyaltyEl = (Element) loyaltyNodes.item(0);
	            String loyaltyId = getNodeValue(loyaltyEl, "LoyaltyCardId");
	            if (loyaltyId != null) {
	                insertSaleMap.put("loyalty_card_id", loyaltyId);
	            } else {
	                return null;
	            }
	        }

	        // Process Ticket nodes
	        NodeList ticketNodes = document.getElementsByTagName("Ticket");
	        String productType = "";
	        for (int i = 0; i < ticketNodes.getLength(); i++) {
	            Element ticketEl = (Element) ticketNodes.item(i);
	            String issueDate = getNodeValue(ticketEl, "IssueDate");
	            String transNo = getNodeValue(ticketEl, "TransactionNumber");
	            if (issueDate != null) {
	                insertSaleIssueDateList.add(issueDate);
	            }
	            if (transNo != null) {
	                transaction_no = transNo;
	                insertSaleTransactionList.add(transaction_no);
	            }

	            // Collect attributes
	            if (ticketEl.hasAttribute("ISRN") && isNotBlank(ticketEl.getAttribute("ISRN"))) {
	                insertSaleMap.put("isrn" + transaction_no, ticketEl.getAttribute("ISRN"));
	            }
	            if (ticketEl.hasAttribute("IPEInstanceId") && isNotBlank(ticketEl.getAttribute("IPEInstanceId"))) {
	                insertSaleMap.put("ipe_instanceId" + transaction_no, ticketEl.getAttribute("IPEInstanceId"));
	            }

	            // ProductType
	            NodeList productNodes = ticketEl.getElementsByTagName("ProductType");
	            if (productNodes.getLength() > 0) {
	                String pt = getNodeValue((Element) productNodes.item(0), null);
	                if (isNotBlank(pt)) {
	                    productType = pt;
	                }
	            }

	            // For TT products, process OutwardDate / TicketDetail
	            if ("TT".equalsIgnoreCase(productType)) {
	                NodeList ticketDetailNodes = ticketEl.getElementsByTagName("TicketDetail");
	                if (ticketDetailNodes.getLength() > 0) {
	                    Element td = (Element) ticketDetailNodes.item(0);
	                    String outwardDate = getNodeValue(td, "OutwardDate");
	                    if (outwardDate != null) {
	                        insertSaleTravelDateList.add(outwardDate);
	                    }
	                }
	            }
	            // For SE products, process SeasonDetail / StartDate etc.
	            if ("SE".equalsIgnoreCase(productType)) {
	                NodeList seasonNodes = ticketEl.getElementsByTagName("SeasonDetail");
	                if (seasonNodes.getLength() > 0) {
	                    Element sd = (Element) seasonNodes.item(0);
	                    String startDate = getNodeValue(sd, "StartDate");
	                    if (startDate != null) {
	                        insertSaleTravelDateList.add(startDate);
	                    }
	                }
	            }
	        }

	        // Process Sundry nodes
	        NodeList sundryNodes = document.getElementsByTagName("Sundry");
	        for (int i = 0; i < sundryNodes.getLength(); i++) {
	            Element sundry = (Element) sundryNodes.item(i);
	            String issueDate = getNodeValue(sundry, "IssueDate");
	            if (issueDate != null) insertSaleIssueDateList.add(issueDate);
	            String transNo = getNodeValue(sundry, "TransactionNumber");
	            if (transNo != null) insertSaleTransactionList.add(transNo);
	        }

	        // Process Refund nodes
	        NodeList refundNodes = document.getElementsByTagName("Refund");
	        List<String> refundRefList = new ArrayList<>();
	        //List<String> refundStatusList = new ArrayList<>();
	        List<String> refundSurnameList = new ArrayList<>();
	        List<String> refundPostCodeList = new ArrayList<>();
	        for (int i = 0; i < refundNodes.getLength(); i++) {
	            Element refundEl = (Element) refundNodes.item(i);
	            String surnameVal = getNodeValue(refundEl, "Surname");
	            String postCodeVal = getNodeValue(refundEl, "Postcode");
	            String refundStatusVal = getNodeValue(refundEl, "RefundStatus");
	            String refundRefVal = getNodeValue(refundEl, "RefundReference");
	            String createdDate = null;
	            if (refundEl.hasAttribute("CreatedDateTime")) {
	                createdDate = refundEl.getAttribute("CreatedDateTime");
	            } else if (refundEl.hasAttribute("CreationDateTime")) {
	                createdDate = refundEl.getAttribute("CreationDateTime");
	            }
	            // Collect data
	            if (refundRefVal != null) {
	                refundRefList.add(refundRefVal);
	                refundStatusList.add(refundStatusVal != null ? refundStatusVal : "");
	                refundSurnameList.add(surnameVal != null ? surnameVal : "~");
	                refundPostCodeList.add(postCodeVal != null ? postCodeVal : "~");
	                if (!isBlank(createdDate)) {
	                    // Store created date tied to refundRef
	                    insertSaleMap.put("createdDate" + refundRefVal, createdDate);
	                }
	            }
	        }

	        // Store refund references and statuses by list size
	        insertSaleMap.put("refund_reference_size", String.valueOf(refundRefList.size()));
	        for (int i = 0; i < refundRefList.size(); i++) {
	            insertSaleMap.put("refund_reference" + i, refundRefList.get(i));
	            insertSaleMap.put("refund_status" + i, refundStatusList.get(i));
	        }

	        // Populate counts, arrays for postcodes, surnames, transactions, issue dates, travel dates
	        setListDataInMap("transaction", insertSaleTransactionList, insertSaleMap);
	        setListDataInMap("issue_date", insertSaleIssueDateList, insertSaleMap);
	        setListDataInMap("travel_date", insertSaleTravelDateList, insertSaleMap);
	        setListDataInMap("postcode", postCodeList, insertSaleMap);
	        setListDataInMap("surname", surnameList, insertSaleMap);

	    } catch (Exception e) {
	      //  logger.log(AVFLoggerLevel.Exception, "Error in parseInput: " + e.getMessage(), e);
	        return null;
	    }
	    // Return the populated map (or null if error)
	    return insertSaleMap;
	}

	// Helper method to populate list counts/values in map
	private void setListDataInMap(String prefix, List<String> list, Map<String, String> map) {
	    String keySize = prefix + "_size";
	    map.put(keySize, String.valueOf(list.size()));
	    for (int i = 0; i < list.size(); i++) {
	        map.put(prefix + i, list.get(i));
	    }
	}

	// Helper: get node value
	private String getNodeValue(Element parent, String tagName) {
	    if (parent == null) return null;
	    NodeList nl = parent.getElementsByTagName(tagName);
	    if (nl.getLength() == 0) return null;
	    Node node = nl.item(0);
	    if (node == null || !node.hasChildNodes()) return null;
	    return node.getChildNodes().item(0).getNodeValue();
	}

	// Helper: is blank
	private boolean isBlank(String s) {
	    return s == null || s.trim().isEmpty();
	}
	
	private boolean isNotBlank(String str) {
        return str != null && !str.trim().isEmpty();
    }
	
	private void addBookingReference(
		      DocumentBuilder db,
		      Transformer transformer,
		      Element saleElement,
		      BookingRepository bookingRepository,
		      String ctrRef) throws Exception {

		    // If booking reference not present in map, try to fetch and update
		    // Fetch BookingRef using your DAO
		    String bookingRef = bookingRepository.findBookingReferenceByCtrReference(ctrRef);
		    if (isNotBlank(bookingRef)) {
		        // Update the sale XML
		        Document doc = db.parse(new InputSource(new StringReader("sale_element")));
		        Element root = (Element) doc.getDocumentElement();
		        root.setAttribute("ContactBookingReference", bookingRef);

		        StringWriter sw = new StringWriter();
		        transformer.transform(new DOMSource(doc), new StreamResult(sw));
		        String updatedXml = sw.toString();

		        // Update the main map or sale_element string with new XML
		        String saleStr = updatedXml.substring(updatedXml.indexOf("<Sale"));
		        // You can store or process this string as needed
		        // For example:
		        // insertSaleMap.put("sale_element", saleStr);
		    }
		}

	private void populateBookingReference(Element saleElem, Map<String, String> saleMap) {
	    if (!saleMap.containsKey("contact_booking_reference")) {
	        String contactRef = getNodeValue(saleElem, "ContactBookingReference");
	        if (isNotBlank(contactRef))
	            saleMap.put("contact_booking_reference", contactRef);
	    }
	}
		
	}
//        Map<String, String> saleMap = new HashMap<>();
//
//        try {
//        	DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
//            Document document = documentBuilder.parse(new InputSource(new StringReader(inputXml)));
//            document.getDocumentElement().normalize();
//
//            Element root = document.getDocumentElement();
//            String machineType = root.getAttribute("MachineType");
//            String machine = root.getAttribute("Machine");
//            String userId = root.getAttribute("UserID");
//
//            saleMap.put("machine_type", machineType);
//            saleMap.put("machine", machine);
//            saleMap.put("userid", userId);
//
//            // Serialize <Sale> node
//            NodeList saleNodes = document.getElementsByTagName("Sale");
//            if (saleNodes.getLength() > 0) {
//                Element saleElement = (Element) saleNodes.item(0);
//
//                // Convert to string
//                Transformer transformer = TransformerFactory.newInstance().newTransformer();
//                StringWriter writer = new StringWriter();
//                transformer.transform(new DOMSource(saleElement), new StreamResult(writer));
//                String saleXml = writer.toString();
//                saleMap.put("sale_element", saleXml);
//
//                // Extract CTRReference
//                NodeList ctrRefNodes = saleElement.getElementsByTagName("CTRReference");
//                if (ctrRefNodes.getLength() > 0) {
//                    String ctrReference = ctrRefNodes.item(0).getTextContent();
//                    saleMap.put("ctr_reference", ctrReference);
//
//                    // Fetch booking ref from DB
//                    String bookingReference  = bookingRepository.findBookingReferenceByCtrReference(ctrReference);
//                    if (bookingReference != null) {
//                        saleMap.put("contact_booking_ref", bookingReference);
//                    } else {
//                        log.info("sale...");
//                    }
//                }
//            }
//
//        } catch (Exception e) {
//           // log.error("Error parsing input XML", e);
//            return null;
//        }
//
//        return saleMap;
//    }


