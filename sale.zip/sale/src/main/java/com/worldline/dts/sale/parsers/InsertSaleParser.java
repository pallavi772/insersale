package com.worldline.dts.sale.parsers;


import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.worldline.dts.common.logger.DTSLogger;
import com.worldline.dts.sale.dataaccess.BookingRepository;

@Component
public class InsertSaleParser  {
	
	private static DTSLogger log = DTSLogger.getLogger(InsertSaleParser.class);

	
	@Autowired
	private BookingRepository bookingRepository;

	public Map<String, String> parseInput(String inputXml,BookingRepository bookingRepository) {
		return null;
	}
}

