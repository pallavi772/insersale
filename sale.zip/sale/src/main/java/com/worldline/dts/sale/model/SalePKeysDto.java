package com.worldline.dts.sale.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import lombok.Data;

@Data
public class SalePKeysDto {
	
	 @JacksonXmlProperty(localName = "postcode")
	    private String postcode;

}
