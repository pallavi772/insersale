package com.worldline.dts.sale.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class Parameters {
	
	  @XmlElement(name = "ID")
	    private String id;

	    @XmlElement(name = "Sale")
	    private SaleXml sale;

}
