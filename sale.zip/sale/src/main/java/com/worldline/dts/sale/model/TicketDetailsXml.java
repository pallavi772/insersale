package com.worldline.dts.sale.model;

import jakarta.xml.bind.annotation.XmlAttribute;

public class TicketDetailsXml {
	
	 @XmlAttribute(name = "CarnetLayout")
	    private String carnetLayout;

	    @XmlAttribute(name = "MandatoryReservation")
	    private String mandatoryReservation;

	    @XmlAttribute(name = "OutwardDate")
	    private String outwardDate;

}
