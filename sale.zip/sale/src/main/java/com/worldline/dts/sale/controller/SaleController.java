package com.worldline.dts.sale.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.worldline.dts.sale.service.SaleService;

import jakarta.validation.Valid;

//@Tag(name = "sale", description = "the sale API")
@RestController
public class SaleController {

	@Autowired
	SaleService saleService;

	// @Operation(summary = "Create a sale", description = "Create a sale.", tags =
	// { "Sale" })
	@PostMapping(value = "/v2/sale", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.TEXT_XML_VALUE }, produces = { MediaType.APPLICATION_XML_VALUE, MediaType.TEXT_XML_VALUE })
	@ResponseStatus(HttpStatus.CREATED)
	public String insertSale1(@Valid @RequestBody String xmlPayload) {
		return saleService.processSaleSearch(xmlPayload);
	}

//	@PostMapping(value = "/v2/sale", consumes = { MediaType.APPLICATION_XML_VALUE,
//			MediaType.TEXT_XML_VALUE }, produces = { MediaType.APPLICATION_XML_VALUE, MediaType.TEXT_XML_VALUE })
//	@ResponseStatus(HttpStatus.CREATED)
//	public String insertSale(@RequestBody SaleRecordDto saleRecordDto) {
//		return saleService.processSaleSearch(saleRecordDto);
//	}
}
