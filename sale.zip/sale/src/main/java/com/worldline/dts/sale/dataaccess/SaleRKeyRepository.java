package com.worldline.dts.sale.dataaccess;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SaleRKeyRepository extends JpaRepository<SaleRKey, Long> {
	
    boolean existsByRefundReference(String refundReference);


}
