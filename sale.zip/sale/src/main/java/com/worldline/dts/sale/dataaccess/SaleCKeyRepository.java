package com.worldline.dts.sale.dataaccess;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SaleCKeyRepository extends JpaRepository<SaleCKey, Long> {

}
