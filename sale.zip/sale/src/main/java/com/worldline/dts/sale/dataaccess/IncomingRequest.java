package com.worldline.dts.sale.dataaccess;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "incoming_request")
@Data
public class IncomingRequest {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "raw_message")
	private String rawMessage;

	@Column(name = "last_updated")
	private Date lastUpdated;

	@Column(name = "ticket_issuer")
	private String ticketIssuer;

}
