package com.worldline.dts.sale.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import lombok.Data;

@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class RefundItemXml {

	 @XmlAttribute(name = "Type")
	    private String type;

	    @XmlAttribute(name = "ReversalMethod")
	    private String reversalMethod;

	    @XmlAttribute(name = "TransNumber")
	    private String transNumber;

	    @XmlAttribute(name = "RefundAmount")
	    private String refundAmount;

	    @XmlAttribute(name = "Keyed")
	    private String keyed;

	    @XmlAttribute(name = "ApplicationTicketId")
	    private String applicationTicketId;
}
