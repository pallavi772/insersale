package com.worldline.dts.sale.model;


import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Data;

@XmlRootElement(name = "Request")
@XmlAccessorType(XmlAccessType.FIELD)@Data
public class InsertSaleRequest {

	@XmlAttribute(name = "original_id")
    private String originalId;

    @XmlAttribute(name = "MachineType")
    private String machineType;

    @XmlAttribute(name = "Machine")
    private String machine;

    @XmlAttribute(name = "UserID")
    private String userId;

    @XmlAttribute(name = "BusinessGroup")
    private String businessGroup;

    @XmlAttribute(name = "contact_booking_ref")
    private String contactBookingRef;

    @XmlAttribute(name = "CTRReference")
    private String ctrReference;

    @XmlAttribute(name = "Postcode")
    private String postcode;

    @XmlAttribute(name = "Surname")
    private String surname;

    @XmlAttribute(name = "RefundReference")
    private String refundReference;
    
    @XmlElement(name = "Parameters")
    private Parameters parameters;
//
//    @XmlAttribute(localName = "c_keys")
//    @JacksonXmlProperty(localName = "c_key")
//    private List<SaleCKeysDto> cKeys;
//
//    @JacksonXmlElementWrapper(localName = "n_keys")
//    @JacksonXmlProperty(localName = "n_key")
//    private List<SaleNKeysDto> nKeys;
//
//    @JacksonXmlElementWrapper(localName = "p_keys")
//    @JacksonXmlProperty(localName = "p_key")
//    private List<SalePKeysDto> pKeys;
//
//    @JacksonXmlElementWrapper(localName = "r_keys")
//    @JacksonXmlProperty(localName = "r_key")
//    private List<SaleRKeysDto> rKeys;
//
//    @JacksonXmlElementWrapper(localName = "t_keys")
//    @JacksonXmlProperty(localName = "t_key")
//    private List<SaleTKeysDto> tKeys;
}
