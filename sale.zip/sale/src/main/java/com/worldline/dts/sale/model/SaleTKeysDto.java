package com.worldline.dts.sale.model;

public class SaleTKeysDto {

}
