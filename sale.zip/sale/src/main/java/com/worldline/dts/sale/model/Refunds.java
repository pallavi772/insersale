package com.worldline.dts.sale.model;

import java.util.List;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Data;

@XmlRootElement(name = "Refunds")
@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class Refunds {
	  @XmlElement(name = "Refund")
	    private List<Refund> refund;
}
