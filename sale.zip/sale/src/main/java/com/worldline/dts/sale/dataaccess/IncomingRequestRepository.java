package com.worldline.dts.sale.dataaccess;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface IncomingRequestRepository
		extends JpaRepository<IncomingRequest, Long>, JpaSpecificationExecutor<IncomingRequest> {

	@Modifying
	@Transactional
	@Query(value = "INSERT INTO incoming_request (raw_message, last_updated, ticket_issuer) "
			+ "VALUES (:rawMessage, :lastUpdated, :ticketIssuer)", nativeQuery = true)
	void insertIncomingRequest(@Param("rawMessage") String rawMessage, @Param("lastUpdated") Date lastUpdated,
			@Param("ticketIssuer") String ticketIssuer);
}
