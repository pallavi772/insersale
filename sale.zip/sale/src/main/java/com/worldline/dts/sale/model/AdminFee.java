package com.worldline.dts.sale.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import lombok.Data;

@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class AdminFee {
	

    @XmlAttribute(name = "Amount")
    private String amount;

    @XmlAttribute(name = "AdminFeeType")
    private String adminFeeType;

    @XmlAttribute(name = "AdminFeeKeyed")
    private String adminFeeKeyed;

    @XmlAttribute(name = "Id")
    private String id;

    @XmlAttribute(name = "SundryCode")
    private String sundryCode;

}
