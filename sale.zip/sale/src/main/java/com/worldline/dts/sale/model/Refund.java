package com.worldline.dts.sale.model;

import java.sql.Date;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class Refund {


	 @XmlAttribute(name = "RefundReference")
	    private String refundReference;

	 @XmlAttribute(name = "WebTISRefundId")
	    private String webTISRefundId;

	    @XmlAttribute(name = "RefundReason")
	    private String refundReason;

	    @XmlAttribute(name = "Title")
	    private String title;

	    @XmlAttribute(name = "Forename")
	    private String forename;

	    @XmlAttribute(name = "Surname")
	    private String surname;

	    @XmlAttribute(name = "AddressLine1")
	    private String addressLine1;

	    @XmlAttribute(name = "AddressLine2")
	    private String addressLine2;

	    @XmlAttribute(name = "AddressLine3")
	    private String addressLine3;

	    @XmlAttribute(name = "AddressLine4")
	    private String addressLine4;

	    @XmlAttribute(name = "Postcode")
	    private String postcode;

	    @XmlAttribute(name = "HomeTelephone")
	    private String homeTelephone;

	    @XmlAttribute(name = "MobileTelephone")
	    private String mobileTelephone;

	    @XmlAttribute(name = "CreatedDateTime")
	    private String createdDateTime;

	    @XmlAttribute(name = "CreationUserId")
	    private String creationUserId;

	    @XmlAttribute(name = "AuthorisedDateTime")
	    private String authorisedDateTime;

	    @XmlAttribute(name = "AuthorisingUserName")
	    private String authorisingUserName;

	    @XmlAttribute(name = "AuthorisingUserId")
	    private String authorisingUserId;

	    @XmlAttribute(name = "RefundStatus")
	    private String refundStatusAttr;  // from attribute

	    // Elements
	    @XmlElement(name = "RefundReference")
	    private String refundRefElement;

	    @XmlElement(name = "Surname")
	    private String surnameElement;

	    @XmlElement(name = "Postcode")
	    private String postcodeElement;

	    @XmlElement(name = "RefundStatus")
	    private String refundStatusElement;

	    @XmlElement(name = "AdminFee")
	    private AdminFee adminFee;

	    @XmlElement(name = "RefundItems")
	    private RefundItems refundItems;

	    @XmlElement(name = "RefundPayments")
	    private RefundPayments refundPayments;
	    
	   
	    }
