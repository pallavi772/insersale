package com.worldline.dts.sale.model;

import jakarta.xml.bind.annotation.XmlAttribute;

public class TicketDetails {
	
	  @XmlAttribute(name = "OutwardDate")
	    private String outwardDate;

	    @XmlAttribute(name = "MandatoryReservation")
	    private String mandatoryReservation;

}
