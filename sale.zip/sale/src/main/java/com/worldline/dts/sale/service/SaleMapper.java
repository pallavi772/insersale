package com.worldline.dts.sale.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.mapstruct.Mapper;

import com.worldline.dts.sale.dataaccess.Sale;
import com.worldline.dts.sale.dataaccess.SaleCKey;
import com.worldline.dts.sale.dataaccess.SaleNKey;
import com.worldline.dts.sale.dataaccess.SalePKey;
import com.worldline.dts.sale.dataaccess.SaleRKey;
import com.worldline.dts.sale.dataaccess.SaleTKey;
import com.worldline.dts.sale.model.InsertSaleRequest;
import com.worldline.dts.sale.model.LoyaltyDetail;
import com.worldline.dts.sale.model.Parameters;
import com.worldline.dts.sale.model.Payment;
import com.worldline.dts.sale.model.Refund;
import com.worldline.dts.sale.model.SaleRecordDto;
import com.worldline.dts.sale.model.Ticket;
import com.worldline.dts.sale.model.TicketDetails;

@Mapper(componentModel = "spring")
public class SaleMapper {

		public SaleRecordDto mapToEntity(InsertSaleRequest request) {
			  String machineType = request.getMachineType();
			    String machine = request.getMachine();
			    String userId = request.getUserId();
		
			    if (machineType == null || machineType.isBlank() ||
			            machine == null || machine.isBlank() ||
			            userId == null || userId.isBlank()) {
			    	throw new IllegalArgumentException("Missing required fields: machineType, machine, or userId");
			        }
				
			  SaleRecordDto dto = new SaleRecordDto();
		        dto.setMachineType(request.getMachineType());
		        dto.setMachine(request.getMachine());
		        dto.setUserId(request.getUserId());
		        dto.setContactBookingRef(request.getContactBookingRef());
		        String originalId = request.getOriginalId();
		        if (originalId == null || originalId.trim().isEmpty()) {
		            originalId = "0";
		        }
		        dto.setLastUpdated(new Date());
		        dto.setOriginalId(originalId);
		       
		        Parameters params = request.getParameters();
		        if (params != null && params.getSale() != null) {
		            com.worldline.dts.sale.model.Sale sale = params.getSale();
		            dto.setSale(sale);
		            dto.setTransactionNumber(sale.getCtrReference());
		            dto.setIssueMchine(sale.getIssueMachine());
		            dto.setIssueDate(sale.getSaleIssueDate());
		            dto.setBusinessGroup(sale.getBusinessGroup());  
			        dto.setCtrReference(sale.getCtrReference());
			        dto.setPostcode(sale.getRefunds().getRefund().get(0).getPostcode());
			        dto.setSurname(sale.getRefunds().getRefund().get(0).getSurname());
			        dto.setRefundReference(sale.getRefunds().getRefund().get(0).getRefundReference());
			        //dto.setRefundStatus(originalId);

		    
		            // --- CSale
		            if (sale.getCtrReference() != null) {
		                SaleCKey cKey = new SaleCKey();
		                cKey.setCtrReference(sale.getCtrReference());
		                dto.setCSale(List.of(cKey));
		            }

		            // --- RSale
		            List<SaleRKey> rKeys = new ArrayList<>();
		            if (sale.getRefunds() != null) {
		                for (Refund refund : sale.getRefunds().getRefund()) {
		                    SaleRKey rKey = new SaleRKey();
		                    rKey.setRefundReference(refund.getRefundReference());
		                    rKey.setRefundStatus(refund.getRefundStatusAttr());
		                    rKeys.add(rKey);
		                }
		            }
		            dto.setRSale(rKeys);
		            
		            List<SalePKey> pKeys = new ArrayList<>();
//		            if (sale.getPayments() != null) {
//		                for (Payment payment : sale.getPayments().getPayment()) {
//		                    SalePKey pKey = new SalePKey();
//		                    pKey.setAmount(payment.getAmount());
//		                    pKey.setCompanyCode(payment.getCompany);
//		                    pKey.setCreditInd(payment.getCreditInd());
//		                    pKeys.add(pKey);
//		                }
//		            }
//		            dto.setPSale(pKeys);


//		            // --- NSale
//		            List<SaleNKey> nKeys = new ArrayList<>();
//		            if (sale.getTickets() != null) {
//		                for (Ticket ticket : sale.getTickets().getTicket()) {
//		                    for (LoyaltyDetail loyalty : ticket.getLoyaltyDetail()) {
//		                        SaleNKey nKey = new SaleNKey();
//		                        nKey.setLoyaltyCardId(loyalty.getLoyaltyCardId());
//		                        nKey.setPoints(loyalty.getPoints());
//		                        nKeys.add(nKey);
//		                    }
//		                }
//		            }
//		            dto.setNSale(nKeys);
//
//		            // --- PSale
//		            List<SalePKey> pKeys = new ArrayList<>();
//		            if (sale.getPayments() != null) {
//		                for (Payment payment : sale.getPayments().getPayment()) {
//		                    SalePKey pKey = new SalePKey();
//		                    pKey.setAmount(payment.getAmount());
//		                    pKey.setCompanyCode(payment.getCompany);
//		                    pKey.setCreditInd(payment.getCreditInd());
//		                    pKeys.add(pKey);
//		                }
//		            }
//		            dto.setPSale(pKeys);
//
//		            // --- TSale
//		            List<SaleTKey> tKeys = new ArrayList<>();
//		            if (sale.getTickets() != null) {
//		                for (Ticket ticket : sale.getTickets().getTicket()) {
//		                    SaleTKey tKey = new SaleTKey();
//		                    tKey.setTicketType(ticket.getTicketType());
//		                    tKey.setFareAmount(ticket.getFareAmount());
//		                    tKey.setTransactionNumber(ticket.getTransactionNumber());
//		                    tKey.setRoute(ticket.getRoute());
//		                    tKeys.add(tKey);
//		                }
//		            }
//		            dto.setTSale(tKeys);
//		        }

		        }
		         
		        return dto;
		}
		       
		
}
		
		

	   
	

