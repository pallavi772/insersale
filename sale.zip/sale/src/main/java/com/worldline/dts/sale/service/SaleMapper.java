package com.worldline.dts.sale.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.worldline.dts.sale.dataaccess.Sale;
import com.worldline.dts.sale.dataaccess.SaleCKey;
import com.worldline.dts.sale.dataaccess.SaleNKey;
import com.worldline.dts.sale.dataaccess.SalePKey;
import com.worldline.dts.sale.dataaccess.SaleRKey;
import com.worldline.dts.sale.dataaccess.SaleTKey;

public class SaleMapper {

	public static Sale toSaleEntity(Map<String, String> map, Long incomingRequestId) {
        Sale sale = new Sale();
        sale.setMachine(map.get("machine"));
        sale.setUserId(map.get("userid"));
        sale.setBusinessGroup(map.get("sale_element"));
        //sale.set(map.get("ctr_reference"));
        sale.setBusinessGroup(map.get("business_group"));
        String bookingRef = map.get("contact_booking_reference");
        if (bookingRef != null && !bookingRef.isEmpty()) {
            try {
                sale.setContactBookingRef(Long.parseLong(bookingRef));
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid contact_booking_reference: " + bookingRef);
            }
        } else {
            sale.setContactBookingRef(null); // or throw exception based on business rules
        }        return sale;
    }

	  public static SaleCKey toCSaleEntity(Sale sale) {
		  SaleCKey cSale = new SaleCKey();
	        cSale.setSale(sale);
	        cSale.setCtrReference(sale.getContactBookingRef() != null ? sale.getContactBookingRef().toString() :null);
	        return cSale;
	    }

    public static List<SaleTKey> toTSaleEntities(Map<String, String> map, Sale sale) {
        List<SaleTKey> list = new ArrayList<>();
        int size = Integer.parseInt(map.getOrDefault("transaction_size", "0"));
        for (int i = 0; i < size; i++) {
        	SaleTKey tsale = new SaleTKey();
            tsale.setSale(sale);
            tsale.setTransactionNumber(map.get("transaction" + i));
            tsale.setIssueDate(map.get("issue_date" + i));
            tsale.setTravelDate(map.get("travel_date" + i));
            tsale.setIsrn(map.get("isrn" + map.get("transaction" + i)));
            tsale.setIpeInstanceId(map.get("ipe_instanceId" + map.get("transaction" + i)));
            list.add(tsale);
        }
        return list;
    }

    public static List<SaleRKey> toRSaleEntities(Map<String, String> map, Sale sale) {
        List<SaleRKey> list = new ArrayList<>();
        int size = Integer.parseInt(map.getOrDefault("refund_reference_size", "0"));
        for (int i = 0; i < size; i++) {
        	SaleRKey rsale = new SaleRKey();
            rsale.setSale(sale);
            rsale.setRefundReference(map.get("refund_reference" + i));
            rsale.setRefundStatus(map.get("refund_status" + i));
         //   rsale.setRefundCreatedDate(map.get("createdDate" + map.get("refund_reference" + i)));
            list.add(rsale);
        }
        return list;
    }

    public static List<SaleNKey> toNSaleEntities(Map<String, String> map, Sale sale) {
        List<SaleNKey> list = new ArrayList<>();
        int size = Integer.parseInt(map.getOrDefault("surname_size", "0"));
        for (int i = 0; i < size; i++) {
        	SaleNKey nsale = new SaleNKey();
            nsale.setSale(sale);
            nsale.setSurname(map.get("surname" + i));
            list.add(nsale);
        }
        return list;
    }

    public static List<SalePKey> toPSaleEntities(Map<String, String> map, Sale sale) {
        List<SalePKey> list = new ArrayList<>();
        int size = Integer.parseInt(map.getOrDefault("postcode_size", "0"));
        for (int i = 0; i < size; i++) {
        	SalePKey psale = new SalePKey();
            psale.setSale(sale);
            psale.setPostcode(map.get("postcode" + i));
            list.add(psale);
        }
        return list;
    }
}
