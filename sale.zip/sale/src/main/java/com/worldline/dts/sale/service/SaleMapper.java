package com.worldline.dts.sale.service;

import java.util.ArrayList;
import java.util.Date;
import org.mapstruct.Mapper;
import com.worldline.dts.sale.model.InsertSaleRequest;
import com.worldline.dts.sale.model.LoyaltyDetailXml;
import com.worldline.dts.sale.model.Parameters;
import com.worldline.dts.sale.model.PaymentXml;
import com.worldline.dts.sale.model.PaymentsXml;
import com.worldline.dts.sale.model.RefundXml;
import com.worldline.dts.sale.model.SaleRecordDto;
import com.worldline.dts.sale.model.SaleXml;
import com.worldline.dts.sale.model.SundriesXml;
import com.worldline.dts.sale.model.SundryXml;
import com.worldline.dts.sale.model.TicketXml;
;

@Mapper(componentModel = "spring")
public class SaleMapper {

		public SaleRecordDto mapToDto(InsertSaleRequest request) {
			   if (request == null || request.getMachineType() == null || request.getMachine() == null || request.getUserId() == null) {
		            throw new IllegalArgumentException("MachineType, Machine, or UserID is missing.");
		        }
				
			  SaleRecordDto dto = new SaleRecordDto();
		        dto.setMachineType(request.getMachineType());
		        dto.setMachine(request.getMachine());
		        dto.setUserId(request.getUserId());
		        dto.setContactBookingRef(request.getContactBookingRef());
		        String originalId = request.getOriginalId();
		        if (originalId == null || originalId.trim().isEmpty()) {
		            originalId = "0";
		        }
		        dto.setLastUpdated(new Date());
		        dto.setOriginalId(originalId);
		       
		        Parameters params = request.getParameters();
		        if (params != null && params.getSale() != null) {
		            SaleXml sale = params.getSale();
		            dto.setSale(sale);
		            dto.setBusinessGroup(sale.getBusinessGroup());  
			        dto.setCtrReference(sale.getCtrReference());
                    dto.setFulfilment(sale.getFulfilment());
                    dto.setIssueMchine(sale.getIssueMachine());
		            dto.setIssueDate(sale.getSaleIssueDate());
		            dto.setIssueOffice(sale.getIssueOffice());
		            dto.setIssueWindow(sale.getIssueWindow());
		            dto.setSaleIssueDate(sale.getSaleIssueDate());
		            dto.setSaleNumber(sale.getSaleNumber());
		            
		            if (sale.getTickets() != null && sale.getTickets().getTicket() != null) {
                        for (TicketXml ticket : sale.getTickets().getTicket()) {
                        	dto.setApplicationTicketId(ticket.getApplicationTicketId());
                        	dto.setTicketClass(ticket.getTicketClass());
                        	dto.setDestination(ticket.getDestination());
                        	dto.setTransactionNumber(ticket.getTransactionNumber());
                        	 if (ticket.getTicketDetails() != null) {
                        	 }
                        	 
                            if (ticket.getLoyaltyDetail() != null) {
                                LoyaltyDetailXml loyalty = ticket.getLoyaltyDetail();
                                dto.setLoyaltyCardId(loyalty.getLoyaltyCardIdElement());
                            }

                            // Set transaction number from first ticket (for reference)
                            if (dto.getTransactionNumber() == null) {
                                dto.setTransactionNumber(ticket.getTransactionNumber());
                            }
                        }
                    }
		            
		            if (sale.getSundries()!= null && sale.getSundries().getSundry() != null) {
		            	 for (SundryXml sundary : sale.getSundries().getSundry()) {
		            		 dto.setIssueDate(sundary.getIssueDate());
		            		 dto.setTransactionNumber(sundary.getTransactionNumber());
		            		 dto.setAmount(sundary.getAmount());
		            	 }
		            	
		            }
		            
		            if (sale.getPayments()!= null && sale.getPayments().getPayment() != null) {
		            	for (PaymentXml payment : sale.getPayments().getPayment()) {
		            		 dto.setAmount(payment.getAmount());
		            		 dto.setMop(payment.getMop());
                             dto.setMaskedPAN(payment.getMaskedPAN());
		            		 
		            		 
		            	 }		            	
		            }
                    RefundXml refund = sale.getRefunds().getRefund().get(0);	            
                    if (sale.getRefunds() != null && !sale.getRefunds().getRefund().isEmpty()) {
                        dto.setRefundReference(refund.getRefundReference());
                        dto.setRefundStatus(refund.getRefundStatusAttr());
                        dto.setPostcode(refund.getPostcode());
                        dto.setSurname(refund.getSurname());
                       //dto.setRefundCreatedDate(refund.getCreatedDateTime());
                    }
                    
		                    if (refund.getRefundPayments() != null && refund.getRefundPayments().getPayments() != null) {
		                        for (PaymentXml payment : refund.getRefundPayments().getPayments()) {
		                        	 dto.setAmount(payment.getAmount());
				            		 dto.setMop(payment.getMop());
		                             dto.setMaskedPAN(payment.getMaskedPAN());
		                        }
		                    }
		                }
	         
		        return dto;
		}
		       
		
}
		
// 4. CTR Reference → CSale
//if (sale.getCtrReference() != null) {
//    SaleCKey cKey = new SaleCKey();
//    cKey.setCtrReference(sale.getCtrReference());
//    dto.setCSale(List.of(cKey));
//}
//
//List<SaleNKey> nKeys = new ArrayList<>();
//if (sale.getTickets() != null && sale.getTickets().getTicket() != null) {
//    for (Ticket ticket : sale.getTickets().getTicket()) {
//        LoyaltyDetail loyalty = ticket.getLoyaltyDetail();
//        if (loyalty != null) {
//            SaleNKey nKey = new SaleNKey();
//         //   nKey.setSurname(sale.getTickets().getTicket().get(0).g);
//           // nKey.setLoyaltyCardId(loyalty.getLoyaltyCardIdElement());
//           // nKey.setPoints(loyalty.getPoints());
//            nKeys.add(nKey);
//        }
//    }
//}
//dto.setNSale(nKeys);
//List<SalePKey> pKeys = new ArrayList<>();
//if (sale.getRefunds() != null) {
//    for (Refund refund : sale.getRefunds().getRefund()) {
//        if (refund.getRefundPayments() != null && refund.getRefundPayments().getPayment() != null) {
//            for (Payment payment : refund.getRefundPayments().getPayment()) {
//                SalePKey pKey = new SalePKey();
//                pKey.setAmount(payment.getAmount());
//                pKey.setCompanyCode(payment.getCompanyCode());
//                pKey.setCreditInd(payment.getPaymentRefundFlag());
//                pKeys.add(pKey);
//            }
//        }
//    }
//}
//
//// 5. NSale list initialization if loyalty was not set
//if (dto.getNSale() == null) {
//    dto.setNSale(new ArrayList<>());
//}

//		            if (sale.getPayments() != null) {
//    for (Payment payment : sale.getPayments().getPayment()) {
//        SalePKey pKey = new SalePKey();
//        pKey.setAmount(payment.getAmount());
//        pKey.setCompanyCode(payment.getCompany);
//        pKey.setCreditInd(payment.getCreditInd());
//        pKeys.add(pKey);
//    }
//}
//dto.setPSale(pKeys);


//// --- NSale
//List<SaleNKey> nKeys = new ArrayList<>();
//if (sale.getTickets() != null) {
//    for (Ticket ticket : sale.getTickets().getTicket()) {
//        for (LoyaltyDetail loyalty : ticket.getLoyaltyDetail()) {
//            SaleNKey nKey = new SaleNKey();
//            nKey.setLoyaltyCardId(loyalty.getLoyaltyCardId());
//            nKey.setPoints(loyalty.getPoints());
//            nKeys.add(nKey);
//        }
//    }
//}
//dto.setNSale(nKeys);
//
//// --- PSale
//List<SalePKey> pKeys = new ArrayList<>();
//if (sale.getPayments() != null) {
//    for (Payment payment : sale.getPayments().getPayment()) {
//        SalePKey pKey = new SalePKey();
//        pKey.setAmount(payment.getAmount());
//        pKey.setCompanyCode(payment.getCompany);
//        pKey.setCreditInd(payment.getCreditInd());
//        pKeys.add(pKey);
//    }
//}
//dto.setPSale(pKeys);
//
//// --- TSale
//List<SaleTKey> tKeys = new ArrayList<>();
//if (sale.getTickets() != null) {
//    for (Ticket ticket : sale.getTickets().getTicket()) {
//        SaleTKey tKey = new SaleTKey();
//        tKey.setTicketType(ticket.getTicketType());
//        tKey.setFareAmount(ticket.getFareAmount());
//        tKey.setTransactionNumber(ticket.getTransactionNumber());
//        tKey.setRoute(ticket.getRoute());
//        tKeys.add(tKey);
//    }
//}
//dto.setTSale(tKeys);
//}



	   
	

