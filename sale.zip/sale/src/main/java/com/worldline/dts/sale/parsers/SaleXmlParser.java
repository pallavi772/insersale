package com.worldline.dts.sale.parsers;

public class SaleXmlParser {

}
