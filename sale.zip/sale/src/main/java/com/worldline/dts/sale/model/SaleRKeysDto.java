package com.worldline.dts.sale.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import lombok.Data;

@Data
public class SaleRKeysDto {
	  @JacksonXmlProperty(isAttribute = true, localName = "RefundReference")
	    private String refundReference;
	  
	   @JacksonXmlProperty(localName = "RefundStatus")
	    private String refundStatus;

	    @JacksonXmlProperty(localName = "CreatedDateTime")
	    private String createdDateTime;
}
