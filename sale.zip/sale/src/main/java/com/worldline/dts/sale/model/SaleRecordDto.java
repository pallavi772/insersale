package com.worldline.dts.sale.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import com.worldline.dts.sale.dataaccess.SaleCKey;
import com.worldline.dts.sale.dataaccess.SaleNKey;
import com.worldline.dts.sale.dataaccess.SalePKey;
import com.worldline.dts.sale.dataaccess.SaleRKey;
import com.worldline.dts.sale.dataaccess.SaleTKey;

import lombok.Data;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

@JacksonXmlRootElement(localName = "SaleRecordDto")
@Data
public class SaleRecordDto {

	public BigInteger id;
	public BigInteger cid;
	public BigInteger tid;
	public BigInteger rid;
	public BigInteger pid;
	public BigInteger nid;
	public BigInteger lid;

	public String originalId;
	public String machineType;
	public String machine;
	public String userId;
	public Date lastUpdated;

	public Sale sale;
	public String ctrReference;
	public String surname;
	public String postcode;
	public String refundReference;

	public String refundStatus;
	public String issueMchine;
	public String issueDate;
	public String transactionNumber;

	public String businessGroup;
	public String contactBookingRef;

	public long ticketingRecordId;
	public String travelDate;
	private String isrn;
	private String ipeInstanceId;

	public String businessCode;
	public String tisType;
	public int sequenceNumber;
	private long loyaltyCardId;
	public String refundCreatedDate;

	private List<SaleCKey> cSale;
	private List<SaleRKey> rSale;
	private List<SaleNKey> nSale;
	private List<SalePKey> pSale;
	private List<SaleTKey> tSale;

}
