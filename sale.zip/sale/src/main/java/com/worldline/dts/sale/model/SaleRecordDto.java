package com.worldline.dts.sale.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.Data;

import java.math.BigInteger;
import java.util.Date;

@JacksonXmlRootElement(localName = "SaleRecordDto")
@Data
public class SaleRecordDto {

	public BigInteger id;
	public BigInteger cid;
	public BigInteger tid;
	public BigInteger rid;
	public BigInteger pid;
	public BigInteger nid;
	public BigInteger lid;

	public String originalId;
	public String machineType;
	public String machine;
	public String userId;
	public Date lastUpdated;

	public SaleXml sale;
	 // Sale basic info
	public String ctrReference;
	public String businessGroup;
	public String fulfilment;
    public String issueMachine;
    public String issueDate;
    public String saleIssueDate;
    public String saleNumber;
    public String issueOffice;
	public String issueWindow;

    // Ticket info (from first ticket, or iterate as needed)
	public String applicationTicketId;
	public String ticketClass;
	public String destination;
	public String transactionNumber;
	public String contactBookingRef;
	public String FareAmount;
	public String FulfilmentMethod;
	public String ProductType;
	public String Route;
	public String Status;
	public String TicketType;
	public String DiscountPercent;
	public String Origin;
	
	public String loyaltyCardId;

    // Refund info
	public String refundReference;
	public String refundStatus;
	public String postcode;
	public String surname;
	public String refundCreatedDate;
	public String issueMchine;
	public String WebTISRefundId;
	public String RefundReason;

	
	public long ticketingRecordId;
	public String travelDate;
	public String isrn;
	public String ipeInstanceId;
	public String tisType;
	public int sequenceNumber;
	public String mop;
	public String Amount;
	public String MaskedPAN;
	
	public String SundryCode;
	
	
	
	
	


	

}
